# RideMesh Android vc54 — Direct-Link Diagnostic

Purpose: isolate the Android-to-Android offline voice failure from mesh routing, Opus, billing, and stale reconnect audio.

## Test architecture

Phone A <-> Google Nearby P2P_CLUSTER direct endpoint <-> Phone B

- Exactly one direct peer is allowed.
- MeshRelayRouter is bypassed for this diagnostic build.
- Internet relay/bridge is not used for local diagnostic audio.
- Raw PCM16, 16 kHz, mono, 20 ms, 640 bytes per audio frame.
- Audio frames are sent immediately to the direct Nearby endpoint. The vc51-vc53 four-payload transfer-ack gate is bypassed.
- Discovery and advertising are stopped after identity lock, and restarted only after a disconnect.
- One side deterministically initiates the Nearby connection to avoid simultaneous connection-request churn.
- Every direct connection gets a generation number. Remote audio from an older generation is discarded.
- A reconnect uses a generation-specific playout source key so stale audio cannot append to a new jitter-buffer timeline.
- Incoming audio is flushed when the direct endpoint is lost.

## Billing

Google Play Billing dependency and RideMeshBillingManager are removed from this diagnostic build. Premium gates are bypassed. This is not a production/subscription build.

## Diagnostics

The offline Status button opens an engineering report containing:

- direct peers, discovered endpoints, advertising/discovery state
- connection attempts/success/fail/pending
- reconnect count and connection generation
- total Nearby TX/RX payloads and send failures
- raw audio TX/RX frame totals and average fps (target 50 fps)
- immediate-send completion/failure/pending counts and maximum pending depth
- last/max TX and RX packet gaps
- AudioEngine missing/duplicate/reordered/late/underrun/rebuffer counters
- playback bytes/errors and incoming flush count
- rolling last 80 diagnostic events
- COPY LOG button

Android Logcat tag: `RideMeshVC54`.

## First test

Use exactly two Android phones with the same ride code, close together. Wait until both screens show DIRECT CONNECTED / DIRECT LINK LOCKED. Then speak continuously for 20-30 seconds and open Status on both phones. Copy the diagnostic report from both devices.

Do not test multi-hop or range yet.
