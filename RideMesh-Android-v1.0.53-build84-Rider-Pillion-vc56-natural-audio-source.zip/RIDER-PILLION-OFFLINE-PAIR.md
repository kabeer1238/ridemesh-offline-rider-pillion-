# Rider + Pillion Offline Pair prototype (vc80 base)

This package extends the vc80 source with a dedicated two-phone Rider + Pillion entry flow.

## Flow
1. Rider selects RIDER and taps START RIDER PAIR.
2. RideMesh creates a private random 6-digit pair code and displays it.
3. Pillion selects PILLION, taps CONNECT TO RIDER, and enters the Rider code.
4. Both devices force LOCAL_ONLY and use the existing VC56 direct Nearby profile (P2P_POINT_TO_POINT).
5. Wi-Fi + Bluetooth are required; Internet/mobile data are not required.

## Safety / regression scope
- Existing Create Ride / Join Ride flows are unchanged.
- Existing offline audio codec, 40 ms packet work, AudioEngine, WebRTC/SFU/TURN and hybrid bridge code are unchanged.
- Pair mode reuses the known direct offline voice transport rather than adding a second audio engine.
- The 6-digit code isolates nearby Rider/Pillion pairs and avoids a universal discovery token.

## Build note
Gradle compilation could not be run in the packaging environment because the Gradle wrapper distribution was not locally cached and external network access is unavailable. XML was edited directly and Kotlin changes are localized to MainActivity.
