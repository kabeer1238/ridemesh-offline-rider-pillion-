# RideMesh vc59 — Cloudflare TURN integration

Base: vc58 3-Rider STAR Fix.

Changes:
- Added dynamic ICE server retrieval from `https://ridemesh-turn-api.salesautopilotindia.workers.dev/turn-credentials`.
- TURN credentials are fetched at runtime; no Cloudflare API token is embedded in the Android app/source.
- Uses Cloudflare-returned STUN/TURN URLs and temporary username/credential.
- Falls back to STUN if credential retrieval is temporarily unavailable.
- Refreshes short-lived TURN credentials approximately every 45 minutes.
- Existing WebRTC Opus/AEC/NS audio path remains unchanged.
- Existing offline Nearby mesh path remains unchanged.
- Added hidden engineering API `setForceTurnForTesting(Boolean)` for relay-only testing (`IceTransportsType.RELAY`).
- Added diagnostics fields for TURN configured/mode/status and selected ICE candidate type/protocol.
- Version bumped to 1.0.29 / vc59.

Build verification note:
An APK could not be compiled in this environment because the Gradle wrapper attempted to download Gradle 8.13 from `services.gradle.org` and this execution environment has no outbound network access. The source is packaged for local Android Studio/Gradle verification.
