# RideMesh vc61.1 SFU Renegotiation + Settings UI Fix

- Preserves vc60 P2P/TURN baseline.
- FORCE SFU now queues remote track announcements until local microphone publishing has completed.
- Serializes Cloudflare pull/renegotiation so a remote pull cannot race the initial publish SDP exchange.
- Counts a remote SFU track only after subscription/renegotiation succeeds.
- Voice Detection in Settings is now a compact iOS-style row with title, description and right-side cyan toggle.
- Silero remains observer-only; no audio gating was introduced.
