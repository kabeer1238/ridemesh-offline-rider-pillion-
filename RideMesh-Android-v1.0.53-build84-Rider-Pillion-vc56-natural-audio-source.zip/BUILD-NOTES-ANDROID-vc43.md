# RideMesh Android vc43 — WebRTC PCM Silero Observer

## Goal
Prove that Silero can observe the existing Android WebRTC microphone PCM without changing RideMesh voice quality, latency, Bluetooth routing, Opus, or call isolation.

## Critical change from Android build 42
Build 42's `OnlineSileroProcessor` was an actual capture **gate**: it buffered ~100 ms of outgoing PCM, could write silence into the ADM buffer, rewrote returned timestamps, and applied gain ramps based on VAD decisions. That was not a safe observation-only A/B baseline.

Build 43 removes all of that behavior.

## Build 43 invariant
`JavaAudioDeviceModule` remains the single microphone owner. Its existing `setAudioBufferCallback` is used only to copy PCM into a bounded analysis queue. The callback never writes to the ByteBuffer and always returns the original timestamp.

Silero inference is performed on `RideMesh-Online-Silero-Observer`, not on the WebRTC capture thread. Queue overflow drops VAD observations, never voice.

Silero does NOT:
- mute/gate TX
- add lookahead/delay
- rewrite timestamps
- modify gain
- modify WebRTC PCM
- open AudioRecord
- change Bluetooth routing
- change Opus/network behavior
- control private-call isolation

The existing `localAudioTrack.setEnabled(...)` policy remains responsible for user mute / focus/private-call TX gating.

## A/B test on Poco F5
1. Build/install vc43.
2. Join a normal online WebRTC ride with Online Silero Observer OFF.
3. Verify TX/RX clarity, latency and Bluetooth helmet route.
4. While still connected, enable Online Silero Observer in Settings. No rejoin should be required.
5. Open Online Silero Diagnostics and verify observed frame count rises and `active` changes with speech.
6. Remote rider should hear no change between OFF and ON.
7. Repeat with helmet Bluetooth, music coexistence, user mute, incoming/private call, call end and automatic recovery.

## Build verification limitation
This package was statically inspected and patched in a Linux environment. Gradle compilation could not run because the Gradle 8.13 distribution was not cached and this runtime has no external network access. Build it in Android Studio/Gradle on the development machine before treating vc43 as runtime-validated.
