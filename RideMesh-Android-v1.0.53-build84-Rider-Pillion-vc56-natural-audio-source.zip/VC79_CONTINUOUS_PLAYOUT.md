# RideMesh Android vc79 — Continuous Offline Playout

Version: 1.0.48-vc79-continuous-playout
Build: 79

Field evidence from vc78 showed good RAW PCM16 quality and a healthy direct Nearby link, but repeated receiver starvation: 62 underruns / 62 rebuffers, 496 late frames, and measured jitter around 121 ms. vc79 therefore changes receiver continuity only.

## Changes
- Preserve 16 kHz mono, 20 ms frames, 4 frames / 80 ms Nearby payload, RAW PCM16 on HIGH, Opus fallback, P2P_POINT_TO_POINT + DISRUPTIVE, and max 3 in-flight payloads.
- Minimum receiver prime is 120 ms.
- Adaptive target is 120/140/160/180/200 ms according to measured burst jitter; burst-size protection remains active.
- Permit up to 60 ms of short-starvation PLC/concealment while keeping the fixed 20 ms AudioTrack clock moving.
- Late-packet grace increased to 90 ms so one delayed 80 ms Nearby burst does not immediately force a rebuffer.
- Full re-prime happens only after the short concealment budget is exhausted.
- Partial 80 ms sender batches tolerate up to 120 ms capture-scheduling gaps (vc78 used 60 ms), reducing avoidable partial-batch discards while still flushing real mute/focus pauses.
- Queue hard cap raised from 300 to 360 ms and frame-age cap from 300 to 420 ms so adaptive priming does not expire its own buffered frames.

## Intentionally unchanged
Codec quality, capture format, Nearby batching, direct-link strategy, backpressure gate, SFU/TURN, AUTO transport selection, VAD, hard mute, billing/Firebase behavior.

## Field success signal
Compared with vc78, rebuffers/underruns should fall sharply during continuous speech. A few PLC frames are acceptable if speech stays continuous. Watch target prime, jitter, late frames, RX packet gap, and mouth-to-ear delay.
