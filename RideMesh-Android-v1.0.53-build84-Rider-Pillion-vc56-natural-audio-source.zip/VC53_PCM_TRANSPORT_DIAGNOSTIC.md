# RideMesh Android vc53 — PCM Transport Diagnostic

Purpose: isolate the Android offline breakup without changing the known-good online WebRTC path.

## Offline diagnostic path
Mic -> exact 20 ms PCM16 mono frame (16 kHz, 640 bytes) -> RideMesh envelope -> Nearby P2P_CLUSTER -> ordered jitter buffer -> AudioTrack.

Opus encode/decode is deliberately bypassed for offline audio in this build. Raw PCM is ~256 kbit/s before transport overhead. This is diagnostic only, not the intended production bandwidth.

## Interpretation
- If vc53 raw PCM is also broken: focus next on Nearby send/ack queue, packet loss/bursting, routing, jitter clock, or AudioTrack starvation. Opus is not the root cause.
- If vc53 raw PCM is clear: focus next on Opus framing/encode/decode state.

## Test
Use exactly two Android phones, close together, one-hop. Do not judge range or bandwidth. Compare normal continuous speech with vc52.
