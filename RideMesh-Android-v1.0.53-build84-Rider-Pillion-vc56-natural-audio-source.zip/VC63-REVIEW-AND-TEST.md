# RideMesh vc63 / build 64 — Nearby checkpoint patch

Version: `1.0.33-vc63-nearby-lifecycle-fix`, versionCode `64`.
Status: source patch only, NOT compiled, NOT device-tested, NOT field-tested.

## Findings and root-cause limits

The supplied archive is not fully consistent with the pasted device report: it already has versionCode 63, AUTO passes hybridMode=true and selects P2P_CLUSTER, AUTO forces SFU, and SFU has pending/in-flight/subscribed deduplication. The diagnostic string nevertheless always printed P2P_POINT_TO_POINT and the APK output filename still named vc61. An installed APK cannot be identified solely from those labels.

Confirmed defects in the supplied source:

1. The watchdog refresh every eight seconds unconditionally stops discovery before starting it again. Other scheduled retries can overlap. This creates repeated false/pending windows and permits out-of-order start completions. It explains a misleading restarted/false snapshot, but does not prove the cause of zero endpoints on the phones.
2. LobbyNode.stop() stopped shared app advertising/discovery even when that lobby was not running. Live invite scanning could also put the hybrid mesh to sleep. Both can interrupt discovery independently of the transport's own flags.
3. Hybrid requests used DISRUPTIVE connection options. Google documents that this can lose Internet connectivity: https://developers.google.com/android/reference/com/google/android/gms/nearby/connection/ConnectionType . This affects connection coexistence, not initial endpoint discovery.
4. Diagnostic transport and APK labels were hard-coded to older modes/builds.

No device logs or vc54 source/git history were included. The exact field root cause remains unconfirmed. This patch addresses these defects; it does not establish successful Nearby voice.

## Changes

- Reconcile advertising/discovery without stopping a healthy scan on watchdog refresh.
- Run discovery reconciliation on the main looper; suppress duplicate starts while tasks are pending; ignore stale start completions using a lifecycle epoch.
- Retain actual start failure text for the report; expose strategy, connection type, service ID, ride token, and pending flags.
- Resume discovery when a cluster peer disconnects even if other peers remain.
- Make an inactive lobby stop a no-op, clean up partial lobby starts, and route active mesh invitations through ride-code/QR sharing instead of a competing lobby scan.
- Use NON_DISRUPTIVE connections for hybrid P2P_CLUSTER only. Keep the explicit legacy direct/star test modes unchanged.
- Preserve the fixed Nearby service ID and ride-token validation. Normalize ride-code hashing with Locale.ROOT to avoid locale-sensitive identities. Matching ride codes use the same service ID and token.
- Keep existing Voice Detection preference defaults (already true) and behavior. Existing compact binary settings cards were already present; use white thumbs in both switch states.
- Derive diagnostic headings from appVersionLabel and name the APK with vc63/build64.

Exact modified files (relative to project root):
app/src/main/java/com/bikemesh/ridemesh/mesh/LobbyNode.kt
app/src/main/java/com/bikemesh/ridemesh/mesh/MeshNode.kt
app/src/main/java/com/bikemesh/ridemesh/transport/WifiAwareWireProtocol.kt
app/src/main/java/com/bikemesh/ridemesh/MainActivity.kt
app/src/main/java/com/bikemesh/ridemesh/offline/NearbyClusterTransport.kt
app/src/main/java/com/bikemesh/ridemesh/offline/OfflineMeshController.kt
app/build.gradle.kts

A unified diff is included as `VC63-CHANGES.patch` in the source ZIP.

## Build and verification

| Gate | Result |
|---|---|
| Source review/diff | Completed; seven source/build files modified |
| :app:compileDebugKotlin | BLOCKED before compiler startup |
| :app:assembleDebug | BLOCKED before build startup |
| Simulated/unit tested | NOT RUN |
| Device tested | NOT RUN |
| Field tested | NOT RUN |

Both Gradle commands exit 1 while fetching gradle-8.13-bin.zip with `java.net.SocketException: Network is unreachable`. Java 17 is installed; no Android SDK or cached Gradle distribution was found. No Kotlin/Android compiler warnings or errors were produced because compilation never began. Both logs are included. No APK was generated; an APK hash is therefore unavailable.

On your Windows Android Studio machine, extract the project into a separate folder and open that folder. Do not overwrite production-vc25-billing8. If integrating into your existing repository, use only offline-mesh-v1 and review the supplied patch first.

From its project root, use PowerShell:

```powershell
.\gradlew.bat :app:compileDebugKotlin
.\gradlew.bat :app:assembleDebug
```

Only after both succeed, the expected APK is:
`app/build/outputs/apk/debug/RideMesh-android-v1.0.33-vc63-build64-debug.apk`

Install that SAME APK on both phones. Keep existing app data/preferences if the signing key permits an update; a signing mismatch requires the original debug key or a separate test installation strategy. Verify Settings shows build 64 on both devices.

## First device test — stop at this checkpoint

1. Place Poco and Xiaomi about 1–2 metres apart. Open RideMesh on both and end any existing ride.
2. Enable Wi-Fi, Bluetooth, and Location on both. Grant microphone, Nearby Devices and requested location permissions.
3. Xiaomi: stay connected to Wi-Fi with validated Internet. Poco: mobile data OFF and disconnect from Internet-providing Wi-Fi, but leave its Wi-Fi radio ON. Verify Poco truly has no Internet.
4. Select AUTO and NORMAL on both. Start/join the same code, e.g. TEST63. Do not use FIND NEARBY during the active ride; share the code/QR.
5. Wait 30–60 seconds. Copy diagnostics from BOTH phones. Check the same service ID and ride token, P2P_CLUSTER(HYBRID), NON_DISRUPTIVE, and no recurring discovery-stop cycle.
6. Required: Direct links 1, Reachable riders 2, Maximum hops 1. Advertising/discovery should remain available below cluster capacity. Check endpoint-found, request, L2 and identity progress in logs.
7. Unmute both phones. Test speech in each direction individually, then simultaneously. Xiaomi must retain Wi-Fi Internet. Counters alone do not prove audible speech.
8. If either direction fails, stop here and provide both full diagnostic reports plus logcat around ride start. If discoveryPending remains true for over 30 seconds, report that too; do not interpret it as active discovery.

Optional log capture from the Android SDK platform-tools directory:

```powershell
adb devices
adb -s DEVICE_SERIAL logcat -v threadtime > RideMesh-build64-device.log
```

Start logging before joining. Use Ctrl+C to finish. Use each phone's actual serial and a separate filename.

## Preserved and deferred work

Per the supplied test-order requirement, SFU, TURN, audio mixing/injection, bridge election, mute/focus handling, codec and bounded audio queues were not rewritten before the two-phone checkpoint is proven. No Cloudflare worker/API changes were made.

Source review found the runtime imports `audio/HybridSfuAudioBridge.kt`; the similarly named transport class is not the imported bridge. InternetNode registers capture-buffer injection and playback-sample callbacks. Callback registration alone does not establish safe or audible bridging.

Remaining risks/gates:

- NON_DISRUPTIVE can offer lower bandwidth; voice quality/latency needs the actual radios and devices.
- Nearby exposes task acceptance, not continuous RF scanning telemetry. Discovery flags represent successful API starts until a known stop, not proof that radio scanning is healthy. The patch intentionally does not repeatedly reset a healthy-looking scan. A never-completing Play Services start task requires further diagnosis.
- Initial discovery failure may still be device permissions, radio/location state, Play Services, strategy mismatch with an older installed APK, or another lifecycle path. None can be excluded by compilation.
- Existing lifecycle/payload callbacks outside start advertising/discovery do not all carry generation tokens. This is a targeted patch, not a complete transport lifecycle rewrite.
- Bridge eligibility still depends on SFU connectivity; AUTO already forces SFU. Verify session bootstrap and PRIMARY only after Test 1.
- MeshNode currently passes provider callbacks into the controller at construction. Later reassignment on handover may not reach the existing controller. Review/fix with the failover checkpoint; no failover success is claimed.
- The PCM bridge mixes sources. Original packet IDs/origin identity cannot simply survive the SFU PCM crossing; full packet-level duplicate/loop protection and six-rider split-brain behavior are NOT established by this package.
- Existing election has a lease and deterministic ID ordering; convergence, hysteresis and role flapping remain unverified.
- The full requested hybrid diagnostic schema, six-rider behavior, bridge counters, and per-origin protection are not certified or completed here. Subsequent bridge work is gated on the required two-device test.

After Test 1 succeeds, continue in the requested order: PRIMARY election, one remote online rider, backup bridge, Internet-loss failover, then six riders. Each needs real-device audio confirmation.
