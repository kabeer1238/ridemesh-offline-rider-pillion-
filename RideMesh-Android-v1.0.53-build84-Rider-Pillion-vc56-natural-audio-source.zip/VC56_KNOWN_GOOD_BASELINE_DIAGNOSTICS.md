# RideMesh Android vc56 — Known-Good Baseline Diagnostics

Base: user-tested Claude `RideMesh-Android-vc55-Direct-Link-Fix-source.zip`.

## Rule
The vc55 offline audio and transport behavior is intentionally preserved. vc56 adds read-only diagnostics and build identification only.

Unchanged behavior includes:
- Nearby `P2P_POINT_TO_POINT` strategy.
- `ConnectionType.DISRUPTIVE`.
- One direct peer / no relay.
- 20 ms, 16 kHz mono capture.
- 4 frames per transport payload.
- In-flight limit of 3.
- AUTO codec policy: PCM on HIGH Nearby bandwidth, Opus otherwise.
- Existing burst-aware jitter buffer and AudioTrack playout logic.

## Added diagnostics
- Nearby payload completion latency average/max.
- Completion cadence/gap average snapshot and max.
- L2 link age and identity-ready age.
- Age of the most recent bandwidth report.
- Time from L2 connect to first HIGH bandwidth report.
- TX/RX bundle rates compared with nominal 12.5 payloads/s.
- Current receive-buffer sources, primed sources, queued frames/ms, target prime, jitter EWMA and oldest buffered-frame age.

No Google Play Billing dependency is added.
