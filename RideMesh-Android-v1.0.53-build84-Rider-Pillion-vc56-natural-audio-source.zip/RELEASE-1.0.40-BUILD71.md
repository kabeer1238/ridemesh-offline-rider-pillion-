# RideMesh Android 1.0.40 • Build 71 — Release Candidate

## Customer-facing cleanup
- Settings now shows only rider profile, app version, Automatic connection, Battery Smart, Voice Detection, profile editing and support.
- Removed customer-facing test role, online engine, TURN, ICE, SFU, App Check and engineering controls from Settings.
- Release always resets hidden 3-rider lab role to NORMAL so an old tester preference cannot alter production behavior.
- Rider screen no longer advertises an 8-rider maximum.
- Version name is customer-facing `1.0.40`; internal vc labels are not in the version string.

## Rider-count change
- Removed the Android InternetNode hard stop at 7 remote riders (8 total).
- SFU room presence can now accept more than 8 riders.
- This removes the app-imposed eight-rider cap; it does NOT claim unlimited field-validated capacity. Device CPU, bandwidth, SFU subscription behavior and offline Nearby topology still need load testing.
- Offline direct mode still has its own topology constraints; this change is primarily for SFU-backed online groups.

## Preserved
- vc69 hybrid/SFU hard-mute fix.
- vc68 hybrid vc56-style media handling.
- vc66/vc67 fast offline↔online handover logic.
- Automatic mode continues to force the proven SFU path when Internet is available.

## Release blockers still to verify
- Full Android compile/signing and real-device smoke test.
- 9+ rider SFU load test before making a public capacity claim.
- Current non-SFU iOS build is not SFU-compatible for voice; iOS needs the matching SFU transport for mixed Android/iOS release groups.
- Billing/subscription code in this branch remains intentionally disabled from the older diagnostic baseline; restore/verify Play Billing before store release if paid access is required.
