# RideMesh Android vc55 — Direct-Link Audio Fix

Version 1.0.25 • versionCode 55 • APK: `RideMesh-android-v1.0.25-vc55-direct-link-<type>.apk`

Builds on vc54 (one direct peer, no relay, billing removed). **Install on both phones** — the
audio packet format changed (RMD1 → RMD2) and vc54/vc55 cannot talk to each other.

## What vc54 showed

- Link healthy: 1 direct link, 0 reconnects, 0 send failures.
- The Nearby link carried only ~15–18 audio payloads/s (~80–90 kbit/s). Raw PCM needs 50/s (256 kbit/s).
- The sender queued without limit: 2412 frames pending on one phone ≈ 48 s of delay.
- vc54's "missing" counter was measured against the playout position, not the last received
  frame, so it over-counted heavily. A simulation with zero packet loss reported thousands of
  "missing" frames. Treat vc54 "missing" numbers as invalid.

## What vc55 changes

| Area | vc54 | vc55 |
|---|---|---|
| Sending | every frame sent immediately, unbounded | max **3 payloads in flight**; when full, new audio is **dropped, not queued** |
| Payload size | 1 frame (20 ms) per payload, 50/s | **4 frames (80 ms)** per payload, 12.5/s |
| Opus bitrate | 32 kbit/s (unused in vc54) | 24 kbit/s |
| Codec | raw PCM always | **AUTO**: raw PCM only when Nearby reports HIGH bandwidth, **Opus** otherwise |
| Nearby strategy | P2P_CLUSTER | **P2P_POINT_TO_POINT** (one-peer test only) |
| Wi-Fi upgrade | default | requestConnection uses **ConnectionType.DISRUPTIVE** |
| Bandwidth | not reported | `onBandwidthChanged` logged and shown in Status |
| Receiver buffer | per-frame jitter, 200 ms cap | burst-aware jitter, headroom ≥ one payload + 2 frames, 300 ms cap |
| Missing counter | vs playout position (wrong) | vs highest received sequence |
| Mute / pause | — | partial batch discarded after a >60 ms capture gap |

## Files

- `offline/DirectAudioLink.kt` (new): `DirectAudioBatch` (RMD2 format), `DirectFrameBatcher`,
  `InFlightGate`, `DirectCodecPolicy`. Pure Kotlin, covered by `DirectAudioLinkTest`.
- `offline/NearbyClusterTransport.kt`: strategy, DISRUPTIVE option, bandwidth callback,
  `sendDirectAudio(bytes, frameCount)` with backpressure, new stats.
- `offline/OfflineMeshController.kt`: batching, adaptive codec, codec-tagged frames,
  in-order decode + concealment (`decodeForPlayout`), added-delay metric, new report.
- `audio/AudioEngine.kt`: burst-aware jitter buffer, corrected missing/reordered counters.
- `MainActivity.kt`: offline mode installs the controller's decoder (was `null`), report text.
- `mesh/MeshNode.kt`, `app/build.gradle.kts`: labels and version.

## Tuning knobs

- `OfflineMeshController.CODEC_MODE` — `AUTO` (default), `FORCE_PCM`, `FORCE_OPUS`.
- `OfflineMeshController.FRAMES_PER_BATCH` — default 4.
- `NearbyClusterTransport.DIRECT_MAX_IN_FLIGHT` — default 3.
- `NearbyClusterTransport.DIRECT_STRATEGY` — set back to `Strategy.P2P_CLUSTER` for mesh work.
- `OpusVoiceCodec.TARGET_BITRATE_BPS` — now 24 kbit/s (was 32) for margin on LOW/MEDIUM links.

## Test procedure

1. Both phones: Wi-Fi ON (no network needed), Location ON, Bluetooth ON, battery
   restriction for RideMesh set to "No restrictions" (MIUI/HyperOS).
2. Same ride code, phones close together. Wait for DIRECT LINK LOCKED.
3. Talk continuously for 30 s from each side, then open Status on both phones and COPY LOG.

## Reading the new Status report

- `Nearby bandwidth` — HIGH means Wi-Fi upgrade worked (raw PCM used). LOW/MEDIUM means Opus.
- `now sending` — codec in use right now.
- `max in-flight … (limit 3)` — must never exceed the limit.
- `Congestion: … (x% of offered audio)` — near 0% is good. High % with PCM means the link
  is too slow for PCM. High % with Opus means the link itself is failing.
- `added delay` — must stay under ~300 ms. vc54 grew without limit.
- `PCM DIAG RX … missing` — now real loss (sender congestion drops show up here too).
- `TX packet gap` — ~80 ms is normal now (one payload per 4 frames).

Android Logcat tag: `RideMeshVC55`.
