# RideMesh Android vc77 / Build 77 — Voice Detection true bypass fix

Version: 1.0.46-vc77-vad-bypass-fix

## Scope

This is a narrow follow-up to vc76. The Android diagnostic could report `TX gate: BYPASS` while `gate gain` still showed `0.03` after Voice Detection was switched OFF.

## Change

When Voice Detection is disabled, `OnlineSileroProcessor` now immediately resets the custom RideMesh VAD envelope to unity gain (`1.00`) and clears residual onset/speech/quiet timing state. The WebRTC capture graph remains running and its normal AEC/NS/AGC processing is unchanged.

Expected diagnostic with Voice Detection OFF:

```text
Online Silero observer: OFF • WebRTC unchanged
TX gate: BYPASS
gate gain: 1.00
```

Voice Detection ON keeps the vc75/vc76 natural-intercom behavior: fast onset protection, Silero confirmation, 1.2 s conversational hold, and smooth attenuation toward the 3% comfort floor.

No intentional changes were made to Cloudflare SFU/TURN, AUTO SFU synchronization, Nearby/offline media, hybrid bridge injection, hard mute, billing, or Firebase entitlement logic.

## Important

A song or steady tone may still be reduced by WebRTC voice-processing (AEC/NS/AGC). Voice Detection OFF means RideMesh's custom Silero gate is bypassed; it does not disable WebRTC speech processing.
