# START HERE — vc68 / Build 69

This build repairs the hybrid media path after the Build 68 field report that offline↔online voice was nowhere near vc56 quality.

Read `VC68_HYBRID_VC56_MEDIA.md` first.

Build identity: `1.0.38-vc68-hybrid-vc56-media` / versionCode `69`.
