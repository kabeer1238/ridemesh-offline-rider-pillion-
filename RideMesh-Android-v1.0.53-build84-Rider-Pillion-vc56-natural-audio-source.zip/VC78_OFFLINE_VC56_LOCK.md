# RideMesh Android vc78 / Build 78 — Offline vc56 lock

Version: `1.0.47-vc78-offline-vc56-lock`

Base: vc77 / Build 77.

## Problem addressed
Two Android phones could remain on the hybrid Nearby profile while AUTO still considered
the session Internet-side, even when the Cloudflare SFU media path was not actually usable.
That profile uses P2P_CLUSTER + NON_DISRUPTIVE and is not the user-confirmed vc56 offline baseline.

## Change
The local Nearby profile now permits HYBRID_CLUSTER only while the SFU media path is
actually connected (`isSfuConnectedForBridge() == true`). Otherwise it selects VC56_DIRECT.

Therefore sustained Android-to-Android offline voice uses:
- P2P_POINT_TO_POINT
- DISRUPTIVE connection type
- one direct peer
- 16 kHz mono / 20 ms frames
- 4 frames per Nearby payload (80 ms)
- RAW PCM16 on HIGH Nearby bandwidth, Opus fallback otherwise
- max 3 direct payloads in flight, drop-not-queue backpressure
- existing vc56 burst-aware jitter buffer and 20 ms AudioTrack playout clock

## Intentionally unchanged
No tuning was made to AudioEngine, OfflineMeshController media batching/codec policy,
Nearby direct-send gate, Opus codec, online SFU/TURN, vc77 VAD bypass, hard mute, billing,
or Firebase entitlement logic. This is a transport-profile selection fix, not an audio rewrite.

## Expected offline diagnostics
`Local mesh profile: VC56_DIRECT`
`P2P_POINT_TO_POINT`
`DISRUPTIVE`
`Direct links: 1`
`Relay packets: 0`
`Maximum hops: 1`

If a sustained offline test still sounds jittery while those exact diagnostics are present,
collect both phones' offline reports before changing audio constants; the next target should be
measured Nearby completion cadence / RX late frames / underruns, not speculative codec tuning.
