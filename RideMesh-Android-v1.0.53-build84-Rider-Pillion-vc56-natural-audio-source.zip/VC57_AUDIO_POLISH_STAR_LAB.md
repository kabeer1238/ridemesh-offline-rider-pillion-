# RideMesh Android vc57 — Audio Polish + 3-Rider STAR Lab

Base: confirmed-good vc56.

## Normal mode
Preserves vc56 P2P_POINT_TO_POINT direct behavior. HIGH bandwidth still uses RAW PCM16. Non-HIGH Opus is raised from 24 to 32 kbit/s with in-band FEC and 10% expected packet loss hint.

## Experimental 3-rider lab
Use existing Mesh Lab Role selector:
- Device 1: A (hub)
- Device 2: B (spoke)
- Device 3: C (spoke)
All three use the same ride code. A advertises P2P_STAR; B/C discover and connect to A. A forwards B audio to C and C audio to B while playing both locally. Hub local audio is sent to both spokes.

This STAR mode is experimental and is not yet the final 6+ rider mesh. Do not use NORMAL for a 3-device test.

## Protected behavior
20 ms capture, 4-frame/80 ms batching, DISRUPTIVE upgrade, bounded real-time sending and existing jitter/playout logic remain in place.
