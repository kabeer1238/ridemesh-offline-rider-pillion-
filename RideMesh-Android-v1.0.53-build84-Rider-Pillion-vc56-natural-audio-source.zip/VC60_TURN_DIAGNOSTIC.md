# RideMesh vc60 — FORCE TURN + Maximum Diagnostics

- Settings > Online TURN engineering > AUTO / FORCE TURN
- FORCE TURN applies relay-only ICE to newly created WebRTC peers.
- Leave and rejoin the ride after changing the mode.
- Ride Status now shows TURN configuration/status, selected ICE transport, signaling, peers, SDP/ICE counts, reconnects, codec, errors, peer states, RTT, jitter, packet loss and packet counters.
- COPY MAXIMUM DIAGNOSTIC LOG copies the full report.
- Version 1.0.30 / build 60.

Build note: compilation was attempted but this environment cannot download Gradle 8.13 because services.gradle.org is unreachable. Build is not claimed verified.
