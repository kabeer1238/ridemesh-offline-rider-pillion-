# RideMesh Android vc76 / Build 76 — AUTO SFU synchronization

Version: 1.0.45-vc76-auto-sfu-sync

## Why
Build 75 field logs showed an Android rider in `AUTO • DIRECT P2P` while the iPhone in the same ride was already `AUTO • SFU`. Android repeatedly sent P2P offers while iOS published an SFU track, so both saw each other but had no shared media engine.

## Changes
- Production ADAPTIVE/AUTO now selects Cloudflare SFU as soon as total group size reaches 2.
- Direct P2P is retained for explicit engineering/non-adaptive modes only.
- Receiving an `SFU_TRACK` signal while still in adaptive P2P immediately promotes Android to SFU, closes stale P2P peer connections, and subscribes to the advertised SFU track.
- Existing SFU backend API, TURN handling, vc75 natural VAD, Hybrid Bridge, hard mute, Nearby/offline path, billing and Firebase entitlement code are otherwise unchanged.

## Expected two-device Android+iOS result
Both diagnostics should report `AUTO • SFU`, each should publish one local track and subscribe to one remote track, and Android should no longer show repeated `OFFER RETRANSMITTED`.

## Verification status
Source/static patch only in this environment. Not Gradle-compiled or device-tested.
