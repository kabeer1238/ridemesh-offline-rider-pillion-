# RideMesh Android vc80 — Offline 40 ms packetization

Version: 1.0.49-vc80-offline-40ms-packets
Build: 80

## Why
vc79 field data improved receiver continuity dramatically (late 496→4; underruns/rebuffers 62→6) but audible jitter remained. The direct Nearby link was healthy (0 send failures, 0 congestion drops, ~9 ms average completion), while 80 ms audio bursts still showed TX gaps up to 332 ms and RX gaps up to 725 ms.

## Narrow change
- Preserve vc79 adaptive receiver/jitter/PLC behavior unchanged.
- Change VC56_DIRECT batching from 4 x 20 ms (80 ms, nominal 12.5 payload/s) to 2 x 20 ms (40 ms, nominal 25 payload/s).
- Keep PCM16 16 kHz mono on HIGH and Opus fallback otherwise.
- Keep P2P_POINT_TO_POINT, DISRUPTIVE and max 3 direct payloads in flight.
- Raise partial-batch scheduler-gap tolerance from 120 ms to 160 ms; codec or sequence discontinuities still flush immediately. With two-frame packets, at most one 20 ms frame is held in a partial batch.
- No SFU/TURN/VAD/AUTO-selection changes.

## Field test
Install the same Build 80 on both phones. Test continuous speech for 1–2 minutes. Compare audible continuity plus: rebuffers, underruns, late, partial-batch discards, TX/RX fps, bundle rate (target ~25/s during continuous active capture), completion latency, TX/RX packet gap, and perceived latency.

## Verification status
Source/static verification only in this environment. A real Android/Gradle compile and device test remain required.
