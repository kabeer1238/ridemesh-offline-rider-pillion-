# RideMesh Android vc47 — App Check Diagnostic

- versionCode 47 / versionName 1.0.18
- Keeps Play Integrity App Check and enforceAppCheck backend behavior unchanged.
- Before reserveInfluencerCode, explicitly requests an App Check token.
- Displays only safe diagnostics: token acquisition success, token length, JWT segment count, or exception type/message.
- Never displays or logs the token itself.
- Expected valid JWT structure: 3 dot-separated segments.
- Rider-facing Redeem Code wording retained.
