# RideMesh Android vc74 / Build 74 — iOS vc50/vc52 parity candidate

Based on uploaded Build 73 adaptive P2P/SFU source.

Changes:
- Local-microphone-only Silero TX gate at the existing ADM PCM observation point.
- 160 ms energy onset provisional opening to protect first consonants.
- Two Silero-positive decisions confirm speech; 400 ms speech hangover.
- 250 ms quiet re-arm prevents continuous noise from repeatedly holding the onset gate open.
- Gate executes before HybridSfuAudioBridge injection, so offline riders forwarded by a PRIMARY bridge are not VAD-gated.
- Existing hard mute remains authoritative downstream.
- Added SFU TX/RX packet-progress age diagnostics.
- Added 1.5 s coalesced network-handover grace; a connected SFU with recent packet progress is preserved rather than torn down because of a transient Android network callback.
- Existing queued SFU subscriptions in Build 73 were already present and are preserved.

Not changed:
- vc56-derived Nearby media/jitter behavior
- Opus/WebRTC codec path
- Hybrid bridge injection/mixing
- TURN/SFU backend API
- Billing/Firebase entitlement files

Verification: source/static checks only in this environment. Android SDK/Gradle build may require Android Studio machine.
