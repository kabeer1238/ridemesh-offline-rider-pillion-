# RideMesh vc69 / build 70 — hard mute fix on hybrid/SFU phones

Version: `1.0.39-vc69-hard-mute-vc56-media`  
Build: `70`

## Field problem

On some Android phones the MUTE button changed the UI but the local microphone could still be heard, often as hiss/noise. This was specific to the newer hybrid/SFU path; the vc56 offline `AudioEngine` mute already drops microphone frames before transport.

## Root cause found in build 69 source

`InternetNode` intentionally keeps the WebRTC local audio track enabled while hybrid bridging is configured so a PRIMARY bridge can carry offline riders to the SFU even when the bridge rider mutes their own microphone.

That design relies on `audio/HybridSfuAudioBridge.processCapture()` to remove the bridge rider's real microphone from the WebRTC capture buffer.

The build 69 implementation did not actually do that:

- `setLocalMicEnabled(false)` stopped the mic from being queued toward Nearby, but
- the WebRTC capture buffer itself was left untouched when no offline frame was injected,
- and when an offline frame was injected it was mixed with `original[i]`, which was still the real microphone,
- plus STANDBY/non-primary phones returned before any PCM gating.

Therefore the UI could say `MIC MUTED` while the WebRTC/SFU track still transmitted the real mic. That also explains noise/hiss on affected phones.

## vc69 fix

The hybrid ADM capture callback now applies a digital hard-mute gate before bridge-role logic:

1. If user mute is ON and capture is PCM16, every captured microphone sample is overwritten with zero.
2. The rule applies to PRIMARY and STANDBY/non-primary phones.
3. A muted PRIMARY bridge keeps its WebRTC track alive only as a carrier for offline-rider audio.
4. Offline audio is mixed onto digital silence, not onto the bridge rider's microphone.
5. `setLocalMicEnabled(false)` still clears queued local-mic material, so speech recorded before/while mute cannot leak later.
6. vc56 Nearby packetization/jitter/playout and build69 hybrid media changes are otherwise untouched.

## New diagnostic

Hybrid bridge diagnostics now include:

`hardMute cb=<callbacks> bytes=<bytes zeroed>`

While a muted hybrid/SFU phone is running, `cb` and `bytes` must keep increasing. This proves that the actual WebRTC capture PCM is being gated, not merely the UI state.

## Expected behavior

- Muted ordinary online rider: no local microphone speech/noise should reach peers.
- Muted PRIMARY bridge: its own mic is silent, but offline riders can still cross the bridge to the SFU.
- Muted STANDBY bridge: local capture is hard-zeroed too.
- Offline vc56 direct mode: existing `AudioEngine.setUserMuted()` behavior remains unchanged.

## Verification status

Source diff and archive integrity checked. Full Android compile/device test was not performed in this environment because the required Android/Gradle toolchain is not available here. Do not treat this as field-verified until tested on the affected phones.
