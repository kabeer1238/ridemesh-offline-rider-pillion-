# START HERE — RideMesh vc69 / Build 70

This build is based on vc68/build69 hybrid-vc56-media and fixes the hybrid/SFU mute leak.

Read `VC69_HARD_MUTE_FIX.md` first.

Primary validation: mute each affected Android phone while another rider listens. In hybrid/SFU diagnostics, `hardMute cb` and `bytes` must increase while muted, and no local mic speech/hiss should be audible.
