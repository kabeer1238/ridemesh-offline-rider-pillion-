# RideMesh vc70 Adaptive Transport — Build 73

Production AUTO routing policy:
- No validated Internet: Android Nearby offline mesh remains active.
- 2 total riders online: direct WebRTC P2P. TURN remains ICE fallback where required.
- 3+ total riders: Cloudflare Realtime SFU.
- Hybrid groups count Nearby/offline members toward the 3+ threshold, preserving the SFU bridge path.
- When group size crosses the threshold, the online engine migrates between direct P2P and SFU.

Diagnostics expose AUTO • DIRECT P2P or AUTO • SFU.

This is a test candidate and must be field-tested before production rollout.
