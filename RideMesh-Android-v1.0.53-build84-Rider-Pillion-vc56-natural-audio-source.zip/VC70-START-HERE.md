# RideMesh Android vc70 — Adaptive Transport Test Candidate

Version 1.0.42 • Build 73

AUTO policy:
- 2 total riders: direct WebRTC P2P (TURN remains ICE fallback when direct ICE cannot connect).
- 3+ total riders: Cloudflare Realtime SFU.
- No validated Internet: existing Android Nearby offline mesh.
- Hybrid groups include local Nearby riders in the group-size decision so 3+ mixed offline/online groups promote to SFU for bridge operation.

Test before production:
1. Two Internet phones: diagnostics must show AUTO • DIRECT P2P and two-way voice.
2. Add third rider: all clients should migrate to AUTO • SFU without app restart and retain voice.
3. Remove third rider: remaining pair should return to direct P2P.
4. Drop Internet: Nearby offline voice must continue/recover.
5. Restore Internet and add 3+ total riders: SFU must reconnect while local mesh remains available for hybrid bridging.
6. Verify mute, call priority, music ducking, Firebase redeem, Google Play Billing, and map/location behavior are unchanged.

Build verification note:
The source was statically repacked in the ChatGPT environment. Gradle compilation could not run because the environment could not reach services.gradle.org to download Gradle 8.13. Build this package in Android Studio before device testing or store upload. Do not treat it as production-proven until it compiles and passes the tests above.
