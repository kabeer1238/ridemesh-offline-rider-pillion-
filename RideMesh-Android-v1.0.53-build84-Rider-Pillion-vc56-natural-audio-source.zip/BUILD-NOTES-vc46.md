# RideMesh Android vc46 / 1.0.17

- versionCode 46, versionName 1.0.17.
- Rider-facing **Influencer Code** wording changed to **Redeem Code**.
- Success message: **Code verified! Enjoy RideMesh free for 12 months.**
- Firebase App Check Play Integrity provider is installed during billing-manager initialization before Firebase Functions is first instantiated.
- Firebase Functions instance is lazy to preserve that initialization order.
- Backend callable/collection/offer identifiers remain unchanged for compatibility (`reserveInfluencerCode`, `finalizeInfluencerRedemption`, `influencerCodes`, `influencer-365`).
- Backend `enforceAppCheck: true` is unchanged.
