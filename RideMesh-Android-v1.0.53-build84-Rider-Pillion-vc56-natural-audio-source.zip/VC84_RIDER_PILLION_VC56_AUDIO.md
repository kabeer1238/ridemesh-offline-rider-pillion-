# vc84 Rider/Pillion – vc56 natural voice profile

This build keeps the Rider/Pillion UI and pairing work from vc80, but restores the offline media cadence that was known-good in vc56.

Changes:
- 20 ms capture frames retained.
- Nearby batching restored to 4 frames / payload (80 ms), as vc56.
- Batch gap restored to 60 ms.
- vc56 adaptive playout targets restored: 60–120 ms.
- vc56 late-packet grace and PLC limits restored.
- vc56 speech pre-roll + hangover sending restored to avoid continuously saturating the Nearby link.
- Codec policy remains AUTO: raw PCM on a lone HIGH-quality direct link, Opus otherwise.
- Rider/Pillion pairing/UI and newer non-audio systems remain in place.

Test priority: two Android phones, Rider/Pillion offline, Internet/mobile data off. Listen for continuity, clicks, speech onset/tail, and natural conversational latency.
