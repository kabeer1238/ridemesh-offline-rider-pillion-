# RideMesh Android vc52 — Offline Stability Lab

Purpose: recover intelligible Android-to-Android offline speech after vc51 broke up in real-device testing.

Changes from vc51:
- Keep continuous 20 ms offline transmit cadence. Voice Detection remains observation-only.
- Restore conservative 60 ms minimum jitter-buffer prime (3 x 20 ms frames).
- Remove vc51 experimental next-packet Opus FEC decode path.
- Disable in-band Opus FEC for this isolation build; packet-loss fallback is decoder PLC.
- Keep 16 kHz mono, 20 ms Opus frames and 32 kbps bitrate.
- Keep adaptive jitter expansion up to 120 ms on unstable links.
- Online WebRTC path is unchanged.

First test: exactly two Android phones, one-hop/direct offline, close together. Compare vc52 against vc51 for intelligibility, breakup, speech onset, and conversational delay. Do not judge multi-hop yet.
