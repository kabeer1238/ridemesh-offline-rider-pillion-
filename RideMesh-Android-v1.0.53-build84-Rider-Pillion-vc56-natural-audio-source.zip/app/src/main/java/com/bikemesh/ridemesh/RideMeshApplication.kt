package com.bikemesh.ridemesh

import android.app.Application
import android.util.Log
import com.bikemesh.ridemesh.diagnostics.AppCheckDiagnostics
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

class RideMeshApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
            AppCheckDiagnostics.logAppIdentity(this)

            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                PlayIntegrityAppCheckProviderFactory.getInstance()
            )
            Log.d("RideMeshAppCheck", "RideMeshAppCheck: Play Integrity provider installed")

            // Startup token check for early Logcat diagnostic
            AppCheckDiagnostics.forceTokenRequest(forceRefresh = true) { success, msg ->
                Log.d("RideMeshAppCheck", "RideMeshAppCheck: Startup token test complete (success=$success)")
            }
        } catch (t: Throwable) {
            Log.e("RideMeshAppCheck", "RideMeshAppCheck: Application onCreate error", t)
        }
    }
}
