package com.bikemesh.ridemesh.transport

import android.annotation.SuppressLint
import com.bikemesh.ridemesh.audio.OnlineSileroProcessor
import com.bikemesh.ridemesh.audio.HybridSfuAudioBridge
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioDeviceCallback
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.random.Random
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Beta4 Internet voice engine.
 *
 * MQTT/TLS is used only for room presence plus SDP/ICE signaling. Microphone audio is never
 * published through MQTT in Beta4. Voice is a WebRTC audio track, which negotiates Opus and uses
 * WebRTC NetEq jitter handling / packet-loss recovery over encrypted SRTP media.
 *
 * Each rider creates a direct PeerConnection to each other rider in the same ride code. This is a
 * practical 2-6 rider Beta architecture and removes all Nearby/offline/bridge timing from the
 * production voice path. STUN is included for NAT traversal. Production TURN credentials are not
 * hard-coded into this public Beta yet, so diagnostics explicitly report TURN as not configured.
 *
 * The old InternetPacket encode/decode helpers remain only for source/unit-test compatibility.
 */
class InternetNode(
    private val listener: Listener,
    private val context: Context? = null,
) {
    interface Listener {
        fun onInternetState(connected: Boolean, message: String)
        fun onInternetAudio(sourceId: String, sequence: Int, timestampMs: Long, audio: ByteArray)
        fun onInternetPeerCount(count: Int)
        fun onInternetAudioStatus(message: String) = Unit
        fun onInternetRiderLocation(location: RiderLocation) = Unit
    }

    data class RiderPeer(
        val id: UUID,
        val riderName: String,
        val deviceName: String,
        val lastSeenMs: Long,
        val qualityBars: Int = 4,
        val qualityLabel: String = "Good",
    ) {
        val displayName: String
            get() = riderName.ifBlank {
                deviceName.ifBlank { "Rider ${id.toString().take(4).uppercase()}" }
            }
    }

    data class RiderLocation(
        val riderId: UUID,
        val displayName: String,
        val latitude: Double,
        val longitude: Double,
        val speedKmh: Float,
        val heading: Float,
        val timestampMs: Long,
        val connectionQuality: String,
        val phoneNumber: String = "",
    )

    data class Diagnostics(
        val signalingConnected: Boolean,
        val voicePeersConnected: Int,
        val knownRiders: Int,
        val offersSent: Int,
        val answersSent: Int,
        val candidatesSent: Int,
        val reconnects: Int,
        val lastError: String,
        val peerStates: String,
        val codec: String = "Opus / WebRTC",
        val turnConfigured: Boolean = false,
        val turnMode: String = "AUTO",
        val selectedIceTransport: String = "UNKNOWN",
        val turnStatus: String = "NOT LOADED",
        val detailedIceStats: String = "No ICE statistics yet",
        val onlineEngine: String = "P2P/AUTO",
        val sfuSessionId: String = "",
        val sfuState: String = "OFF",
        val sfuIceState: String = "NEW",
        val sfuPeerConnectionState: String = "NEW",
        val sfuLocalTrackName: String = "",
        val sfuRemoteTracks: Int = 0,
        val sfuPublishCalls: Int = 0,
        val sfuSubscribeCalls: Int = 0,
        val sfuRenegotiations: Int = 0,
        val sfuReconnects: Int = 0,
        val sfuPacketsSent: Long = 0L,
        val sfuPacketsReceived: Long = 0L,
        val sfuLastTxPacketAgeMs: Long = -1L,
        val sfuLastRxPacketAgeMs: Long = -1L,
        val sfuRttMs: Double = -1.0,
        val sfuJitterMs: Double = -1.0,
        val sfuLossPercent: Double = -1.0,
        val sfuLastError: String = "",
        val hybridBridgeDiagnostics: String = "Hybrid bridge: OFF",
    )

    private data class PeerSession(
        val id: UUID,
        val pc: PeerConnection,
        val initiator: Boolean,
        val pendingCandidates: MutableList<IceCandidate> = CopyOnWriteArrayList(),
        @Volatile var remoteDescriptionSet: Boolean = false,
        @Volatile var connected: Boolean = false,
        @Volatile var state: String = "NEW",
        @Volatile var lastOfferMs: Long = 0L,
        @Volatile var lastStateChangeMs: Long = System.currentTimeMillis(),
        @Volatile var reconnectScheduled: Boolean = false,
        @Volatile var measuredQualityBars: Int = 3,
        @Volatile var measuredQualityLabel: String = "Good",
        @Volatile var lastRttMs: Double = -1.0,
        @Volatile var lastJitterMs: Double = -1.0,
        @Volatile var lastLossPercent: Double = -1.0,
        @Volatile var lastPacketsLost: Long = -1L,
        @Volatile var lastPacketsReceived: Long = -1L,
        @Volatile var audioQualityTier: Int = 0,
    )

    private val appContext: Context?
        get() = context?.applicationContext

    private val nodeId: UUID by lazy {
        val ctx = appContext
        if (ctx == null) {
            UUID.randomUUID()
        } else {
            val prefs = ctx.getSharedPreferences("ridemesh", Context.MODE_PRIVATE)
            val saved = prefs.getString(WEBRTC_NODE_ID_KEY, null)
            runCatching { UUID.fromString(saved) }.getOrElse {
                UUID.randomUUID().also { generated ->
                    prefs.edit().putString(WEBRTC_NODE_ID_KEY, generated.toString()).apply()
                }
            }
        }
    }

    private val running = AtomicBoolean(false)
    private val signalingConnected = AtomicBoolean(false)
    private val reportedPeerCount = AtomicInteger(-1)
    private val offersSent = AtomicInteger(0)
    private val answersSent = AtomicInteger(0)
    private val candidatesSent = AtomicInteger(0)
    private val reconnects = AtomicInteger(0)
    private val healthStatsPending = ConcurrentHashMap.newKeySet<UUID>()
    private val mediaFocusRecoveryPending = AtomicBoolean(false)
    private val smartDuckStatsPending = AtomicBoolean(false)

    private val peers = ConcurrentHashMap<UUID, RiderPeer>()
    private val sessions = ConcurrentHashMap<UUID, PeerSession>()
    private val outputLock = Any()

    @Volatile private var riderName: String = "Rider"
    @Volatile private var deviceName: String = "Android device"
    @Volatile private var baseTopic: String = ""
    @Volatile private var presenceTopic: String = ""
    @Volatile private var signalTopic: String = ""
    @Volatile private var locationTopic: String = ""
    @Volatile private var subscriptionTopic: String = ""
    @Volatile private var socket: SSLSocket? = null
    @Volatile private var output: BufferedOutputStream? = null
    @Volatile private var worker: Thread? = null
    @Volatile private var lastError: String = ""
    @Volatile private var reconnectAttempt = 0
    @Volatile private var userMuted = false
    @Volatile private var focusPaused = false
    @Volatile private var audioRoute = "AUTO"
    @Volatile private var audioStatus = "WEBRTC AUDIO READY"
    @Volatile private var connectionHealthThread: Thread? = null
    @Volatile private var networkHandoverPending = false
    @Volatile private var lastNetworkHandle = -1L
    @Volatile private var lastNetworkTransport = ""
    @Volatile private var smartDuckThread: Thread? = null
    @Volatile private var lastVoiceActivityMs = 0L
    @Volatile private var musicVolumeBeforeDuck: Int? = null
    @Volatile private var musicDuckTargetVolume: Int? = null
    @Volatile private var musicDucked = false
    private val smartDuckLevelLock = Any()
    private var smartDuckRoundLocalMax = 0.0
    private var smartDuckRoundRemoteMax = 0.0
    private var smartDuckRoundLocalVadKnown = false
    private var smartDuckRoundRemoteVadKnown = false
    private var smartDuckRoundLocalVad = false
    private var smartDuckRoundRemoteVad = false
    @Volatile private var localNoiseFloor = NOISE_FLOOR_INITIAL
    @Volatile private var remoteNoiseFloor = NOISE_FLOOR_INITIAL
    @Volatile private var localSpeechHits = 0
    @Volatile private var remoteSpeechHits = 0
    @Volatile private var noiseCalibrationUntilMs = 0L
    @Volatile private var smartDuckMusicWasActive = false

    @Volatile private var turnIceServers: List<PeerConnection.IceServer> = emptyList()
    @Volatile private var turnCredentialsLoadedAtMs: Long = 0L
    @Volatile private var turnStatus: String = "NOT LOADED"
    private val turnPrefetchInFlight = AtomicBoolean(false)
    @Volatile private var forceTurnForTesting: Boolean = false
    @Volatile private var forceSfuForTesting: Boolean = false
    @Volatile private var adaptiveOnlineEngine: Boolean = false
    @Volatile private var adaptiveGroupSize: Int = 1
    @Volatile private var selectedIceTransport: String = "UNKNOWN"
    @Volatile private var sfuEngine: CloudflareSfuEngine? = null

    /** Hidden engineering controls. Public builds should normally use AUTO. */
    fun setForceTurnForTesting(enabled: Boolean) {
        forceTurnForTesting = enabled
        if (enabled) forceSfuForTesting = false
        if (enabled && turnIceServers.isEmpty()) turnStatus = "FORCE TURN WAITING FOR CREDENTIALS"
    }

    fun setForceSfuForTesting(enabled: Boolean) {
        forceSfuForTesting = enabled
        if (enabled) forceTurnForTesting = false
    }

    fun setOnlineEngineModeForTesting(mode: String) {
        when (mode.uppercase()) {
            "FORCE_SFU" -> { adaptiveOnlineEngine = false; forceSfuForTesting = true; forceTurnForTesting = false }
            "FORCE_TURN" -> { adaptiveOnlineEngine = false; forceSfuForTesting = false; forceTurnForTesting = true }
            "ADAPTIVE" -> { adaptiveOnlineEngine = true; forceTurnForTesting = false; applyAdaptiveOnlineEngine() }
            else -> { adaptiveOnlineEngine = false; forceSfuForTesting = false; forceTurnForTesting = false }
        }
    }

    /** vc76 production AUTO policy. Once another rider is present, use Cloudflare SFU.
     * This removes cross-platform split-brain where one device selected direct P2P while
     * another selected SFU. P2P remains available only through explicit engineering modes.
     * MainActivity includes Nearby/offline members in groupSize so hybrid groups also stay on SFU. */
    fun setAdaptiveGroupSize(groupSize: Int) {
        adaptiveGroupSize = groupSize.coerceAtLeast(1)
        if (adaptiveOnlineEngine) applyAdaptiveOnlineEngine()
    }

    private fun applyAdaptiveOnlineEngine() {
        val wantSfu = adaptiveGroupSize >= 2
        if (wantSfu == forceSfuForTesting) return
        forceSfuForTesting = wantSfu
        forceTurnForTesting = false
        if (!running.get()) return
        if (wantSfu) {
            closeAllPeerConnections()
            ensureSfuStarted()
            announceSfuTrackIfReady()
            listener.onInternetState(true, "AUTO • SFU • $adaptiveGroupSize RIDERS")
        } else {
            sfuEngine?.close()
            sfuEngine = null
            peers.keys.forEach { ensurePeer(it, allowOffer = true) }
            listener.onInternetState(true, "AUTO • DIRECT P2P • $adaptiveGroupSize RIDERS")
        }
    }

    @Volatile private var onlineSilero: OnlineSileroProcessor? = null
    fun onlineVadDiagnostics(): String = onlineSilero?.diagnostics() ?: "Online Silero: OFF • normal WebRTC"
    fun disableOnlineVad() { onlineSilero?.setEnabled(false) }
    fun setOnlineVadEnabled(enabled: Boolean) { onlineSilero?.setEnabled(enabled) }

    // vc62 hybrid bridge hooks. MainActivity wires these to the local Nearby mesh before start().
    @Volatile private var hybridPrimaryProvider: () -> Boolean = { false }
    @Volatile private var hybridOfflineSender: (ByteArray) -> Unit = { }
    @Volatile private var hybridAudioBridge: HybridSfuAudioBridge? = null
    @Volatile private var hybridBridgeConfigured: Boolean = false

    fun configureHybridBridge(isPrimary: () -> Boolean, sendToOffline: (ByteArray) -> Unit) {
        hybridBridgeConfigured = true
        hybridPrimaryProvider = isPrimary
        hybridOfflineSender = sendToOffline
    }

    fun clearHybridBridgeConfiguration() {
        hybridBridgeConfigured = false
        hybridPrimaryProvider = { false }
        hybridOfflineSender = { }
        hybridAudioBridge?.close()
        hybridAudioBridge = null
        applyVoiceEnabled()
    }

    fun offerHybridOfflinePcm(sourceId: String, pcm16k20ms: ByteArray) {
        hybridAudioBridge?.offerOfflinePcm(sourceId, pcm16k20ms)
    }

    fun hybridBridgeDiagnostics(): String = hybridAudioBridge?.diagnostics() ?: "Hybrid bridge: NOT INITIALIZED"

    private var factory: PeerConnectionFactory? = null
    private var audioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null
    private var audioDeviceModule: JavaAudioDeviceModule? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var recoveryHandler: Handler? = null
    private var audioDeviceCallback: AudioDeviceCallback? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    fun start(rideCode: String, riderName: String, deviceName: String) {
        val ctx = appContext ?: throw IllegalStateException("Android context required for WebRTC voice")
        stop()

        this.riderName = sanitizeIdentity(riderName, "Rider", MAX_RIDER_NAME_BYTES)
        this.deviceName = sanitizeIdentity(deviceName, "Android device", MAX_DEVICE_NAME_BYTES)
        val safeRide = rideCode.trim().uppercase().ifBlank { "RIDE01" }
            .replace(Regex("[^A-Z0-9_-]"), "_")
            .take(32)

        baseTopic = "ridemesh/test/v3/$safeRide"
        presenceTopic = "$baseTopic/presence"
        signalTopic = "$baseTopic/signal"
        locationTopic = "$baseTopic/location"
        subscriptionTopic = "$baseTopic/#"

        lastError = ""
        reconnectAttempt = 0
        selectedIceTransport = "UNKNOWN"
        turnStatus = "LOADING"
        offersSent.set(0)
        answersSent.set(0)
        candidatesSent.set(0)
        reconnects.set(0)

        initializeWebRtc(ctx)
        running.set(true)
        requestAudioFocus()
        selectAudioRoute()
        applyVoiceEnabled()
        registerRecoveryCallbacks(ctx)
        startSmartDucking()
        startConnectionHealthMonitor()

        listener.onInternetState(false, "WEBRTC SIGNALING CONNECTING • OPUS VOICE")
        worker = Thread({ connectionLoop() }, "RideMesh-WebRTC-Signaling").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        val wasRunning = running.getAndSet(false)
        onlineSilero?.close()
        onlineSilero = null
        hybridAudioBridge?.close()
        hybridAudioBridge = null
        if (wasRunning && signalingConnected.get()) {
            runCatching { publishSignal(SignalPacket(nodeId, BROADCAST_ID, SignalType.BYE)) }
        }

        signalingConnected.set(false)
        closeSocket()
        worker?.interrupt()
        worker = null

        sfuEngine?.close()
        sfuEngine = null
        closeAllPeerConnections()
        peers.clear()
        notifyPeerCount(force = true)

        localAudioTrack?.setEnabled(false)
        runCatching { localAudioTrack?.dispose() }
        localAudioTrack = null
        runCatching { audioSource?.dispose() }
        audioSource = null
        runCatching { factory?.dispose() }
        factory = null
        runCatching { audioDeviceModule?.release() }
        audioDeviceModule = null

        stopConnectionHealthMonitor()
        unregisterRecoveryCallbacks()
        stopSmartDucking(restoreVolume = true)
        abandonAudioFocus()
        clearCommunicationRoute()
    }

    fun isConnected(): Boolean = signalingConnected.get() || voicePeerCount() > 0 || (forceSfuForTesting && sfuEngine?.isConnected() == true)
    /** vc62 bridge election uses actual SFU media readiness, not MQTT/signaling readiness. */
    fun isSfuConnectedForBridge(): Boolean = forceSfuForTesting && sfuEngine?.isConnected() == true

    /**
     * vc66 handover warm-up. Fetch/refresh short-lived TURN credentials while the
     * offline AudioEngine still owns the microphone. This does not initialize WebRTC,
     * request audio focus or touch the audio route, so it is safe during LOCAL_ONLY.
     */
    fun prefetchTurnCredentials() {
        val now = System.currentTimeMillis()
        if (turnIceServers.isNotEmpty() && now - turnCredentialsLoadedAtMs < TURN_REFRESH_INTERVAL_MS) return
        if (!turnPrefetchInFlight.compareAndSet(false, true)) return
        Thread({
            try {
                refreshTurnCredentialsIfNeeded(allowWhenStopped = true)
            } finally {
                turnPrefetchInFlight.set(false)
            }
        }, "RideMesh-TURN-Prefetch").apply {
            isDaemon = true
            start()
        }
    }

    fun remotePeerCount(): Int = peers.size

    fun voicePeerCount(): Int = if (forceSfuForTesting) {
        if (sfuEngine?.isConnected() == true) sfuEngine?.remoteTrackCount() ?: 0 else 0
    } else sessions.values.count { it.connected }

    fun remotePeers(): List<RiderPeer> = peers.values
        .map { peer ->
            peer.copy(
                qualityBars = qualityBarsFor(peer.id),
                qualityLabel = qualityLabelFor(peer.id),
            )
        }
        .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.displayName })

    /**
     * Legacy API only. Beta4 WebRTC captures the microphone directly; raw PCM is never sent over
     * the signaling broker.
     */
    fun sendLocalAudio(audio: ByteArray): Boolean = false

    fun setMuted(muted: Boolean) {
        userMuted = muted
        hybridAudioBridge?.setLocalMicEnabled(!muted && !focusPaused)
        applyVoiceEnabled()
        audioStatus = if (muted) {
            "MIC MUTED • LISTENING ONLY"
        } else if (focusPaused) {
            "CALL / OTHER AUDIO ACTIVE • RIDEMESH PAUSED"
        } else {
            "WEBRTC OPUS • MIC LIVE"
        }
        listener.onInternetAudioStatus(audioStatus)
    }

    fun setAudioRoute(route: String): String {
        audioRoute = route.uppercase()
        val result = selectAudioRoute()
        listener.onInternetAudioStatus(result)
        return result
    }

    fun currentAudioStatus(): String = audioStatus
    fun isAudioInterrupted(): Boolean = focusPaused

    fun localRiderId(): UUID = nodeId

    fun currentConnectionQualityLabel(): String {
        val active = sessions.values.filter { it.connected }
        if (!signalingConnected.get() && active.isEmpty()) return "Reconnecting"
        if (active.any { it.measuredQualityLabel.equals("Poor", true) }) return "Poor"
        if (active.isNotEmpty() && active.all { it.measuredQualityLabel.equals("Excellent", true) }) return "Excellent"
        return "Good"
    }

    fun publishRiderLocation(
        latitude: Double,
        longitude: Double,
        speedKmh: Float,
        heading: Float,
        phoneNumber: String = "",
    ): Boolean {
        if (!running.get() || !signalingConnected.get()) return false
        if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return false
        val packet = RiderLocation(
            riderId = nodeId,
            displayName = riderName,
            latitude = latitude,
            longitude = longitude,
            speedKmh = speedKmh.coerceIn(0f, 450f),
            heading = ((heading % 360f) + 360f) % 360f,
            timestampMs = System.currentTimeMillis(),
            connectionQuality = currentConnectionQualityLabel(),
            phoneNumber = sanitizePhone(phoneNumber),
        )
        return runCatching {
            sendMqttPublish(locationTopic, encodeLocation(packet))
            true
        }.getOrDefault(false)
    }

    fun diagnostics(): Diagnostics {
        val sfu = sfuEngine?.diagnostics()
        val stateText = if (forceSfuForTesting) {
            if (sfu == null) "SFU not started" else "SFU ${sfu.state} • ICE ${sfu.iceState} • PC ${sfu.peerConnectionState}"
        } else sessions.values
            .sortedBy { it.id.toString() }
            .joinToString(separator = "\n") { session ->
                "${session.id.toString().take(8)}: ${session.state}${if (session.connected) " • VOICE" else ""}"
            }
            .ifBlank { "No WebRTC peers yet" }
        return Diagnostics(
            signalingConnected = signalingConnected.get(),
            voicePeersConnected = voicePeerCount(),
            knownRiders = peers.size,
            offersSent = offersSent.get(),
            answersSent = answersSent.get(),
            candidatesSent = candidatesSent.get(),
            reconnects = reconnects.get(),
            lastError = lastError,
            peerStates = stateText,
            turnConfigured = turnIceServers.any { server -> server.urls.any { it.startsWith("turn:") || it.startsWith("turns:") } },
            turnMode = if (forceTurnForTesting) "FORCE TURN" else "AUTO",
            selectedIceTransport = selectedIceTransport,
            turnStatus = turnStatus,
            detailedIceStats = if (forceSfuForTesting && sfu != null) {
                val rtt = if (sfu.rttMs >= 0) "%.1f ms".format(sfu.rttMs) else "n/a"
                val jitter = if (sfu.jitterMs >= 0) "%.1f ms".format(sfu.jitterMs) else "n/a"
                val loss = if (sfu.lossPercent >= 0) "%.2f%%".format(sfu.lossPercent) else "n/a"
                "SFU • ${sfu.state} • PC=${sfu.peerConnectionState} • ICE=${sfu.iceState} • RTT=$rtt • jitter=$jitter • loss=$loss • tx=${sfu.packetsSent} rx=${sfu.packetsReceived}"
            } else sessions.values.sortedBy { it.id.toString() }.joinToString("\n") { session ->
                val rtt = if (session.lastRttMs >= 0) "%.1f ms".format(session.lastRttMs) else "n/a"
                val jitter = if (session.lastJitterMs >= 0) "%.1f ms".format(session.lastJitterMs) else "n/a"
                val loss = if (session.lastLossPercent >= 0) "%.2f%%".format(session.lastLossPercent) else "n/a"
                "${session.id.toString().take(8)} • ${session.state} • connected=${session.connected} • quality=${session.measuredQualityLabel} • RTT=$rtt • jitter=$jitter • loss=$loss • packets rx=${session.lastPacketsReceived} lost=${session.lastPacketsLost}"
            }.ifBlank { "No ICE statistics yet" },
            onlineEngine = when { adaptiveOnlineEngine && forceSfuForTesting -> "AUTO • SFU"; adaptiveOnlineEngine -> "AUTO • DIRECT P2P"; forceSfuForTesting -> "FORCE SFU"; forceTurnForTesting -> "FORCE TURN"; else -> "P2P/AUTO" },
            sfuSessionId = sfu?.sessionId.orEmpty(),
            sfuState = sfu?.state ?: if (forceSfuForTesting) "STARTING" else "OFF",
            sfuIceState = sfu?.iceState ?: "NEW",
            sfuPeerConnectionState = sfu?.peerConnectionState ?: "NEW",
            sfuLocalTrackName = sfu?.localTrackName.orEmpty(),
            sfuRemoteTracks = sfu?.remoteTracks ?: 0,
            sfuPublishCalls = sfu?.publishCalls ?: 0,
            sfuSubscribeCalls = sfu?.subscribeCalls ?: 0,
            sfuRenegotiations = sfu?.renegotiations ?: 0,
            sfuReconnects = sfu?.reconnects ?: 0,
            sfuPacketsSent = sfu?.packetsSent ?: 0L,
            sfuPacketsReceived = sfu?.packetsReceived ?: 0L,
            sfuLastTxPacketAgeMs = sfu?.lastTxPacketAgeMs ?: -1L,
            sfuLastRxPacketAgeMs = sfu?.lastRxPacketAgeMs ?: -1L,
            sfuRttMs = sfu?.rttMs ?: -1.0,
            sfuJitterMs = sfu?.jitterMs ?: -1.0,
            sfuLossPercent = sfu?.lossPercent ?: -1.0,
            sfuLastError = sfu?.lastError.orEmpty(),
            hybridBridgeDiagnostics = hybridBridgeDiagnostics(),
        )
    }

    private fun initializeWebRtc(ctx: Context) {
        if (factory != null) return

        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        val voiceAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        // Build 43: install one read-only observer on the existing WebRTC ADM. It never owns a
        // microphone, never mutates capture PCM, and can be toggled without rebuilding peers.
        val onlineFilter = OnlineSileroProcessor(ctx).apply {
            setEnabled(ctx.getSharedPreferences("ridemesh", Context.MODE_PRIVATE)
                .getBoolean("silero_online_observer_v43", true))
        }
        onlineSilero = onlineFilter
        val admBuilder = JavaAudioDeviceModule.builder(ctx)
            .setUseHardwareAcousticEchoCanceler(
                JavaAudioDeviceModule.isBuiltInAcousticEchoCancelerSupported()
            )
            .setUseHardwareNoiseSuppressor(
                JavaAudioDeviceModule.isBuiltInNoiseSuppressorSupported()
            )
            .setUseStereoInput(false)
            .setUseStereoOutput(false)
            .setUseLowLatency(true)
            .setAudioAttributes(voiceAttributes)
        val hybridBridge = if (hybridBridgeConfigured) {
            HybridSfuAudioBridge(
                isPrimaryBridge = { running.get() && hybridPrimaryProvider.invoke() },
                sendToOffline = { pcm -> if (running.get()) hybridOfflineSender.invoke(pcm) },
            )
        } else null
        hybridAudioBridge?.close()
        hybridAudioBridge = hybridBridge

        admBuilder.setAudioBufferCallback { buffer, format, channels, rate, bytes, timestamp ->
            // Silero observes the REAL microphone before vc62 injects offline bridge audio.
            val observedTimestamp = onlineFilter.process(buffer, format, channels, rate, bytes, timestamp)
            hybridBridge?.setLocalMicEnabled(!userMuted && !focusPaused)
            hybridBridge?.processCapture(buffer, format, channels, rate, bytes, observedTimestamp) ?: observedTimestamp
        }
        if (hybridBridge != null) {
            admBuilder.setPlaybackSamplesReadyCallback { samples ->
                hybridBridge.onPlaybackSamples(samples)
            }
        }
        val adm = admBuilder.createAudioDeviceModule()

        audioDeviceModule = adm
        factory = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .createPeerConnectionFactory()

        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
        }
        audioSource = factory?.createAudioSource(constraints)
        localAudioTrack = audioSource?.let { source ->
            factory?.createAudioTrack(LOCAL_AUDIO_TRACK_ID, source)
        }
        audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioStatus = "WEBRTC OPUS • AEC + NS • READY"
        listener.onInternetAudioStatus(audioStatus)
    }

    private fun ensurePeer(peerId: UUID, allowOffer: Boolean = true): PeerSession? {
        if (forceSfuForTesting) return null
        sessions[peerId]?.let { existing ->
            if (allowOffer && existing.initiator && !existing.connected) maybeCreateOffer(existing)
            return existing
        }

        val factory = factory ?: return null
        val localTrack = localAudioTrack ?: return null
        val initiator = nodeId.toString() < peerId.toString()

        val configuredIceServers = if (turnIceServers.isNotEmpty()) {
            turnIceServers
        } else {
            listOf(
                PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            )
        }
        val config = PeerConnection.RTCConfiguration(configuredIceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            iceTransportsType = if (forceTurnForTesting && turnIceServers.isNotEmpty()) PeerConnection.IceTransportsType.RELAY else PeerConnection.IceTransportsType.ALL
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            audioJitterBufferMaxPackets = 50
            audioJitterBufferFastAccelerate = true
            iceCandidatePoolSize = 2
        }

        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState) {
                updatePeerState(peerId, "SDP $newState")
            }

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                when (newState) {
                    PeerConnection.IceConnectionState.CONNECTED,
                    PeerConnection.IceConnectionState.COMPLETED ->
                        markPeerConnected(peerId, true, "ICE $newState")

                    PeerConnection.IceConnectionState.FAILED -> {
                        markPeerConnected(peerId, false, "ICE FAILED")
                        schedulePeerReconnect(peerId, immediate = true)
                    }

                    PeerConnection.IceConnectionState.DISCONNECTED -> {
                        markPeerConnected(peerId, false, "ICE DISCONNECTED")
                        schedulePeerReconnect(peerId, immediate = false)
                    }

                    PeerConnection.IceConnectionState.CLOSED ->
                        markPeerConnected(peerId, false, "ICE CLOSED")

                    else -> updatePeerState(peerId, "ICE $newState")
                }
            }

            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                when (newState) {
                    PeerConnection.PeerConnectionState.CONNECTED ->
                        markPeerConnected(peerId, true, "CONNECTED")

                    PeerConnection.PeerConnectionState.FAILED -> {
                        markPeerConnected(peerId, false, "FAILED")
                        schedulePeerReconnect(peerId, immediate = true)
                    }

                    PeerConnection.PeerConnectionState.DISCONNECTED -> {
                        markPeerConnected(peerId, false, "DISCONNECTED")
                        schedulePeerReconnect(peerId, immediate = false)
                    }

                    PeerConnection.PeerConnectionState.CLOSED ->
                        markPeerConnected(peerId, false, "CLOSED")

                    else -> updatePeerState(peerId, newState.name)
                }
            }

            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit

            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) {
                updatePeerState(peerId, "ICE GATHER $newState")
            }

            override fun onIceCandidate(candidate: IceCandidate) {
                if (!running.get()) return
                publishSignal(
                    SignalPacket(
                        from = nodeId,
                        to = peerId,
                        type = SignalType.CANDIDATE,
                        payload = candidate.sdp,
                        mid = candidate.sdpMid.orEmpty(),
                        line = candidate.sdpMLineIndex,
                    )
                )
                candidatesSent.incrementAndGet()
            }

            override fun onIceCandidatesRemoved(candidates: Array<IceCandidate>) = Unit
            override fun onAddStream(stream: MediaStream) = Unit
            override fun onRemoveStream(stream: MediaStream) = Unit
            override fun onDataChannel(dataChannel: DataChannel) = Unit

            override fun onRenegotiationNeeded() {
                sessions[peerId]?.let { session ->
                    if (session.initiator) maybeCreateOffer(session)
                }
            }

            override fun onAddTrack(receiver: RtpReceiver, mediaStreams: Array<MediaStream>) {
                receiver.track()?.setEnabled(true)
            }
        }

        val pc = factory.createPeerConnection(config, observer) ?: run {
            lastError = "Could not create WebRTC PeerConnection"
            listener.onInternetState(isConnected(), lastError)
            return null
        }

        val session = PeerSession(peerId, pc, initiator)
        sessions[peerId] = session
        pc.addTrack(localTrack, listOf(MEDIA_STREAM_ID))
        runCatching { pc.setBitrate(28_000, 42_000, 60_000) }
        updatePeerState(peerId, if (initiator) "READY TO OFFER" else "WAITING OFFER")

        if (allowOffer && initiator) maybeCreateOffer(session)
        return session
    }

    private fun maybeCreateOffer(session: PeerSession, force: Boolean = false) {
        if (!running.get() || !session.initiator || session.connected) return
        val now = System.currentTimeMillis()
        if (!force && now - session.lastOfferMs < OFFER_RETRY_INTERVAL_MS) return
        session.lastOfferMs = now

        if (!force && session.pc.signalingState() == PeerConnection.SignalingState.HAVE_LOCAL_OFFER) {
            session.pc.localDescription?.let { current ->
                publishSignal(
                    SignalPacket(nodeId, session.id, SignalType.OFFER, preferOpus(current.description))
                )
                offersSent.incrementAndGet()
                updatePeerState(session.id, "OFFER RETRANSMITTED")
                return
            }
        }

        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            if (force) mandatory.add(MediaConstraints.KeyValuePair("IceRestart", "true"))
        }

        session.pc.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                val preferred = SessionDescription(desc.type, preferOpus(desc.description))
                session.pc.setLocalDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        publishSignal(
                            SignalPacket(
                                from = nodeId,
                                to = session.id,
                                type = SignalType.OFFER,
                                payload = preferred.description,
                            )
                        )
                        offersSent.incrementAndGet()
                        updatePeerState(session.id, if (force) "ICE RESTART OFFER" else "OFFER SENT")
                    }

                    override fun onSetFailure(error: String) {
                        recordError("Set local offer failed: $error")
                    }
                }, preferred)
            }

            override fun onCreateFailure(error: String) {
                recordError("Create offer failed: $error")
            }
        }, constraints)
    }

    private fun handleOffer(signal: SignalPacket) {
        val session = ensurePeer(signal.from, allowOffer = false) ?: return
        val remote = SessionDescription(SessionDescription.Type.OFFER, preferOpus(signal.payload))
        session.pc.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                session.remoteDescriptionSet = true
                flushPendingCandidates(session)
                val constraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
                }
                session.pc.createAnswer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        val preferred = SessionDescription(desc.type, preferOpus(desc.description))
                        session.pc.setLocalDescription(object : SimpleSdpObserver() {
                            override fun onSetSuccess() {
                                publishSignal(
                                    SignalPacket(
                                        from = nodeId,
                                        to = signal.from,
                                        type = SignalType.ANSWER,
                                        payload = preferred.description,
                                    )
                                )
                                answersSent.incrementAndGet()
                                updatePeerState(signal.from, "ANSWER SENT")
                            }

                            override fun onSetFailure(error: String) {
                                recordError("Set local answer failed: $error")
                            }
                        }, preferred)
                    }

                    override fun onCreateFailure(error: String) {
                        recordError("Create answer failed: $error")
                    }
                }, constraints)
            }

            override fun onSetFailure(error: String) {
                recordError("Set remote offer failed: $error")
            }
        }, remote)
    }

    private fun handleAnswer(signal: SignalPacket) {
        val session = sessions[signal.from] ?: ensurePeer(signal.from, allowOffer = false) ?: return
        val remote = SessionDescription(SessionDescription.Type.ANSWER, preferOpus(signal.payload))
        session.pc.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                session.remoteDescriptionSet = true
                flushPendingCandidates(session)
                updatePeerState(signal.from, "ANSWER APPLIED")
            }

            override fun onSetFailure(error: String) {
                recordError("Set remote answer failed: $error")
            }
        }, remote)
    }

    private fun handleCandidate(signal: SignalPacket) {
        val session = sessions[signal.from] ?: ensurePeer(signal.from, allowOffer = false) ?: return
        val candidate = IceCandidate(signal.mid.takeIf { it.isNotBlank() }, signal.line, signal.payload)
        if (session.remoteDescriptionSet || session.pc.remoteDescription != null) {
            session.pc.addIceCandidate(candidate)
        } else {
            session.pendingCandidates += candidate
        }
    }

    private fun flushPendingCandidates(session: PeerSession) {
        if (!session.remoteDescriptionSet && session.pc.remoteDescription == null) return
        val pending = session.pendingCandidates.toList()
        session.pendingCandidates.clear()
        pending.forEach { candidate -> session.pc.addIceCandidate(candidate) }
    }

    private fun schedulePeerReconnect(peerId: UUID, immediate: Boolean) {
        val session = sessions[peerId] ?: return
        if (session.reconnectScheduled || !running.get()) return
        session.reconnectScheduled = true
        Thread({
            try {
                Thread.sleep(if (immediate) ICE_FAILED_RETRY_MS else ICE_DISCONNECTED_GRACE_MS)
            } catch (_: InterruptedException) {
                return@Thread
            }

            val current = sessions[peerId] ?: return@Thread
            current.reconnectScheduled = false
            if (!running.get() || current.connected) return@Thread

            reconnects.incrementAndGet()
            if (current.initiator) {
                runCatching { current.pc.restartIce() }
                maybeCreateOffer(current, force = true)
            } else {
                updatePeerState(peerId, "WAITING ICE RESTART")
            }
        }, "RideMesh-ICE-Reconnect").apply {
            isDaemon = true
            start()
        }
    }

    private fun markPeerConnected(peerId: UUID, connected: Boolean, state: String) {
        val session = sessions[peerId] ?: return
        session.connected = connected
        session.state = state
        session.lastStateChangeMs = System.currentTimeMillis()
        if (!connected) {
            session.measuredQualityBars = 1
            session.measuredQualityLabel = "Reconnecting"
        } else if (session.measuredQualityLabel == "Reconnecting") {
            session.measuredQualityBars = 3
            session.measuredQualityLabel = "Good"
        }
        peers.computeIfPresent(peerId) { _, peer ->
            peer.copy(qualityBars = qualityBarsFor(peerId))
        }
        notifyPeerCount(force = true)
        listener.onInternetState(
            isConnected(),
            if (connected) {
                val count = voicePeerCount()
                "WEBRTC OPUS VOICE CONNECTED • $count PEER${if (count == 1) "" else "S"}"
            } else {
                "WEBRTC $state • AUTO RECONNECT"
            }
        )
    }

    private fun updatePeerState(peerId: UUID, state: String) {
        sessions[peerId]?.let {
            it.state = state
            it.lastStateChangeMs = System.currentTimeMillis()
        }
    }

    private fun closePeer(peerId: UUID, sendBye: Boolean = false) {
        val session = sessions.remove(peerId) ?: return
        if (sendBye && signalingConnected.get()) {
            publishSignal(SignalPacket(nodeId, peerId, SignalType.BYE))
        }
        runCatching { session.pc.close() }
        runCatching { session.pc.dispose() }
        notifyPeerCount(force = true)
    }

    private fun closeAllPeerConnections() {
        sessions.keys.toList().forEach { closePeer(it, sendBye = false) }
        sessions.clear()
    }

    private fun qualityBarsFor(id: UUID): Int {
        val session = sessions[id] ?: return 2
        if (!session.connected) return 1
        return session.measuredQualityBars.coerceIn(1, 4)
    }

    private fun qualityLabelFor(id: UUID): String {
        val session = sessions[id] ?: return "Connecting"
        if (!session.connected) return "Reconnecting"
        return session.measuredQualityLabel.ifBlank { "Good" }
    }

    private fun startConnectionHealthMonitor() {
        stopConnectionHealthMonitor()
        healthStatsPending.clear()
        connectionHealthThread = Thread({
            try {
                while (running.get() && !Thread.currentThread().isInterrupted) {
                    refreshTurnCredentialsIfNeeded()
                    val snapshot = sessions.values.toList()
                    snapshot.forEach { session ->
                        if (session.connected) collectPeerHealth(session)
                    }
                    Thread.sleep(CONNECTION_HEALTH_POLL_MS)
                }
            } catch (_: InterruptedException) {
                // Ride stopped/restarted.
            }
        }, "RideMesh-ConnectionHealth").apply {
            isDaemon = true
            start()
        }
    }

    private fun stopConnectionHealthMonitor() {
        connectionHealthThread?.interrupt()
        connectionHealthThread = null
        healthStatsPending.clear()
    }

    private fun collectPeerHealth(session: PeerSession) {
        if (!healthStatsPending.add(session.id)) return
        runCatching {
            session.pc.getStats { report ->
                try {
                    var rttMs = -1.0
                    var jitterMs = -1.0
                    var packetsLost = -1L
                    var packetsReceived = -1L
                    var selectedLocalCandidateId: String? = null

                    report.statsMap.values.forEach { stat ->
                        val members = stat.members
                        when (stat.type) {
                            "candidate-pair" -> {
                                val state = members["state"]?.toString().orEmpty()
                                val nominated = members["nominated"] as? Boolean ?: false
                                if (state.equals("succeeded", true) || nominated) {
                                    selectedLocalCandidateId = members["localCandidateId"]?.toString() ?: selectedLocalCandidateId
                                }
                                if ((state.equals("succeeded", true) || nominated) && rttMs < 0.0) {
                                    val seconds = (members["currentRoundTripTime"] as? Number)?.toDouble()
                                    if (seconds != null && seconds >= 0.0) rttMs = seconds * 1000.0
                                }
                            }

                            "remote-inbound-rtp" -> {
                                val kind = (members["kind"] ?: members["mediaType"])?.toString().orEmpty()
                                if (kind.equals("audio", true) && rttMs < 0.0) {
                                    val seconds = (members["roundTripTime"] as? Number)?.toDouble()
                                    if (seconds != null && seconds >= 0.0) rttMs = seconds * 1000.0
                                }
                            }

                            "inbound-rtp" -> {
                                val kind = (members["kind"] ?: members["mediaType"])?.toString().orEmpty()
                                if (!kind.equals("audio", true)) return@forEach
                                val jitterSeconds = (members["jitter"] as? Number)?.toDouble()
                                if (jitterSeconds != null && jitterSeconds >= 0.0) {
                                    jitterMs = maxOf(jitterMs, jitterSeconds * 1000.0)
                                }
                                val lost = (members["packetsLost"] as? Number)?.toLong()
                                val received = (members["packetsReceived"] as? Number)?.toLong()
                                if (lost != null) packetsLost = maxOf(packetsLost, lost)
                                if (received != null) packetsReceived = maxOf(packetsReceived, received)
                            }
                        }
                    }

                    selectedLocalCandidateId?.let { candidateId ->
                        report.statsMap[candidateId]?.let { candidate ->
                            val type = candidate.members["candidateType"]?.toString()?.uppercase().orEmpty()
                            val protocol = candidate.members["protocol"]?.toString()?.uppercase().orEmpty()
                            if (type.isNotBlank()) {
                                selectedIceTransport = listOf(type, protocol).filter { it.isNotBlank() }.joinToString("/")
                                if (type == "RELAY" && turnIceServers.isNotEmpty()) turnStatus = "CLOUDFLARE TURN ACTIVE"
                            }
                        }
                    }

                    val lossPercent = calculateLossPercent(session, packetsLost, packetsReceived)
                    updateMeasuredQuality(session, rttMs, jitterMs, lossPercent)
                } finally {
                    healthStatsPending.remove(session.id)
                }
            }
        }.onFailure {
            healthStatsPending.remove(session.id)
        }
    }

    private fun calculateLossPercent(session: PeerSession, lost: Long, received: Long): Double {
        if (lost < 0L || received < 0L) return session.lastLossPercent
        val previousLost = session.lastPacketsLost
        val previousReceived = session.lastPacketsReceived
        session.lastPacketsLost = lost
        session.lastPacketsReceived = received

        val lostDelta = if (previousLost >= 0L && lost >= previousLost) lost - previousLost else lost
        val receivedDelta = if (previousReceived >= 0L && received >= previousReceived) {
            received - previousReceived
        } else {
            received
        }
        val total = lostDelta + receivedDelta
        if (total <= 0L) return session.lastLossPercent
        return (lostDelta.coerceAtLeast(0L).toDouble() * 100.0 / total.toDouble()).coerceIn(0.0, 100.0)
    }

    private fun updateMeasuredQuality(
        session: PeerSession,
        rttMs: Double,
        jitterMs: Double,
        lossPercent: Double,
    ) {
        if (!session.connected) return
        if (rttMs >= 0.0) session.lastRttMs = rttMs
        if (jitterMs >= 0.0) session.lastJitterMs = jitterMs
        if (lossPercent >= 0.0) session.lastLossPercent = lossPercent

        val rtt = session.lastRttMs
        val jitter = session.lastJitterMs
        val loss = session.lastLossPercent

        val poor = (loss >= QUALITY_POOR_LOSS_PERCENT) ||
            (rtt >= QUALITY_POOR_RTT_MS) ||
            (jitter >= QUALITY_POOR_JITTER_MS)
        val excellent = !poor &&
            (loss < 0.0 || loss <= QUALITY_EXCELLENT_LOSS_PERCENT) &&
            (rtt < 0.0 || rtt <= QUALITY_EXCELLENT_RTT_MS) &&
            (jitter < 0.0 || jitter <= QUALITY_EXCELLENT_JITTER_MS)

        when {
            poor -> {
                session.measuredQualityBars = 1
                session.measuredQualityLabel = "Poor"
                applyAdaptiveAudioTier(session, AUDIO_TIER_POOR)
            }
            excellent -> {
                session.measuredQualityBars = 4
                session.measuredQualityLabel = "Excellent"
                applyAdaptiveAudioTier(session, AUDIO_TIER_EXCELLENT)
            }
            else -> {
                session.measuredQualityBars = 3
                session.measuredQualityLabel = "Good"
                applyAdaptiveAudioTier(session, AUDIO_TIER_GOOD)
            }
        }

        peers.computeIfPresent(session.id) { _, peer ->
            peer.copy(
                qualityBars = session.measuredQualityBars,
                qualityLabel = session.measuredQualityLabel,
            )
        }
    }

    private fun applyAdaptiveAudioTier(session: PeerSession, tier: Int) {
        if (session.audioQualityTier == tier) return
        session.audioQualityTier = tier
        val connectedPeers = sessions.values.count { it.connected }.coerceAtLeast(1)
        val values = when {
            connectedPeers >= 6 -> when (tier) {
                AUDIO_TIER_POOR -> intArrayOf(18_000, 24_000, 34_000)
                AUDIO_TIER_GOOD -> intArrayOf(24_000, 34_000, 46_000)
                else -> intArrayOf(28_000, 42_000, 56_000)
            }
            connectedPeers >= 4 -> when (tier) {
                AUDIO_TIER_POOR -> intArrayOf(20_000, 28_000, 40_000)
                AUDIO_TIER_GOOD -> intArrayOf(28_000, 40_000, 54_000)
                else -> intArrayOf(32_000, 48_000, 64_000)
            }
            else -> when (tier) {
                AUDIO_TIER_POOR -> intArrayOf(22_000, 30_000, 44_000)
                AUDIO_TIER_GOOD -> intArrayOf(30_000, 44_000, 60_000)
                else -> intArrayOf(36_000, 54_000, 72_000)
            }
        }
        // Keep speech quality high while preventing seven simultaneous outbound encodes
        // from overloading a phone or mobile uplink. Opus FEC + DTX remain enabled.
        runCatching { session.pc.setBitrate(values[0], values[1], values[2]) }
    }

    private fun registerRecoveryCallbacks(ctx: Context) {
        val handler = Handler(Looper.getMainLooper())
        recoveryHandler = handler

        val manager = audioManager
        if (manager != null && audioDeviceCallback == null) {
            val callback = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<AudioDeviceInfo>) {
                    if (addedDevices.any { it.isVoiceBluetoothDevice() }) scheduleAudioRouteRecovery()
                }

                override fun onAudioDevicesRemoved(removedDevices: Array<AudioDeviceInfo>) {
                    if (removedDevices.any { it.isVoiceBluetoothDevice() }) scheduleAudioRouteRecovery()
                }
            }
            audioDeviceCallback = callback
            runCatching { manager.registerAudioDeviceCallback(callback, handler) }
        }

        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        connectivityManager = cm
        val active = cm.activeNetwork
        lastNetworkHandle = active?.networkHandle ?: -1L
        lastNetworkTransport = networkTransportLabel(active?.let(cm::getNetworkCapabilities))

        if (networkCallback == null) {
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    observeDefaultNetwork(network)
                }

                override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                    observeDefaultNetwork(network, capabilities)
                }
            }
            networkCallback = callback
            runCatching { cm.registerDefaultNetworkCallback(callback, handler) }
        }
    }

    private fun unregisterRecoveryCallbacks() {
        audioDeviceCallback?.let { callback ->
            runCatching { audioManager?.unregisterAudioDeviceCallback(callback) }
        }
        audioDeviceCallback = null
        networkCallback?.let { callback ->
            runCatching { connectivityManager?.unregisterNetworkCallback(callback) }
        }
        networkCallback = null
        connectivityManager = null
        recoveryHandler?.removeCallbacksAndMessages(null)
        recoveryHandler = null
        networkHandoverPending = false
        lastNetworkHandle = -1L
        lastNetworkTransport = ""
    }

    private fun scheduleAudioRouteRecovery() {
        val handler = recoveryHandler ?: return
        handler.removeCallbacksAndMessages(AUDIO_ROUTE_RECOVERY_TOKEN)
        handler.postAtTime({
            if (!running.get() || focusPaused) return@postAtTime
            selectAudioRoute()
            sessions.values.forEach { session ->
                runCatching { session.pc.setAudioPlayout(true) }
                runCatching { session.pc.setAudioRecording(true) }
            }
            applyVoiceEnabled()
        }, AUDIO_ROUTE_RECOVERY_TOKEN, android.os.SystemClock.uptimeMillis() + AUDIO_ROUTE_RECOVERY_MS)
    }

    private fun observeDefaultNetwork(
        network: Network,
        capabilities: NetworkCapabilities? = connectivityManager?.getNetworkCapabilities(network),
    ) {
        if (!running.get()) return
        val handle = network.networkHandle
        val transport = networkTransportLabel(capabilities)
        val changed = lastNetworkHandle >= 0L &&
            (handle != lastNetworkHandle || (lastNetworkTransport.isNotBlank() && transport != lastNetworkTransport))
        lastNetworkHandle = handle
        lastNetworkTransport = transport
        if (!changed) return

        networkHandoverPending = true
        reconnectAttempt = 0
        listener.onInternetState(voicePeerCount() > 0, "CONNECTION CHANGED • CHECKING MEDIA")
        // vc74: cellular/Wi-Fi callbacks can flap while WebRTC/SFU media remains healthy.
        // Coalesce them and wait briefly. If SFU is still connected and packets are moving,
        // preserve the session and signaling instead of forcing needless recovery.
        val handler = recoveryHandler ?: return
        handler.removeCallbacksAndMessages(NETWORK_HANDOVER_RECOVERY_TOKEN)
        handler.postAtTime({
            if (!running.get() || !networkHandoverPending) return@postAtTime
            val d = sfuEngine?.diagnostics()
            val mediaHealthy = d != null && sfuEngine?.isConnected() == true &&
                d.lastTxPacketAgeMs in 0..SFU_MEDIA_HEALTHY_AGE_MS &&
                (d.remoteTracks == 0 || d.lastRxPacketAgeMs in 0..SFU_MEDIA_HEALTHY_AGE_MS)
            if (mediaHealthy) {
                networkHandoverPending = false
                lastError = ""
                listener.onInternetState(true, "SFU MEDIA HEALTHY • HANDOVER IGNORED")
            } else {
                listener.onInternetState(voicePeerCount() > 0, "CONNECTION CHANGED • RECOVERING")
                closeSocket()
            }
        }, NETWORK_HANDOVER_RECOVERY_TOKEN, android.os.SystemClock.uptimeMillis() + NETWORK_HANDOVER_GRACE_MS)
    }

    private fun networkTransportLabel(capabilities: NetworkCapabilities?): String = when {
        capabilities == null -> "UNKNOWN"
        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
        else -> "OTHER"
    }

    private fun recoverPeersAfterNetworkHandover() {
        sessions.values.forEach { session ->
            if (session.initiator) {
                runCatching { session.pc.restartIce() }
                session.connected = false
                session.measuredQualityBars = 1
                session.measuredQualityLabel = "Reconnecting"
                maybeCreateOffer(session, force = true)
            } else if (!session.connected) {
                updatePeerState(session.id, "RECONNECTING")
            }
        }
        notifyPeerCount(force = true)
    }

    private fun refreshTurnCredentialsIfNeeded(allowWhenStopped: Boolean = false) {
        if (!allowWhenStopped && !running.get()) return
        val now = System.currentTimeMillis()
        if (turnIceServers.isNotEmpty() && now - turnCredentialsLoadedAtMs < TURN_REFRESH_INTERVAL_MS) return

        try {
            val connection = (URL(TURN_CREDENTIALS_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = TURN_HTTP_TIMEOUT_MS
                readTimeout = TURN_HTTP_TIMEOUT_MS
                useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            try {
                val status = connection.responseCode
                if (status !in 200..299) {
                    turnStatus = "HTTP $status • STUN FALLBACK"
                    return
                }
                val json = connection.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(json)
                val array = root.optJSONArray("iceServers") ?: run {
                    turnStatus = "INVALID RESPONSE • STUN FALLBACK"
                    return
                }
                val servers = ArrayList<PeerConnection.IceServer>()
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val urlsValue = item.opt("urls")
                    val urls = ArrayList<String>()
                    when (urlsValue) {
                        is org.json.JSONArray -> for (j in 0 until urlsValue.length()) urlsValue.optString(j).takeIf { it.isNotBlank() }?.let(urls::add)
                        is String -> if (urlsValue.isNotBlank()) urls.add(urlsValue)
                    }
                    if (urls.isEmpty()) continue
                    val builder = PeerConnection.IceServer.builder(urls)
                    item.optString("username").takeIf { it.isNotBlank() }?.let(builder::setUsername)
                    item.optString("credential").takeIf { it.isNotBlank() }?.let(builder::setPassword)
                    servers += builder.createIceServer()
                }
                if (servers.none { server -> server.urls.any { it.startsWith("turn:") || it.startsWith("turns:") } }) {
                    turnStatus = "TURN MISSING • STUN FALLBACK"
                    return
                }
                turnIceServers = servers
                turnCredentialsLoadedAtMs = now
                turnStatus = "CLOUDFLARE TURN READY"
            } finally {
                connection.disconnect()
            }
        } catch (t: Throwable) {
            turnStatus = "${t.javaClass.simpleName} • STUN FALLBACK"
        }
    }

    private fun connectionLoop() {
        while (running.get()) {
            try {
                refreshTurnCredentialsIfNeeded()
                connectAndRead()
            } catch (_: InterruptedException) {
                break
            } catch (t: Throwable) {
                if (running.get()) {
                    recordError("Signaling: ${t.javaClass.simpleName}: ${t.message ?: "connection error"}")
                    listener.onInternetState(
                        voicePeerCount() > 0,
                        if (voicePeerCount() > 0) {
                            "VOICE STILL ACTIVE • SIGNALING RECONNECTING"
                        } else {
                            "WEBRTC SIGNALING RECONNECTING"
                        }
                    )
                }
            } finally {
                closeSocket()
            }

            if (running.get()) {
                val delayMs = nextReconnectDelayMs()
                try {
                    Thread.sleep(delayMs)
                } catch (_: InterruptedException) {
                    break
                }
            }
        }
    }

    private fun connectAndRead() {
        val tls = (SSLSocketFactory.getDefault()
            .createSocket(PUBLIC_BROKER, PUBLIC_BROKER_TLS_PORT) as SSLSocket).apply {
            soTimeout = SOCKET_TIMEOUT_MS
            tcpNoDelay = true
            startHandshake()
        }
        socket = tls
        val input = BufferedInputStream(tls.inputStream)
        output = BufferedOutputStream(tls.outputStream)

        sendRaw(connectPacket())
        val connAck = readPacket(input)
        if (connAck.type != 2 || connAck.body.size < 2 || connAck.body[1].toInt() != 0) {
            throw IllegalStateException("MQTT signaling broker rejected connection")
        }

        sendRaw(subscribePacket(subscriptionTopic))
        signalingConnected.set(true)
        reconnectAttempt = 0
        lastError = ""
        listener.onInternetState(true, if (forceSfuForTesting) "SFU SIGNALING READY • OPUS VOICE" else "WEBRTC SIGNALING READY • OPUS VOICE")
        publishPresence()
        if (forceSfuForTesting) ensureSfuStarted()
        if (networkHandoverPending) {
            networkHandoverPending = false
            recoverPeersAfterNetworkHandover()
        }

        var lastPing = System.currentTimeMillis()
        var lastPresence = 0L

        while (running.get() && !tls.isClosed) {
            try {
                val mqtt = readPacket(input)
                if (mqtt.type == 3) handlePublish(mqtt.body)
            } catch (_: java.net.SocketTimeoutException) {
                // Wake for presence, peer negotiation and signaling keepalive.
            }

            val now = System.currentTimeMillis()
            val stableRoom = if (forceSfuForTesting) {
                sfuEngine?.isConnected() == true && (peers.isEmpty() || (sfuEngine?.remoteTrackCount() ?: 0) >= peers.size)
            } else sessions.size >= peers.size && sessions.values.all { it.connected }
            val presenceIntervalMs = if (stableRoom) {
                PRESENCE_STABLE_INTERVAL_MS
            } else {
                PRESENCE_DISCOVERY_INTERVAL_MS
            }
            if (now - lastPresence >= presenceIntervalMs) {
                publishPresence()
                if (!stableRoom) refreshPeerNegotiation(now)
                prunePeers(now)
                lastPresence = now
            }
            if (now - lastPing >= PING_INTERVAL_MS) {
                sendRaw(byteArrayOf(0xC0.toByte(), 0x00))
                lastPing = now
            }
        }
    }

    private fun handlePublish(body: ByteArray) {
        if (body.size < 2) return
        val topicLen = ((body[0].toInt() and 0xff) shl 8) or (body[1].toInt() and 0xff)
        if (topicLen <= 0 || body.size < 2 + topicLen) return
        val receivedTopic = body.copyOfRange(2, 2 + topicLen).toString(Charsets.UTF_8)
        val payload = body.copyOfRange(2 + topicLen, body.size)

        when (receivedTopic) {
            presenceTopic -> handlePresence(payload)
            signalTopic -> decodeSignal(payload)?.let(::handleSignal)
            locationTopic -> decodeLocationCompat(payload)?.let { location ->
                if (location.riderId != nodeId) listener.onInternetRiderLocation(location)
            }
        }
    }

    private fun publishPresence() {
        if (!signalingConnected.get()) return
        sendMqttPublish(
            presenceTopic,
            encodePresence(
                PresencePacket(
                    origin = nodeId,
                    timestampMs = System.currentTimeMillis(),
                    riderName = riderName,
                    deviceName = deviceName,
                )
            )
        )
    }

    private fun handlePresence(payload: ByteArray) {
        val presence = decodePresence(payload) ?: return
        if (presence.origin == nodeId) return

        val now = System.currentTimeMillis()
        val previous = peers[presence.origin]
        peers[presence.origin] = RiderPeer(
            id = presence.origin,
            riderName = presence.riderName.ifBlank { previous?.riderName.orEmpty() },
            deviceName = presence.deviceName.ifBlank { previous?.deviceName.orEmpty() },
            lastSeenMs = now,
            qualityBars = qualityBarsFor(presence.origin),
            qualityLabel = qualityLabelFor(presence.origin),
        )
        notifyPeerCount(force = previous == null)
        if (adaptiveOnlineEngine) {
            adaptiveGroupSize = maxOf(adaptiveGroupSize, peers.size + 1)
            applyAdaptiveOnlineEngine()
        }
        if (forceSfuForTesting) {
            ensureSfuStarted()
            announceSfuTrackIfReady()
        } else {
            ensurePeer(presence.origin, allowOffer = true)
        }
        if (previous == null) {
            // Fast room convergence: tell the newcomer about us immediately instead of
            // waiting for the next periodic presence heartbeat.
            publishPresence()
        }
    }

    private fun refreshPeerNegotiation(now: Long) {
        if (forceSfuForTesting) {
            ensureSfuStarted()
            announceSfuTrackIfReady()
            return
        }
        peers.keys.forEach { peerId ->
            val session = sessions[peerId] ?: ensurePeer(peerId, allowOffer = true)
            if (session != null && session.initiator && !session.connected &&
                now - session.lastOfferMs >= OFFER_RETRY_INTERVAL_MS
            ) {
                maybeCreateOffer(session)
            }
        }
    }

    private fun prunePeers(now: Long) {
        val stale = peers.values.filter { now - it.lastSeenMs > PRESENCE_TIMEOUT_MS }
        stale.forEach { peer ->
            val session = sessions[peer.id]
            // Keep a healthy SRTP connection alive across a temporary MQTT heartbeat gap.
            if (session == null || !session.connected) {
                peers.remove(peer.id)
                if (!forceSfuForTesting) closePeer(peer.id, sendBye = false)
            }
        }
        notifyPeerCount()
        if (adaptiveOnlineEngine && adaptiveGroupSize <= peers.size + 1) {
            adaptiveGroupSize = peers.size + 1
            applyAdaptiveOnlineEngine()
        }
    }

    private fun ensureSfuStarted() {
        if (!forceSfuForTesting || sfuEngine != null) return
        val currentFactory = factory ?: return
        val currentTrack = localAudioTrack ?: return
        sfuEngine = CloudflareSfuEngine(
            factory = currentFactory,
            localAudioTrack = currentTrack,
            backendUrl = SFU_BACKEND_URL,
            callback = object : CloudflareSfuEngine.Callback {
                override fun onPublished(sessionId: String, trackName: String) {
                    publishSfuTrackAnnouncement(sessionId, trackName)
                }

                override fun onState(message: String) {
                    listener.onInternetState(true, message)
                }

                override fun onError(message: String) {
                    recordError(message)
                    listener.onInternetState(signalingConnected.get(), message)
                }
            },
        ).also { it.start() }
    }

    private fun announceSfuTrackIfReady() {
        val d = sfuEngine?.diagnostics() ?: return
        if (d.sessionId.isNotBlank() && d.localTrackName.isNotBlank()) {
            publishSfuTrackAnnouncement(d.sessionId, d.localTrackName)
        }
    }

    private fun publishSfuTrackAnnouncement(sessionId: String, trackName: String) {
        if (!signalingConnected.get()) return
        val payload = JSONObject()
            .put("sessionId", sessionId)
            .put("trackName", trackName)
            .toString()
        publishSignal(SignalPacket(nodeId, BROADCAST_ID, SignalType.SFU_TRACK, payload))
    }

    private fun handleSfuTrackSignal(signal: SignalPacket) {
        val json = runCatching { JSONObject(signal.payload) }.getOrNull() ?: return
        val remoteSessionId = json.optString("sessionId")
        val remoteTrackName = json.optString("trackName")
        if (remoteSessionId.isBlank() || remoteTrackName.isBlank()) return
        ensureSfuStarted()
        sfuEngine?.subscribe(remoteSessionId, remoteTrackName)
    }

    private fun handleSignal(signal: SignalPacket) {
        if (signal.from == nodeId) return
        if (signal.to != nodeId && signal.to != BROADCAST_ID) return

        when (signal.type) {
            SignalType.OFFER -> handleOffer(signal)
            SignalType.ANSWER -> handleAnswer(signal)
            SignalType.CANDIDATE -> if (!forceSfuForTesting) handleCandidate(signal)
            SignalType.SFU_TRACK -> {
                // vc76: SFU wins in AUTO. If a remote rider already advertises an SFU track,
                // immediately converge this device to the same media engine instead of
                // continuing to retransmit P2P offers into a split room.
                if (adaptiveOnlineEngine && !forceSfuForTesting) {
                    forceSfuForTesting = true
                    forceTurnForTesting = false
                    closeAllPeerConnections()
                    ensureSfuStarted()
                    listener.onInternetState(true, "AUTO • SFU • REMOTE SELECTED SFU")
                }
                if (forceSfuForTesting) handleSfuTrackSignal(signal)
            }
            SignalType.BYE -> {
                peers.remove(signal.from)
                if (!forceSfuForTesting) closePeer(signal.from, sendBye = false)
            }
        }
    }

    private fun publishSignal(signal: SignalPacket) {
        if (!signalingConnected.get()) return
        runCatching { sendMqttPublish(signalTopic, encodeSignal(signal)) }
            .onFailure { recordError("Signal send: ${it.javaClass.simpleName}: ${it.message ?: "error"}") }
    }

    private fun notifyPeerCount(force: Boolean = false) {
        val count = peers.size
        val previous = reportedPeerCount.getAndSet(count)
        if (force || previous != count) listener.onInternetPeerCount(count)
    }

    @SuppressLint("MissingPermission")
    private fun selectAudioRoute(): String {
        val manager = audioManager ?: return "WEBRTC AUDIO READY"
        return try {
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
            val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val available = manager.availableCommunicationDevices
                val helmet = available.firstOrNull { it.isVoiceBluetoothDevice() }
                val speaker = available.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                val earpiece = available.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }

                val chosen = when (audioRoute) {
                    "HELMET" -> helmet ?: speaker ?: earpiece
                    "PHONE" -> speaker ?: earpiece
                    else -> helmet ?: speaker ?: earpiece
                }

                if (chosen == null) {
                    "WEBRTC AUDIO • NO COMMUNICATION DEVICE"
                } else {
                    val ok = manager.setCommunicationDevice(chosen)
                    val label = chosen.voiceRouteLabel()
                    if (ok) "WEBRTC OPUS • $label" else "WEBRTC ROUTE FAILED • $label"
                }
            } else {
                @Suppress("DEPRECATION")
                val hasSco = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                    .any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                val useBluetooth = when (audioRoute) {
                    "HELMET" -> hasSco
                    "PHONE" -> false
                    else -> hasSco
                }
                @Suppress("DEPRECATION")
                if (useBluetooth) {
                    manager.isSpeakerphoneOn = false
                    manager.startBluetoothSco()
                    manager.isBluetoothScoOn = true
                    "WEBRTC OPUS • BLUETOOTH HELMET"
                } else {
                    manager.stopBluetoothSco()
                    manager.isBluetoothScoOn = false
                    manager.isSpeakerphoneOn = true
                    "WEBRTC OPUS • PHONE AUDIO"
                }
            }
            audioStatus = result
            result
        } catch (t: Throwable) {
            val result = "WEBRTC AUDIO ROUTE ERROR • ${t.javaClass.simpleName}"
            audioStatus = result
            recordError(result)
            result
        }
    }

    private fun AudioDeviceInfo.isVoiceBluetoothDevice(): Boolean = when (type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> true
        else -> false
    }

    private fun AudioDeviceInfo.voiceRouteLabel(): String = when (type) {
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_BLE_HEADSET,
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> "BLUETOOTH HELMET"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "PHONE SPEAKER"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "PHONE EARPIECE"
        else -> productName?.toString()?.uppercase()?.take(32) ?: "AUDIO DEVICE"
    }

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
            when (change) {
                AudioManager.AUDIOFOCUS_GAIN -> resumeAfterExternalAudio()

                // Phone/VoIP style interruptions are normally transient. RideMesh yields
                // completely, releases the communication route, and auto-resumes later.
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pauseForExternalAudio()

                // Navigation/prompts that only ask us to duck must not tear down the ride.
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                    if (!focusPaused && running.get()) {
                        audioStatus = if (userMuted) {
                            "MIC MUTED • MUSIC / NAV MIX ACTIVE"
                        } else {
                            "VOICE CONNECTED • MUSIC / NAV MIX ACTIVE"
                        }
                        listener.onInternetAudioStatus(audioStatus)
                    }
                }

                // A normal media player commonly asks for long-lived GAIN. Re-acquire
                // MAY_DUCK focus after a tiny settle period so the music app can stay
                // playing at reduced volume while RideMesh voice remains live.
                AudioManager.AUDIOFOCUS_LOSS -> recoverMusicMixFocus()
            }
        }

        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attributes)
            .setAcceptsDelayedFocusGain(true)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener(focusListener)
            .build()

        val result = manager.requestAudioFocus(audioFocusRequest!!)
        focusPaused = result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        applyVoiceEnabled()
        if (!focusPaused) {
            audioStatus = if (userMuted) {
                "MIC MUTED • MUSIC MIX READY"
            } else {
                "VOICE CONNECTED • MUSIC MIX READY"
            }
            listener.onInternetAudioStatus(audioStatus)
        }
    }

    private fun recoverMusicMixFocus() {
        if (!running.get() || focusPaused) return
        if (!mediaFocusRecoveryPending.compareAndSet(false, true)) return

        Thread({
            try {
                Thread.sleep(MEDIA_FOCUS_RECOVERY_MS)
            } catch (_: InterruptedException) {
                mediaFocusRecoveryPending.set(false)
                return@Thread
            }

            mediaFocusRecoveryPending.set(false)
            if (!running.get() || focusPaused) return@Thread
            val manager = audioManager ?: return@Thread
            val request = audioFocusRequest ?: return@Thread

            when (manager.requestAudioFocus(request)) {
                AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                    applyVoiceEnabled()
                    audioStatus = if (userMuted) {
                        "MIC MUTED • MUSIC PLAYING"
                    } else {
                        "VOICE CONNECTED • MUSIC PLAYING"
                    }
                    listener.onInternetAudioStatus(audioStatus)
                }

                AudioManager.AUDIOFOCUS_REQUEST_DELAYED,
                AudioManager.AUDIOFOCUS_REQUEST_FAILED -> {
                    // A locked high-priority owner is much more likely to be a real
                    // phone/VoIP call than ordinary media. Yield instead of fighting it.
                    pauseForExternalAudio()
                }
            }
        }, "RideMesh-MediaFocus").apply {
            isDaemon = true
            start()
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        audioFocusRequest?.let { runCatching { manager.abandonAudioFocusRequest(it) } }
        audioFocusRequest = null
        mediaFocusRecoveryPending.set(false)
        focusPaused = false
    }

    private fun pauseForExternalAudio() {
        if (focusPaused) return
        focusPaused = true
        applyVoiceEnabled()
        sessions.values.forEach { session ->
            runCatching { session.pc.setAudioPlayout(false) }
            runCatching { session.pc.setAudioRecording(false) }
        }
        clearCommunicationRoute()
        audioStatus = "CALL / OTHER AUDIO ACTIVE • RIDEMESH PAUSED"
        listener.onInternetAudioStatus(audioStatus)
    }

    private fun resumeAfterExternalAudio() {
        if (!focusPaused) return
        focusPaused = false
        Thread({
            try {
                Thread.sleep(CALL_RESUME_SETTLE_MS)
            } catch (_: InterruptedException) {
                return@Thread
            }
            if (focusPaused || !running.get()) return@Thread
            selectAudioRoute()
            sessions.values.forEach { session ->
                runCatching { session.pc.setAudioPlayout(true) }
                runCatching { session.pc.setAudioRecording(true) }
            }
            applyVoiceEnabled()
            audioStatus = if (userMuted) {
                "MIC MUTED • LISTENING ONLY"
            } else {
                "WEBRTC OPUS • AUDIO RESUMED"
            }
            listener.onInternetAudioStatus(audioStatus)
        }, "RideMesh-CallResume").apply {
            isDaemon = true
            start()
        }
    }

    private fun startSmartDucking() {
        stopSmartDucking(restoreVolume = true)
        lastVoiceActivityMs = 0L
        smartDuckStatsPending.set(false)
        localNoiseFloor = NOISE_FLOOR_INITIAL
        remoteNoiseFloor = NOISE_FLOOR_INITIAL
        localSpeechHits = 0
        remoteSpeechHits = 0
        noiseCalibrationUntilMs = System.currentTimeMillis() + NOISE_CALIBRATION_MS
        smartDuckMusicWasActive = false

        smartDuckThread = Thread({
            try {
                while (running.get() && !Thread.currentThread().isInterrupted) {
                    val manager = audioManager
                    val musicActive = manager?.isMusicActive == true || musicDucked

                    val sleepMs = when {
                        focusPaused || sessions.isEmpty() -> {
                            smartDuckMusicWasActive = false
                            localSpeechHits = 0
                            remoteSpeechHits = 0
                            restoreMusicVolume(manager)
                            SMART_DUCK_NO_MUSIC_POLL_MS
                        }

                        !musicActive -> {
                            if (smartDuckMusicWasActive) {
                                smartDuckMusicWasActive = false
                                localSpeechHits = 0
                                remoteSpeechHits = 0
                            }
                            restoreMusicVolume(manager)
                            SMART_DUCK_NO_MUSIC_POLL_MS
                        }

                        else -> {
                            if (!smartDuckMusicWasActive) {
                                smartDuckMusicWasActive = true
                                localNoiseFloor = NOISE_FLOOR_INITIAL
                                remoteNoiseFloor = NOISE_FLOOR_INITIAL
                                localSpeechHits = 0
                                remoteSpeechHits = 0
                                noiseCalibrationUntilMs = System.currentTimeMillis() +
                                    SMART_DUCK_MUSIC_CALIBRATION_MS
                            }
                            collectVoiceActivity()
                            applySmartDuckState()
                            if (musicDucked) {
                                SMART_DUCK_DUCKED_POLL_MS
                            } else {
                                SMART_DUCK_ACTIVE_POLL_MS
                            }
                        }
                    }

                    Thread.sleep(sleepMs)
                }
            } catch (_: InterruptedException) {
                // Ride stopped or restarted.
            } finally {
                smartDuckMusicWasActive = false
                restoreMusicVolume()
            }
        }, "RideMesh-SmartDuck").apply {
            isDaemon = true
            start()
        }
    }

    private fun stopSmartDucking(restoreVolume: Boolean) {
        smartDuckThread?.interrupt()
        smartDuckThread = null
        smartDuckStatsPending.set(false)
        if (restoreVolume) restoreMusicVolume()
    }

    private fun collectVoiceActivity() {
        val activeSessions = sessions.values.toList()
        if (activeSessions.isEmpty()) return
        if (!smartDuckStatsPending.compareAndSet(false, true)) return

        synchronized(smartDuckLevelLock) {
            smartDuckRoundLocalMax = 0.0
            smartDuckRoundRemoteMax = 0.0
            smartDuckRoundLocalVadKnown = false
            smartDuckRoundRemoteVadKnown = false
            smartDuckRoundLocalVad = false
            smartDuckRoundRemoteVad = false
        }

        val remaining = AtomicInteger(activeSessions.size)
        activeSessions.forEach { session ->
            runCatching {
                session.pc.getStats { report ->
                    try {
                        var localMax = 0.0
                        var remoteMax = 0.0
                        var localVadKnown = false
                        var remoteVadKnown = false
                        var localVad = false
                        var remoteVad = false

                        report.statsMap.values.forEach { stat ->
                            if (stat.type != "inbound-rtp" && stat.type != "media-source") return@forEach
                            val members = stat.members
                            val kind = (members["kind"] ?: members["mediaType"])?.toString().orEmpty()
                            if (!kind.equals("audio", ignoreCase = true)) return@forEach

                            val level = (members["audioLevel"] as? Number)?.toDouble() ?: 0.0
                            val vad = members["voiceActivityFlag"] as? Boolean

                            if (stat.type == "media-source") {
                                localMax = maxOf(localMax, level)
                                if (vad != null) {
                                    localVadKnown = true
                                    localVad = localVad || vad
                                }
                            } else {
                                remoteMax = maxOf(remoteMax, level)
                                if (vad != null) {
                                    remoteVadKnown = true
                                    remoteVad = remoteVad || vad
                                }
                            }
                        }

                        synchronized(smartDuckLevelLock) {
                            smartDuckRoundLocalMax = maxOf(smartDuckRoundLocalMax, localMax)
                            smartDuckRoundRemoteMax = maxOf(smartDuckRoundRemoteMax, remoteMax)
                            smartDuckRoundLocalVadKnown = smartDuckRoundLocalVadKnown || localVadKnown
                            smartDuckRoundRemoteVadKnown = smartDuckRoundRemoteVadKnown || remoteVadKnown
                            smartDuckRoundLocalVad = smartDuckRoundLocalVad || localVad
                            smartDuckRoundRemoteVad = smartDuckRoundRemoteVad || remoteVad
                        }
                    } finally {
                        if (remaining.decrementAndGet() == 0) {
                            finalizeNoiseAwareVoiceRound()
                            smartDuckStatsPending.set(false)
                        }
                    }
                }
            }.onFailure {
                if (remaining.decrementAndGet() == 0) {
                    finalizeNoiseAwareVoiceRound()
                    smartDuckStatsPending.set(false)
                }
            }
        }
    }

    private fun finalizeNoiseAwareVoiceRound() {
        val snapshot = synchronized(smartDuckLevelLock) {
            NoiseAwareLevels(
                localLevel = smartDuckRoundLocalMax,
                remoteLevel = smartDuckRoundRemoteMax,
                localVadKnown = smartDuckRoundLocalVadKnown,
                remoteVadKnown = smartDuckRoundRemoteVadKnown,
                localVad = smartDuckRoundLocalVad,
                remoteVad = smartDuckRoundRemoteVad,
            )
        }

        val now = System.currentTimeMillis()
        if (now < noiseCalibrationUntilMs) {
            localNoiseFloor = updateNoiseFloor(localNoiseFloor, snapshot.localLevel, NOISE_CALIBRATION_ALPHA)
            remoteNoiseFloor = updateNoiseFloor(remoteNoiseFloor, snapshot.remoteLevel, NOISE_CALIBRATION_ALPHA)
            localSpeechHits = 0
            remoteSpeechHits = 0
            return
        }

        val localThreshold = maxOf(
            LOCAL_SPEECH_ABSOLUTE_MIN,
            localNoiseFloor * LOCAL_NOISE_MULTIPLIER,
            localNoiseFloor + LOCAL_NOISE_MARGIN,
        )
        val remoteThreshold = maxOf(
            REMOTE_SPEECH_ABSOLUTE_MIN,
            remoteNoiseFloor * REMOTE_NOISE_MULTIPLIER,
            remoteNoiseFloor + REMOTE_NOISE_MARGIN,
        )

        val localCandidate = if (snapshot.localVadKnown) {
            snapshot.localVad && snapshot.localLevel >= LOCAL_SPEECH_ABSOLUTE_MIN
        } else {
            snapshot.localLevel >= localThreshold
        }
        val remoteCandidate = if (snapshot.remoteVadKnown) {
            snapshot.remoteVad && snapshot.remoteLevel >= REMOTE_SPEECH_ABSOLUTE_MIN
        } else {
            snapshot.remoteLevel >= remoteThreshold
        }

        localSpeechHits = updateSpeechHits(localSpeechHits, localCandidate)
        remoteSpeechHits = updateSpeechHits(remoteSpeechHits, remoteCandidate)

        // Quiet/non-speech samples follow the environment fairly quickly. Elevated
        // samples move the baseline only very slowly so a spoken sentence does not
        // become the new noise floor, while sustained wind can still be relearned.
        localNoiseFloor = updateNoiseFloor(
            localNoiseFloor,
            snapshot.localLevel,
            if (localCandidate) NOISE_SLOW_RISE_ALPHA else NOISE_TRACK_ALPHA,
        )
        remoteNoiseFloor = updateNoiseFloor(
            remoteNoiseFloor,
            snapshot.remoteLevel,
            if (remoteCandidate) NOISE_SLOW_RISE_ALPHA else NOISE_TRACK_ALPHA,
        )

        if (localSpeechHits >= SPEECH_CONFIRM_HITS || remoteSpeechHits >= SPEECH_CONFIRM_HITS) {
            lastVoiceActivityMs = now
        }
    }

    private fun updateSpeechHits(current: Int, candidate: Boolean): Int {
        return if (candidate) {
            minOf(current + 1, SPEECH_CONFIRM_HITS + 3)
        } else {
            maxOf(0, current - 1)
        }
    }

    private fun updateNoiseFloor(current: Double, sample: Double, alpha: Double): Double {
        if (sample <= 0.0) return current
        val bounded = sample.coerceIn(NOISE_FLOOR_MIN, NOISE_FLOOR_MAX)
        return (current + alpha * (bounded - current)).coerceIn(NOISE_FLOOR_MIN, NOISE_FLOOR_MAX)
    }

    private data class NoiseAwareLevels(
        val localLevel: Double,
        val remoteLevel: Double,
        val localVadKnown: Boolean,
        val remoteVadKnown: Boolean,
        val localVad: Boolean,
        val remoteVad: Boolean,
    )

    private fun applySmartDuckState() {
        val manager = audioManager ?: return
        if (!manager.isMusicActive) {
            restoreMusicVolume(manager)
            return
        }

        val now = System.currentTimeMillis()
        val voiceActive = lastVoiceActivityMs > 0L &&
            now - lastVoiceActivityMs <= SMART_DUCK_HOLD_MS

        if (voiceActive) {
            duckMusicVolume(manager)
        } else {
            restoreMusicVolume(manager)
        }
    }

    private fun duckMusicVolume(manager: AudioManager) {
        if (musicDucked) return

        val current = runCatching {
            manager.getStreamVolume(AudioManager.STREAM_MUSIC)
        }.getOrNull() ?: return
        if (current <= 1) return

        val target = (current * SMART_DUCK_VOLUME_RATIO)
            .toInt()
            .coerceAtLeast(1)
            .coerceAtMost(current - 1)
        if (target >= current) return

        val changed = runCatching {
            manager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            true
        }.getOrDefault(false)
        if (!changed) return

        musicVolumeBeforeDuck = current
        musicDuckTargetVolume = target
        musicDucked = true
        audioStatus = if (userMuted) {
            "MIC MUTED • RIDER TALKING • MUSIC LOWERED"
        } else {
            "VOICE ACTIVE • MUSIC LOWERED"
        }
        listener.onInternetAudioStatus(audioStatus)
    }

    private fun restoreMusicVolume(manager: AudioManager? = audioManager) {
        val original = musicVolumeBeforeDuck
        val target = musicDuckTargetVolume
        val wasDucked = musicDucked

        musicVolumeBeforeDuck = null
        musicDuckTargetVolume = null
        musicDucked = false

        if (!wasDucked || original == null || manager == null) return

        // If the rider manually changed the media volume while it was ducked,
        // respect that adjustment instead of overwriting it with an old value.
        val current = runCatching {
            manager.getStreamVolume(AudioManager.STREAM_MUSIC)
        }.getOrNull()
        if (target != null && current != null && current != target) return

        runCatching {
            manager.setStreamVolume(AudioManager.STREAM_MUSIC, original, 0)
        }
        if (running.get() && !focusPaused) {
            audioStatus = if (userMuted) {
                "MIC MUTED • MUSIC NORMAL"
            } else {
                "VOICE CONNECTED • MUSIC NORMAL"
            }
            listener.onInternetAudioStatus(audioStatus)
        }
    }

    private fun applyVoiceEnabled() {
        val captureAllowed = running.get() && !focusPaused
        onlineSilero?.setAllowed(captureAllowed && !userMuted)
        // In vc62 hybrid mode the WebRTC capture track stays alive while muted so the
        // PRIMARY bridge can continue carrying offline riders to the SFU. The bridge
        // zeros this phone's real microphone before injection when userMuted=true.
        localAudioTrack?.setEnabled(captureAllowed && (hybridBridgeConfigured || !userMuted))
        hybridAudioBridge?.setLocalMicEnabled(captureAllowed && !userMuted)
    }

    @SuppressLint("MissingPermission")
    private fun clearCommunicationRoute() {
        val manager = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                manager.clearCommunicationDevice()
            } else {
                @Suppress("DEPRECATION")
                runCatching { manager.stopBluetoothSco() }
                @Suppress("DEPRECATION")
                runCatching { manager.isBluetoothScoOn = false }
                @Suppress("DEPRECATION")
                runCatching { manager.isSpeakerphoneOn = false }
            }
            manager.mode = AudioManager.MODE_NORMAL
        } catch (_: Throwable) {
            // Another phone/VoIP call owns the route; RideMesh must not fight it.
        }
    }

    private fun preferOpus(sdp: String): String {
        val separator = if (sdp.contains("\r\n")) "\r\n" else "\n"
        val lines = sdp.split(separator).toMutableList()
        val opusLine = lines.firstOrNull {
            it.startsWith("a=rtpmap:", ignoreCase = true) &&
                it.contains("opus/48000", ignoreCase = true)
        } ?: return sdp

        val opusPt = opusLine.substringAfter("a=rtpmap:").substringBefore(' ').trim()
        val mIndex = lines.indexOfFirst { it.startsWith("m=audio ") }
        if (mIndex >= 0) {
            val parts = lines[mIndex].split(' ').toMutableList()
            if (parts.size > 3) {
                val payloads = parts.drop(3).filter { it != opusPt }
                lines[mIndex] = (parts.take(3) + opusPt + payloads).joinToString(" ")
            }
        }

        val fmtpPrefix = "a=fmtp:$opusPt"
        val fmtpIndex = lines.indexOfFirst { it.startsWith(fmtpPrefix, ignoreCase = true) }
        if (fmtpIndex >= 0) {
            var fmtp = lines[fmtpIndex]
            if (!fmtp.contains("useinbandfec=1", ignoreCase = true)) fmtp += ";useinbandfec=1"
            if (!fmtp.contains("usedtx=", ignoreCase = true)) fmtp += ";usedtx=1"
            if (!fmtp.contains("minptime=", ignoreCase = true)) fmtp += ";minptime=10"
            if (!fmtp.contains("maxaveragebitrate=", ignoreCase = true)) fmtp += ";maxaveragebitrate=56000"
            if (!fmtp.contains("maxplaybackrate=", ignoreCase = true)) fmtp += ";maxplaybackrate=48000"
            if (!fmtp.contains("cbr=", ignoreCase = true)) fmtp += ";cbr=0"
            if (!fmtp.contains("stereo=", ignoreCase = true)) fmtp += ";stereo=0"
            lines[fmtpIndex] = fmtp
        } else {
            val rtpIndex = lines.indexOf(opusLine)
            if (rtpIndex >= 0) {
                lines.add(rtpIndex + 1, "$fmtpPrefix minptime=10;useinbandfec=1;usedtx=1;maxaveragebitrate=56000;maxplaybackrate=48000;cbr=0;stereo=0")
            }
        }
        return lines.joinToString(separator)
    }

    private fun recordError(message: String) {
        lastError = message.take(240)
    }

    // -------------------------------------------------------------------------
    // MQTT 3.1.1 signaling transport
    // -------------------------------------------------------------------------

    private fun sendMqttPublish(topic: String, payload: ByteArray) {
        val topicBytes = topic.toByteArray(Charsets.UTF_8)
        val variable = ByteArrayOutputStream().apply {
            writeUtf8(topicBytes)
            write(payload)
        }.toByteArray()
        sendRaw(fixedPacket(0x30, variable))
    }

    private fun connectPacket(): ByteArray {
        val clientId = "rm4-${nodeId.toString().replace("-", "").take(19)}".toByteArray(Charsets.UTF_8)
        val body = ByteArrayOutputStream().apply {
            writeUtf8("MQTT".toByteArray(Charsets.UTF_8))
            write(0x04)
            write(0x02)
            write((KEEP_ALIVE_SECONDS shr 8) and 0xff)
            write(KEEP_ALIVE_SECONDS and 0xff)
            writeUtf8(clientId)
        }.toByteArray()
        return fixedPacket(0x10, body)
    }

    private fun subscribePacket(topic: String): ByteArray {
        val topicBytes = topic.toByteArray(Charsets.UTF_8)
        val body = ByteArrayOutputStream().apply {
            write(0x00)
            write(0x01)
            writeUtf8(topicBytes)
            write(0x00)
        }.toByteArray()
        return fixedPacket(0x82, body)
    }

    private fun sendRaw(packet: ByteArray) {
        val out = output ?: throw IllegalStateException("Signaling socket not connected")
        synchronized(outputLock) {
            out.write(packet)
            out.flush()
        }
    }

    private data class MqttPacket(val type: Int, val body: ByteArray)

    private fun readPacket(input: BufferedInputStream): MqttPacket {
        val first = input.read()
        if (first < 0) throw EOFException()
        val remaining = readRemainingLength(input)
        val body = ByteArray(remaining)
        DataInputStream(input).readFully(body)
        return MqttPacket((first ushr 4) and 0x0f, body)
    }

    private fun readRemainingLength(input: BufferedInputStream): Int {
        var multiplier = 1
        var value = 0
        var loops = 0
        while (true) {
            val digit = input.read()
            if (digit < 0) throw EOFException()
            value += (digit and 127) * multiplier
            if ((digit and 128) == 0) return value
            multiplier *= 128
            loops++
            if (loops >= 4) throw IllegalStateException("Malformed MQTT remaining length")
        }
    }

    private fun fixedPacket(header: Int, body: ByteArray): ByteArray {
        val remaining = encodeRemainingLength(body.size)
        return ByteArray(1 + remaining.size + body.size).also { packet ->
            packet[0] = header.toByte()
            remaining.copyInto(packet, 1)
            body.copyInto(packet, 1 + remaining.size)
        }
    }

    private fun encodeRemainingLength(length: Int): ByteArray {
        var x = length
        val out = ByteArrayOutputStream(4)
        do {
            var digit = x % 128
            x /= 128
            if (x > 0) digit = digit or 0x80
            out.write(digit)
        } while (x > 0)
        return out.toByteArray()
    }

    private fun ByteArrayOutputStream.writeUtf8(bytes: ByteArray) {
        write((bytes.size shr 8) and 0xff)
        write(bytes.size and 0xff)
        write(bytes)
    }

    private fun nextReconnectDelayMs(): Long {
        val voiceStillActive = voicePeerCount() > 0
        val exponent = reconnectAttempt.coerceAtMost(if (voiceStillActive) 4 else 3)
        val maxDelay = if (voiceStillActive) {
            RECONNECT_MAX_DELAY_WITH_VOICE_MS
        } else {
            RECONNECT_MAX_DELAY_MS
        }
        val base = (RECONNECT_BASE_DELAY_MS * (1L shl exponent)).coerceAtMost(maxDelay)
        reconnectAttempt = (reconnectAttempt + 1).coerceAtMost(8)
        return base + Random.nextLong(0L, RECONNECT_JITTER_MS + 1L)
    }

    private fun closeSocket() {
        signalingConnected.set(false)
        synchronized(outputLock) {
            runCatching { output?.close() }
            output = null
            runCatching { socket?.close() }
            socket = null
        }
    }

    // -------------------------------------------------------------------------
    // Signaling packet encoding
    // -------------------------------------------------------------------------

    private enum class SignalType(val code: Byte) {
        OFFER(1),
        ANSWER(2),
        CANDIDATE(3),
        BYE(4),
        SFU_TRACK(5);

        companion object {
            fun from(code: Byte): SignalType? = entries.firstOrNull { it.code == code }
        }
    }

    private data class SignalPacket(
        val from: UUID,
        val to: UUID,
        val type: SignalType,
        val payload: String = "",
        val mid: String = "",
        val line: Int = -1,
    )

    private fun encodeSignal(packet: SignalPacket): ByteArray {
        val payloadBytes = packet.payload.toByteArray(Charsets.UTF_8)
        val midBytes = packet.mid.toByteArray(Charsets.UTF_8)
        val buffer = ByteBuffer.allocate(SIGNAL_FIXED_BYTES + payloadBytes.size + midBytes.size)
            .order(ByteOrder.BIG_ENDIAN)

        buffer.putInt(SIGNAL_MAGIC)
        buffer.put(SIGNAL_VERSION)
        buffer.put(packet.type.code)
        buffer.putLong(packet.from.mostSignificantBits)
        buffer.putLong(packet.from.leastSignificantBits)
        buffer.putLong(packet.to.mostSignificantBits)
        buffer.putLong(packet.to.leastSignificantBits)
        buffer.putInt(packet.line)
        buffer.putInt(payloadBytes.size)
        buffer.putShort(midBytes.size.toShort())
        buffer.put(payloadBytes)
        buffer.put(midBytes)
        return buffer.array()
    }

    private fun decodeSignal(bytes: ByteArray): SignalPacket? {
        if (bytes.size < SIGNAL_FIXED_BYTES) return null
        return try {
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
            if (buffer.int != SIGNAL_MAGIC || buffer.get() != SIGNAL_VERSION) return null
            val type = SignalType.from(buffer.get()) ?: return null
            val from = UUID(buffer.long, buffer.long)
            val to = UUID(buffer.long, buffer.long)
            val line = buffer.int
            val payloadLength = buffer.int
            val midLength = buffer.short.toInt() and 0xffff
            if (payloadLength < 0 || payloadLength > MAX_SIGNAL_BYTES) return null
            if (midLength > MAX_MID_BYTES) return null
            if (payloadLength + midLength > buffer.remaining()) return null

            val payloadBytes = ByteArray(payloadLength)
            buffer.get(payloadBytes)
            val midBytes = ByteArray(midLength)
            buffer.get(midBytes)
            SignalPacket(
                from = from,
                to = to,
                type = type,
                payload = payloadBytes.toString(Charsets.UTF_8),
                mid = midBytes.toString(Charsets.UTF_8),
                line = line,
            )
        } catch (_: Throwable) {
            null
        }
    }

    // -------------------------------------------------------------------------
    // Live Rider Map location codec. Fixed binary contract for Android/iOS parity.
    // Room isolation is provided by the existing ride-code MQTT topic namespace.
    // -------------------------------------------------------------------------

    internal fun encodeLocation(packet: RiderLocation): ByteArray {
        val nameBytes = packet.displayName.toByteArray(Charsets.UTF_8).let {
            if (it.size > MAX_RIDER_NAME_BYTES) it.copyOf(MAX_RIDER_NAME_BYTES) else it
        }
        val phoneBytes = sanitizePhone(packet.phoneNumber).toByteArray(Charsets.UTF_8).let {
            if (it.size > MAX_PHONE_BYTES) it.copyOf(MAX_PHONE_BYTES) else it
        }
        val qualityCode = when (packet.connectionQuality.lowercase()) {
            "excellent" -> 1
            "good" -> 2
            "poor" -> 3
            "reconnecting" -> 4
            else -> 0
        }
        return ByteBuffer.allocate(LOCATION_FIXED_BYTES + nameBytes.size + phoneBytes.size)
            .order(ByteOrder.BIG_ENDIAN)
            .putInt(LOCATION_MAGIC)
            .put(LOCATION_VERSION)
            .putLong(packet.riderId.mostSignificantBits)
            .putLong(packet.riderId.leastSignificantBits)
            .putLong(packet.timestampMs)
            .putDouble(packet.latitude)
            .putDouble(packet.longitude)
            .putFloat(packet.speedKmh.coerceIn(0f, 450f))
            .putFloat(((packet.heading % 360f) + 360f) % 360f)
            .put(qualityCode.toByte())
            .put(nameBytes.size.toByte())
            .put(nameBytes)
            .put(phoneBytes.size.toByte())
            .put(phoneBytes)
            .array()
    }

    internal fun decodeLocation(payload: ByteArray): RiderLocation? {
        if (payload.size < LOCATION_FIXED_BYTES) return null
        return try {
            val buffer = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN)
            if (buffer.int != LOCATION_MAGIC || buffer.get() != LOCATION_VERSION) return null
            val riderId = UUID(buffer.long, buffer.long)
            val timestampMs = buffer.long
            val latitude = buffer.double
            val longitude = buffer.double
            val speedKmh = buffer.float
            val heading = buffer.float
            val quality = when (buffer.get().toInt() and 0xff) {
                1 -> "Excellent"
                2 -> "Good"
                3 -> "Poor"
                4 -> "Reconnecting"
                else -> "Good"
            }
            if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return null
            if (!buffer.hasRemaining()) return null
            val nameLength = buffer.get().toInt() and 0xff
            if (nameLength > MAX_RIDER_NAME_BYTES || nameLength > buffer.remaining()) return null
            val nameBytes = ByteArray(nameLength)
            buffer.get(nameBytes)
            if (!buffer.hasRemaining()) return null
            val phoneLength = buffer.get().toInt() and 0xff
            if (phoneLength > MAX_PHONE_BYTES || phoneLength > buffer.remaining()) return null
            val phoneBytes = ByteArray(phoneLength)
            buffer.get(phoneBytes)
            RiderLocation(
                riderId = riderId,
                displayName = nameBytes.toString(Charsets.UTF_8).trim().ifBlank { "Rider" },
                latitude = latitude,
                longitude = longitude,
                speedKmh = speedKmh.coerceIn(0f, 450f),
                heading = ((heading % 360f) + 360f) % 360f,
                timestampMs = timestampMs,
                connectionQuality = quality,
                phoneNumber = sanitizePhone(phoneBytes.toString(Charsets.UTF_8)),
            )
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Accept all location representations currently used by RideMesh:
     * 1) Android Beta5.x extended RML1 (existing decoder, includes phone tail)
     * 2) Canonical RML1 v1 used by iOS vc23/vc24 (no phone tail)
     * 3) JSON fallback retained for older experimental iOS builds
     *
     * Voice/signaling is not touched by this compatibility path.
     */
    private fun decodeLocationCompat(payload: ByteArray): RiderLocation? {
        decodeLocation(payload)?.let { return it }
        decodeCanonicalRml1Location(payload)?.let { return it }
        return decodeJsonLocation(payload)
    }

    private fun decodeCanonicalRml1Location(payload: ByteArray): RiderLocation? {
        // 55 bytes is the fixed canonical RML1 header including name-length byte.
        if (payload.size < 55) return null
        return try {
            val buffer = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN)
            if (buffer.int != 0x524D4C31 || buffer.get().toInt() != 1) return null

            val riderId = UUID(buffer.long, buffer.long)
            val timestampMs = buffer.long
            val latitude = buffer.double
            val longitude = buffer.double
            val speedKmh = buffer.float
            val heading = buffer.float
            val qualityRaw = buffer.get().toInt() and 0xff
            val nameLength = buffer.get().toInt() and 0xff

            if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return null
            if (!latitude.isFinite() || !longitude.isFinite()) return null
            if (nameLength > 48 || buffer.remaining() < nameLength) return null

            val nameBytes = ByteArray(nameLength)
            buffer.get(nameBytes)

            // Canonical iOS RML1 v1 quality values:
            // 0=excellent, 1=good, 2=poor, 3=reconnecting.
            val quality = when (qualityRaw) {
                0 -> "Excellent"
                1 -> "Good"
                2 -> "Poor"
                3 -> "Reconnecting"
                else -> "Good"
            }

            RiderLocation(
                riderId = riderId,
                displayName = nameBytes.toString(Charsets.UTF_8).trim().ifBlank { "Rider" },
                latitude = latitude,
                longitude = longitude,
                speedKmh = speedKmh.coerceIn(0f, 450f),
                heading = ((heading % 360f) + 360f) % 360f,
                timestampMs = timestampMs,
                connectionQuality = quality,
                phoneNumber = "",
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun decodeJsonLocation(payload: ByteArray): RiderLocation? {
        val text = payload.toString(Charsets.UTF_8).trim()
        if (!text.startsWith("{")) return null
        return try {
            val root = JSONObject(text)
            val location = root.optJSONObject("location") ?: root
            val rider = root.optJSONObject("rider") ?: root

            fun firstString(source: JSONObject, vararg keys: String): String {
                keys.forEach { key ->
                    if (source.has(key) && !source.isNull(key)) {
                        val value = source.optString(key, "").trim()
                        if (value.isNotBlank()) return value
                    }
                }
                return ""
            }

            fun firstDouble(source: JSONObject, vararg keys: String): Double? {
                keys.forEach { key ->
                    if (source.has(key) && !source.isNull(key)) {
                        val value = source.opt(key)
                        val parsed = when (value) {
                            is Number -> value.toDouble()
                            is String -> value.toDoubleOrNull()
                            else -> null
                        }
                        if (parsed != null && parsed.isFinite()) return parsed
                    }
                }
                return null
            }

            val idText = firstString(
                rider,
                "riderId", "riderID", "rider_id", "nodeId", "nodeID", "id", "origin"
            ).ifBlank {
                firstString(root, "riderId", "riderID", "rider_id", "nodeId", "nodeID", "id", "origin")
            }
            val riderId = runCatching { UUID.fromString(idText) }.getOrNull() ?: return null

            val latitude = firstDouble(location, "latitude", "lat") ?: return null
            val longitude = firstDouble(location, "longitude", "lng", "lon", "long") ?: return null
            if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0) return null

            val speed = (firstDouble(location, "speedKmh", "speedKPH", "speedKph", "speed") ?: 0.0)
                .toFloat().coerceIn(0f, 450f)
            val heading = (firstDouble(location, "heading", "bearing", "course") ?: 0.0)
                .toFloat().let { ((it % 360f) + 360f) % 360f }

            var timestamp = (firstDouble(location, "timestampMs", "timestamp", "time", "ts")
                ?: firstDouble(root, "timestampMs", "timestamp", "time", "ts")
                ?: System.currentTimeMillis().toDouble()).toLong()
            if (timestamp in 1..9_999_999_999L) timestamp *= 1_000L

            val displayName = firstString(rider, "displayName", "riderName", "name")
                .ifBlank { firstString(root, "displayName", "riderName", "name") }
                .ifBlank { "Rider" }
                .take(24)
            val quality = firstString(location, "connectionQuality", "quality")
                .ifBlank { firstString(root, "connectionQuality", "quality") }
                .ifBlank { "Good" }
            val phone = firstString(rider, "phoneNumber", "phone")
                .ifBlank { firstString(root, "phoneNumber", "phone") }

            RiderLocation(
                riderId = riderId,
                displayName = displayName,
                latitude = latitude,
                longitude = longitude,
                speedKmh = speed,
                heading = heading,
                timestampMs = timestamp,
                connectionQuality = quality,
                phoneNumber = sanitizePhone(phone),
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun sanitizePhone(value: String): String = value
        .trim()
        .filter { it.isDigit() || it == '+' || it == ' ' || it == '-' || it == '(' || it == ')' }
        .take(MAX_PHONE_BYTES)

    // -------------------------------------------------------------------------
    // Legacy-compatible presence/audio helpers retained for existing unit tests.
    // -------------------------------------------------------------------------

    internal data class PresencePacket(
        val origin: UUID,
        val timestampMs: Long,
        val riderName: String,
        val deviceName: String,
    )

    internal fun encodePresence(packet: PresencePacket): ByteArray {
        val riderBytes = packet.riderName.toByteArray(Charsets.UTF_8).let {
            if (it.size > MAX_RIDER_NAME_BYTES) it.copyOf(MAX_RIDER_NAME_BYTES) else it
        }
        val deviceBytes = packet.deviceName.toByteArray(Charsets.UTF_8).let {
            if (it.size > MAX_DEVICE_NAME_BYTES) it.copyOf(MAX_DEVICE_NAME_BYTES) else it
        }
        return ByteBuffer.allocate(PRESENCE_BASE_BYTES + 1 + riderBytes.size + 1 + deviceBytes.size)
            .order(ByteOrder.BIG_ENDIAN)
            .putLong(packet.origin.mostSignificantBits)
            .putLong(packet.origin.leastSignificantBits)
            .putLong(packet.timestampMs)
            .put(riderBytes.size.toByte())
            .put(riderBytes)
            .put(deviceBytes.size.toByte())
            .put(deviceBytes)
            .array()
    }

    internal fun decodePresence(payload: ByteArray): PresencePacket? {
        if (payload.size < PRESENCE_BASE_BYTES) return null
        return try {
            val buffer = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN)
            val origin = UUID(buffer.long, buffer.long)
            val timestamp = buffer.long
            if (!buffer.hasRemaining()) return PresencePacket(origin, timestamp, "", "")

            val riderLength = buffer.get().toInt() and 0xff
            if (riderLength > buffer.remaining()) return PresencePacket(origin, timestamp, "", "")
            val riderBytes = ByteArray(riderLength)
            buffer.get(riderBytes)
            val rider = riderBytes.toString(Charsets.UTF_8).trim()
            if (!buffer.hasRemaining()) return PresencePacket(origin, timestamp, rider, "")

            val deviceLength = buffer.get().toInt() and 0xff
            if (deviceLength > buffer.remaining()) return PresencePacket(origin, timestamp, rider, "")
            val deviceBytes = ByteArray(deviceLength)
            buffer.get(deviceBytes)
            PresencePacket(
                origin,
                timestamp,
                rider,
                deviceBytes.toString(Charsets.UTF_8).trim(),
            )
        } catch (_: Throwable) {
            null
        }
    }

    internal data class InternetPacket(
        val origin: UUID,
        val sequence: Int,
        val timestampMs: Long,
        val audio: ByteArray,
    )

    internal fun encode(packet: InternetPacket): ByteArray {
        val buffer = ByteBuffer.allocate(HEADER_BYTES + packet.audio.size).order(ByteOrder.BIG_ENDIAN)
        buffer.putInt(MAGIC)
        buffer.put(VERSION)
        buffer.putLong(packet.origin.mostSignificantBits)
        buffer.putLong(packet.origin.leastSignificantBits)
        buffer.putInt(packet.sequence)
        buffer.putLong(packet.timestampMs)
        buffer.put(packet.audio)
        return buffer.array()
    }

    internal fun decode(bytes: ByteArray): InternetPacket? {
        if (bytes.size < HEADER_BYTES) return null
        return try {
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
            if (buffer.int != MAGIC || buffer.get() != VERSION) return null
            val origin = UUID(buffer.long, buffer.long)
            val sequence = buffer.int
            val timestamp = buffer.long
            val audio = ByteArray(buffer.remaining())
            buffer.get(audio)
            InternetPacket(origin, sequence, timestamp, audio)
        } catch (_: Throwable) {
            null
        }
    }

    private fun sanitizeIdentity(value: String, fallback: String, maxBytes: Int): String {
        val clean = value.trim().replace('|', '/').ifBlank { fallback }
        var result = clean
        while (result.toByteArray(Charsets.UTF_8).size > maxBytes && result.isNotEmpty()) {
            result = result.dropLast(1)
        }
        return result.ifBlank { fallback }
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) = Unit
        override fun onSetSuccess() = Unit
        override fun onCreateFailure(error: String) = Unit
        override fun onSetFailure(error: String) = Unit
    }

    companion object {
        private const val TURN_CREDENTIALS_URL = "https://ridemesh-turn-api.salesautopilotindia.workers.dev/turn-credentials"
        private const val SFU_BACKEND_URL = "https://ridemesh-sfu-backend.salesautopilotindia.workers.dev"
        private const val TURN_HTTP_TIMEOUT_MS = 5_000
        private const val TURN_REFRESH_INTERVAL_MS = 45L * 60L * 1000L

        private const val PUBLIC_BROKER = "broker.hivemq.com"
        private const val PUBLIC_BROKER_TLS_PORT = 8883
        private const val KEEP_ALIVE_SECONDS = 30
        private const val SOCKET_TIMEOUT_MS = 3_000
        private const val PING_INTERVAL_MS = 24_000L
        private const val PRESENCE_DISCOVERY_INTERVAL_MS = 1_000L
        private const val PRESENCE_STABLE_INTERVAL_MS = 3_000L
        private const val PRESENCE_TIMEOUT_MS = 14_000L
        private const val OFFER_RETRY_INTERVAL_MS = 2_000L
        private const val ICE_DISCONNECTED_GRACE_MS = 6_000L
        private const val ICE_FAILED_RETRY_MS = 1_000L
        private const val CALL_RESUME_SETTLE_MS = 650L
        private const val MEDIA_FOCUS_RECOVERY_MS = 180L
        private const val SMART_DUCK_NO_MUSIC_POLL_MS = 500L
        private const val SMART_DUCK_ACTIVE_POLL_MS = 200L
        private const val SMART_DUCK_DUCKED_POLL_MS = 300L
        private const val SMART_DUCK_MUSIC_CALIBRATION_MS = 600L
        private const val SMART_DUCK_HOLD_MS = 900L
        private const val SMART_DUCK_VOLUME_RATIO = 0.22
        private const val NOISE_CALIBRATION_MS = 1_500L
        private const val NOISE_FLOOR_INITIAL = 0.004
        private const val NOISE_FLOOR_MIN = 0.001
        private const val NOISE_FLOOR_MAX = 0.30
        private const val NOISE_CALIBRATION_ALPHA = 0.30
        private const val NOISE_TRACK_ALPHA = 0.12
        private const val NOISE_SLOW_RISE_ALPHA = 0.012
        private const val LOCAL_SPEECH_ABSOLUTE_MIN = 0.018
        private const val REMOTE_SPEECH_ABSOLUTE_MIN = 0.012
        private const val LOCAL_NOISE_MULTIPLIER = 3.0
        private const val REMOTE_NOISE_MULTIPLIER = 2.5
        private const val LOCAL_NOISE_MARGIN = 0.010
        private const val REMOTE_NOISE_MARGIN = 0.007
        private const val SPEECH_CONFIRM_HITS = 2

        private const val RECONNECT_BASE_DELAY_MS = 1_000L
        private const val RECONNECT_MAX_DELAY_MS = 8_000L
        private const val RECONNECT_MAX_DELAY_WITH_VOICE_MS = 16_000L
        private const val RECONNECT_JITTER_MS = 500L

        private const val CONNECTION_HEALTH_POLL_MS = 4_000L
        private const val AUDIO_ROUTE_RECOVERY_MS = 550L
        private val AUDIO_ROUTE_RECOVERY_TOKEN = Any()
        private const val NETWORK_HANDOVER_GRACE_MS = 1_500L
        private const val SFU_MEDIA_HEALTHY_AGE_MS = 2_500L
        private val NETWORK_HANDOVER_RECOVERY_TOKEN = Any()

        private const val QUALITY_EXCELLENT_LOSS_PERCENT = 2.0
        private const val QUALITY_EXCELLENT_RTT_MS = 180.0
        private const val QUALITY_EXCELLENT_JITTER_MS = 25.0
        private const val QUALITY_POOR_LOSS_PERCENT = 7.0
        private const val QUALITY_POOR_RTT_MS = 450.0
        private const val QUALITY_POOR_JITTER_MS = 60.0

        private const val AUDIO_TIER_POOR = 1
        private const val AUDIO_TIER_GOOD = 2
        private const val AUDIO_TIER_EXCELLENT = 3

        private const val LOCAL_AUDIO_TRACK_ID = "ridemesh-audio"
        private const val MEDIA_STREAM_ID = "ridemesh-stream"
        private const val WEBRTC_NODE_ID_KEY = "beta4_webrtc_node_id"

        private val BROADCAST_ID = UUID(0L, 0L)

        private const val SIGNAL_MAGIC = 0x524D5334 // RMS4
        private const val SIGNAL_VERSION: Byte = 1
        private const val SIGNAL_FIXED_BYTES = 48
        private const val MAX_SIGNAL_BYTES = 128_000
        private const val MAX_MID_BYTES = 512

        private const val LOCATION_MAGIC = 0x524D4C31 // RML1
        private const val LOCATION_VERSION: Byte = 1
        private const val LOCATION_FIXED_BYTES = 56
        private const val MAX_PHONE_BYTES = 32

        private const val PRESENCE_BASE_BYTES = 24
        private const val MAX_RIDER_NAME_BYTES = 48
        private const val MAX_DEVICE_NAME_BYTES = 64

        private const val MAGIC = 0x524D4931 // RMI1 legacy unit-test codec
        private const val VERSION: Byte = 1
        private const val HEADER_BYTES = 33
    }
}
