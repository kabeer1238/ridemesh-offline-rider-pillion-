package com.bikemesh.ridemesh.audio

/** Build 43 analysis-only conversion. Never used for WebRTC playback or transmission. */
internal object OnlineVadPolicy {
    /** Convert one 10 ms mono PCM16 WebRTC observation to a 10 ms 16 kHz Silero-only copy. */
    fun analysisFrame(input: ByteArray, rate: Int): ByteArray {
        require(rate in intArrayOf(8_000, 16_000, 32_000, 48_000))
        require(input.size == rate / 100 * 2)
        fun sample(index: Int): Int =
            ((input[index * 2].toInt() and 255) or
                (input[index * 2 + 1].toInt() shl 8)).toShort().toInt()
        val output = ByteArray(320)
        for (i in 0 until 160) {
            val value = if (rate == 8_000) sample(i / 2) else {
                val ratio = rate / 16_000
                var sum = 0
                for (j in 0 until ratio) sum += sample(i * ratio + j)
                sum / ratio
            }
            output[i * 2] = value.toByte()
            output[i * 2 + 1] = (value shr 8).toByte()
        }
        return output
    }
}
