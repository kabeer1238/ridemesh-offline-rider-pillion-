
package com.bikemesh.ridemesh.offline

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.bikemesh.ridemesh.transport.WifiAwareWireProtocol
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** September 11 Opus/router/transport integration, extended for eight-rider hybrid field tests.
 * vc55: the receive callback carries codec-tagged frames (PCM or Opus) to AudioEngine,
 * which reorders them and calls [decodeForPlayout] in sequence order.
 */
class OfflineMeshController(
    context: Context,
    private val onLog: (String) -> Unit,
    private val onAudioFrame: (String, Int, Long, ByteArray) -> Unit = { _, _, _, _ -> },
    private val internetPeers: () -> Set<String> = { emptySet() },
    private val internetSend: (String, ByteArray) -> Boolean = { _, _ -> false },
    private val bridgeCandidate: () -> Boolean = { false },
) : NearbyClusterTransport.Listener {
    data class PeerDetails(val nodeId: String, val riderName: String, val deviceName: String, val rttMs: Int?)
    data class ReachablePeer(val nodeId: String, val riderName: String, val deviceName: String, val hops: Int)
    private data class Presence(val peer: ReachablePeer, val at: Long)
    private val appContext = context.applicationContext
    private val opus = OpusVoiceCodec()
    private val handler = Handler(Looper.getMainLooper())
    private val roster = ConcurrentHashMap<String, Presence>()
    private val rtt = ConcurrentHashMap<String, Int>()
    private val tx = AtomicLong()
    private val rx = AtomicLong()
    private val dropped = AtomicLong()
    private val maxHops = AtomicInteger()
    private val directSequence = AtomicInteger()
    private val remoteGenerations = ConcurrentHashMap<String, Int>()
    private val generationChanges = AtomicLong()
    private val staleGenerationDrops = AtomicLong()
    private val invalidDirectPackets = AtomicLong()

    // ---- vc55 direct-link audio ----
    private val batcher = DirectFrameBatcher(FRAMES_PER_BATCH, MAX_FRAME_GAP_MS)
    @Volatile private var batcherGeneration = 0
    private var activeLabRole = 0
    @Volatile private var lastTxCodec = -1
    private val txPcmFrames = AtomicLong()
    private val txOpusFrames = AtomicLong()
    private val txOpusBytes = AtomicLong()
    private val opusEncodeFailures = AtomicLong()
    private val congestionDrops = AtomicLong()
    private val rxBatches = AtomicLong()
    private val rxPcmFrames = AtomicLong()
    private val rxOpusFrames = AtomicLong()
    private val plcFrames = AtomicLong()
    private val decodeFailures = AtomicLong()
    private val lastRxCodec = ConcurrentHashMap<String, Int>()
    private val lastPcmBySource = ConcurrentHashMap<String, ByteArray>()
    private val plcRunBySource = ConcurrentHashMap<String, Int>()
    private val delayLock = Any()
    private var minTransitMs = Long.MAX_VALUE
    @Volatile private var addedDelayMs = 0L
    @Volatile private var maxAddedDelayMs = 0L
    @Volatile private var startedAtElapsedMs = 0L
    @Volatile private var cluster: NearbyClusterTransport? = null
    @Volatile private var router: MeshRelayRouter? = null
    @Volatile private var localNodeId: UUID? = null
    @Volatile private var status = "STOPPED"
    private var presencePayload = ByteArray(0)
    private var presenceName = ""
    private var presenceDevice = ""
    private var election: GatewayElection? = null
    private val internetTx = AtomicLong()
    @Volatile private var hybridMode = false
    private val bridgeCandidates = ConcurrentHashMap<String, Long>()

    fun primaryBridgeId(): String? {
        if (!hybridMode) return null
        val now = SystemClock.elapsedRealtime()
        bridgeCandidates.entries.removeAll { now - it.value > BRIDGE_LEASE_MS }
        val candidates = bridgeCandidates.keys.toMutableSet()
        val local = localNodeId?.toString()
        if (local != null && bridgeCandidate()) candidates.add(local)
        return candidates.minOrNull()
    }
    fun isPrimaryBridge(): Boolean {
        val local = localNodeId?.toString() ?: return false
        return hybridMode && bridgeCandidate() && primaryBridgeId() == local
    }
    fun bridgeSummary(): String {
        val role = when {
            !hybridMode -> "OFF"
            isPrimaryBridge() -> "PRIMARY"
            bridgeCandidate() -> "BACKUP"
            else -> "OFFLINE RIDER"
        }
        return "Hybrid bridge: $role • candidate=${bridgeCandidate()} • elected=${primaryBridgeId()?.take(8) ?: "NONE"} • local=${localNodeId?.toString()?.take(8) ?: "NONE"} • local riders=${reachablePeerDetails().size + if (isActive()) 1 else 0}"
    }
    private fun announce() {
        presencePayload = JSONObject().put("name", presenceName).put("device", presenceDevice)
            .put("bridgeCandidate", bridgeCandidate())
            .put("gateways", org.json.JSONArray(internetPeers().toList())).toString().toByteArray()
        router?.originatePresence(presencePayload)
    }
    fun receiveInternet(peer: String, bytes: ByteArray) {
        val packet = RideMeshEnvelope.decode(bytes) ?: return
        if (packet.internetHops != 1 || peer !in internetPeers()) return
        router?.receive(peer, bytes)
    }
    private val heartbeat = object : Runnable {
        override fun run() {
            if (!isActive()) return
            announce()
            val now = SystemClock.elapsedRealtime()
            roster.entries.removeAll { now - it.value.at > 8000 }
            bridgeCandidates.entries.removeAll { now - it.value > BRIDGE_LEASE_MS }
            handler.postDelayed(this, 2000)
        }
    }
    fun start(riderName: String, rideCode: String, deviceName: String = "Android device", labRole: Int = 0, sharedNodeId: UUID? = null, hybridMode: Boolean = false) {
        stop()
        this.hybridMode = hybridMode
        activeLabRole = labRole
        val code = rideCode.trim().uppercase(java.util.Locale.ROOT)
        require(code.matches(Regex("[A-Z0-9]{5,12}"))) { "Invalid ride code" }
        // Per-ride identity prevents a sequence reset being mistaken for stale audio on peers.
        val node = sharedNodeId ?: UUID.randomUUID()
        election = GatewayElection(node.toString(), SystemClock::elapsedRealtime)
        presenceName = riderName.take(24)
        presenceDevice = deviceName.take(48)
        localNodeId = node
        presencePayload = JSONObject().put("name", riderName.take(24)).put("device", deviceName.take(48))
            .toString().toByteArray(Charsets.UTF_8)
        val transport = NearbyClusterTransport(appContext, node.toString(), riderName,
            WifiAwareWireProtocol.rideToken(code), deviceName, this, labRole, hybridMesh = hybridMode)
        cluster = transport
        router = if (hybridMode) {
            MeshRelayRouter(
                localNodeId = node,
                sendToNeighborsExcept = { exclude, bytes -> transport.sendExceptNode(exclude, bytes) },
                onDeliver = { envelope ->
                    if (envelope.originNodeId != node && isActive()) {
                        val source = envelope.originNodeId.toString()
                        val hops = envelope.hopCount + 1
                        maxHops.updateAndGet { old -> maxOf(old, hops) }
                        when (envelope.type) {
                            RideMeshEnvelope.Type.AUDIO -> {
                                // vc68 hybrid media now carries the same four-frame RMD2 batch
                                // used by the vc56 direct path. Keep a one-frame fallback only so
                                // mixed diagnostic builds fail soft during development.
                                val batch = DirectAudioBatch.decode(envelope.payload)
                                if (batch != null) {
                                    deliverAudioBatch(source, envelope.sequence, envelope.createdAtMs, batch)
                                } else if (envelope.payload.size in 2..2048) {
                                    rx.incrementAndGet()
                                    onAudioFrame(source, envelope.sequence, envelope.createdAtMs, envelope.payload)
                                } else dropped.incrementAndGet()
                            }
                            RideMeshEnvelope.Type.PRESENCE -> runCatching {
                                val json = JSONObject(String(envelope.payload, Charsets.UTF_8))
                                if (envelope.internetHops == 0) {
                                    if (json.optBoolean("bridgeCandidate", false)) bridgeCandidates[source] = SystemClock.elapsedRealtime()
                                    else bridgeCandidates.remove(source)
                                }
                                if (roster.size < 7 || roster.containsKey(source)) {
                                    roster[source] = Presence(
                                        ReachablePeer(
                                            source,
                                            json.optString("name", "Rider").take(24),
                                            json.optString("device", "Android device").take(48),
                                            hops,
                                        ),
                                        SystemClock.elapsedRealtime(),
                                    )
                                }
                            }.let { Unit }
                            RideMeshEnvelope.Type.DIAGNOSTIC -> onLog("HYBRID ROUTE • $hops hops • ${source.take(8)}")
                            else -> Unit
                        }
                    }
                },
                onStatus = onLog,
                // SFU bridging is PCM inside InternetNode, not envelope tunnelling.
                sendToInternet = { false },
            )
        } else null
        startedAtElapsedMs = SystemClock.elapsedRealtime()
        transport.start()
        if (hybridMode) {
            status = "VC68 HYBRID VC56-MEDIA STARTING"
            handler.post(heartbeat)
            announce()
            onLog("VC68 HYBRID MEDIA • P2P_CLUSTER • vc56 4-frame batch/jitter path • relay + bridge election active")
        } else {
            status = "VC56 KNOWN-GOOD BASELINE STARTING"
            onLog("VC56 BASELINE DIAGNOSTICS • vc55 direct audio behavior locked • codec $CODEC_MODE • $FRAMES_PER_BATCH frames/payload • one peer")
        }
    }
    fun stop() {
        toneActive = false
        toneTask?.let(handler::removeCallbacks); toneTask = null; decodedFrames.set(0)
        handler.removeCallbacks(heartbeat)
        cluster?.stop(); cluster = null; router = null; localNodeId = null
        roster.clear(); bridgeCandidates.clear(); rtt.clear(); tx.set(0); rx.set(0); dropped.set(0); maxHops.set(0)
        directSequence.set(0); remoteGenerations.clear(); generationChanges.set(0); staleGenerationDrops.set(0); invalidDirectPackets.set(0); startedAtElapsedMs = 0L
        batcher.reset(); batcherGeneration = 0; lastTxCodec = -1
        txPcmFrames.set(0); txOpusFrames.set(0); txOpusBytes.set(0); opusEncodeFailures.set(0); congestionDrops.set(0)
        rxBatches.set(0); rxPcmFrames.set(0); rxOpusFrames.set(0); plcFrames.set(0); decodeFailures.set(0)
        lastRxCodec.clear(); lastPcmBySource.clear(); plcRunBySource.clear()
        synchronized(delayLock) { minTransitMs = Long.MAX_VALUE; addedDelayMs = 0L; maxAddedDelayMs = 0L }
        opus.reset(); election = null; internetTx.set(0); hybridMode = false; status = "STOPPED"
    }
    fun isActive() = cluster != null
    fun connectedPeerCount() = cluster?.connectedPeerCount() ?: 0
    fun connectedPeerDetails() = cluster?.peerSnapshots()?.map {
        PeerDetails(it.nodeId, it.riderName, it.deviceName, rtt[it.nodeId])
    }.orEmpty()
    fun reachablePeerDetails() = if (hybridMode) roster.values.map { it.peer }.sortedBy { it.riderName.lowercase() }
        else connectedPeerDetails().map { ReachablePeer(it.nodeId, it.riderName, it.deviceName, 1) }
    fun connectedPeerName() = cluster?.firstPeerName()
    fun currentRttMs(): Int? = rtt.values.firstOrNull()
    fun diagnosticSummary(): String {
        val t = cluster?.stats()
        return if (t == null) status else buildString {
            append(status)
            append(" | gen=").append(t.connectionGeneration)
            append(" reconnects=").append(t.reconnects)
            append(" txPayload=").append(t.txPayloads).append(" rxPayload=").append(t.rxPayloads)
            append(" txGap=").append(t.lastTxGapMs).append("ms(max ").append(t.maxTxGapMs).append(")")
            append(" rxGap=").append(t.lastRxGapMs).append("ms(max ").append(t.maxRxGapMs).append(")")
        }
    }
    fun audioTxCount() = tx.get()
    private var toneTask: Runnable? = null
    @Volatile private var toneActive = false
    private val decodedFrames = java.util.concurrent.atomic.AtomicLong()
    fun audioPipelineSummary(): String {
        val t = cluster?.stats()
        val elapsedSec = ((SystemClock.elapsedRealtime() - startedAtElapsedMs).coerceAtLeast(1L) / 1000.0)
        val txFps = tx.get() / elapsedSec
        val rxFps = rx.get() / elapsedSec
        val bandwidth = t?.bandwidthQuality ?: DirectCodecPolicy.QUALITY_UNKNOWN
        return buildString {
            appendLine("VC56 KNOWN-GOOD AUDIO BASELINE • vc55 behavior preserved • codec mode $CODEC_MODE • now sending ${DirectCodecPolicy.codecLabel(lastTxCodec)}")
            appendLine("Nearby bandwidth: ${DirectCodecPolicy.qualityLabel(bandwidth)} • changes: ${t?.bandwidthChanges ?: 0} • raw PCM needs HIGH")
            appendLine("Audio TX frames: ${tx.get()} (PCM ${txPcmFrames.get()} / Opus ${txOpusFrames.get()}) • RX frames: ${rx.get()} (PCM ${rxPcmFrames.get()} / Opus ${rxOpusFrames.get()})")
            appendLine("Average audio rate: TX ${"%.1f".format(txFps)} fps • RX ${"%.1f".format(rxFps)} fps • TARGET 50.0 fps while mic active")
            val avgOpus = if (txOpusFrames.get() > 0) txOpusBytes.get() / txOpusFrames.get() else 0
            appendLine("Opus avg frame: $avgOpus bytes • encode failures: ${opusEncodeFailures.get()} • decode failures: ${decodeFailures.get()} • PLC frames: ${plcFrames.get()}")
            appendLine("Congestion drops (sender, frames): ${congestionDrops.get()} • partial-batch discards: ${batcher.discardedFrames} • other drops: ${dropped.get()}")
            appendLine("RX batches: ${rxBatches.get()} • added delay: $addedDelayMs ms (max $maxAddedDelayMs ms) • EXPECTED < 300 ms")
            appendLine("Generation changes: ${generationChanges.get()} • stale generation drops: ${staleGenerationDrops.get()} • invalid direct packets: ${invalidDirectPackets.get()}")
            if (t != null) {
                val offered = t.directAudioFramesSent + t.congestionDroppedFrames
                val dropPct = if (offered > 0) t.congestionDroppedFrames * 100 / offered else 0
                appendLine("Connection generation: ${t.connectionGeneration} • reconnects: ${t.reconnects}")
                appendLine("Nearby payloads TX/RX: ${t.txPayloads}/${t.rxPayloads} • failures: ${t.sendFailed}")
                appendLine("Audio payloads sent/completed/failed/in-flight: ${t.directAudioSent}/${t.directAudioCompleted}/${t.directAudioFailed}/${t.directAudioPending} • max in-flight: ${t.maxDirectAudioPending} (limit ${t.inFlightLimit}) • timed out: ${t.directAudioTimedOut}")
                val txBundlesPerSec = t.directAudioSent / elapsedSec
                val rxBundlesPerSec = rxBatches.get() / elapsedSec
                appendLine("Bundle rate: TX ${"%.2f".format(txBundlesPerSec)}/s • RX ${"%.2f".format(rxBundlesPerSec)}/s • nominal ${"%.2f".format(50.0 / FRAMES_PER_BATCH)}/s")
                appendLine("Nearby completion latency: avg ${t.directCompletionAvgMs} ms • max ${t.directCompletionMaxMs} ms • completion gap ${t.lastCompletionGapMs} ms (max ${t.maxCompletionGapMs})")
                appendLine("Link age: L2 ${t.l2ConnectedForMs} ms • identity ready ${t.identityReadyForMs} ms • bandwidth report age ${t.bandwidthReportAgeMs} ms • first HIGH after L2 ${t.timeToFirstHighBandwidthMs} ms")
                appendLine("Congestion: ${t.congestionDroppedBatches} payloads / ${t.congestionDroppedFrames} frames dropped ($dropPct% of offered audio)")
                appendLine("TX packet gap: ${t.lastTxGapMs} ms • max ${t.maxTxGapMs} ms (normal ~${FRAMES_PER_BATCH * 20} ms)")
                append("RX packet gap: ${t.lastRxGapMs} ms • max ${t.maxRxGapMs} ms")
            }
        }
    }
    fun sendTestTone(allowed: () -> Boolean) {
        toneTask?.let(handler::removeCallbacks)
        toneActive = true
        var frame = 0
        val task = object : Runnable {
            override fun run() {
                if (!isActive() || !allowed() || frame >= 100) { toneTask = null; toneActive = false; return }
                val pcm = java.nio.ByteBuffer.allocate(640).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until 320) pcm.putShort((2600 * kotlin.math.sin(2 * Math.PI * 440 * (frame * 320 + i) / 16000)).toInt().toShort())
                encodeAndSend(pcm.array()); frame += 1
                handler.postDelayed(this, 20)
            }
        }
        toneTask = task; handler.post(task)
    }
    fun audioRxCount() = rx.get()
    fun audioDropCount() = dropped.get() + congestionDrops.get() + (cluster?.realtimeAudioDropped() ?: 0)
    fun relayCount() = router?.relayCount() ?: 0L
    fun maximumHops() = if (hybridMode) maxHops.get() else if (connectedPeerCount() > 0) 1 else 0
    fun transportStats() = cluster?.stats()
    fun hotspotInvitePayload(): String? = null
    fun hotspotCredentialsSummary(): String? = null
    fun transportDescription(): String = cluster?.transportDescription() ?: "STOPPED"
    fun refreshDiscovery(reason: String) { cluster?.refreshDiscovery(reason) }
    fun sendDiagnosticEnvelope(text: String) = router?.originateDiagnostic(text) == true
    fun sendAudioFrame(audio: ByteArray): Boolean {
        // A tone replaces microphone packets; mixing two independently paced
        // encoders into one sequence overfills the receiver's 20 ms jitter clock.
        if (toneActive) return false
        return if (hybridMode) encodeAndSendHybrid(audio) else encodeAndSend(audio)
    }

    /**
     * vc68: hybrid P2P_CLUSTER keeps vc56's media behavior instead of the old vc62
     * one-Opus-frame-per-Nearby-payload path. Four 20 ms frames are batched, RAW PCM16
     * is used when Nearby reports HIGH bandwidth, and Opus is retained as the fallback.
     * The router still owns TTL/dedup/multi-hop; only the media payload is restored.
     */
    @Synchronized
    private fun encodeAndSendHybrid(audio: ByteArray): Boolean {
        val transport = cluster ?: return false
        val r = router ?: return false
        if (!isActive() || connectedPeerCount() == 0) return false
        if (audio.size != OpusVoiceCodec.PCM_FRAME_BYTES) { dropped.incrementAndGet(); return false }

        val generation = transport.connectionGeneration()
        if (generation <= 0) return false
        if (generation != batcherGeneration) {
            batcher.reset()
            batcherGeneration = generation
        }

        val codec = DirectCodecPolicy.codecFor(CODEC_MODE, transport.bandwidthQuality())
        if (codec != lastTxCodec) {
            if (lastTxCodec >= 0) onLog("HYBRID CODEC • ${DirectCodecPolicy.codecLabel(lastTxCodec)} -> ${DirectCodecPolicy.codecLabel(codec)}")
            lastTxCodec = codec
        }
        val encodedFrame = if (codec == DirectAudioBatch.CODEC_OPUS) {
            opus.encode20ms(audio) ?: run { opusEncodeFailures.incrementAndGet(); dropped.incrementAndGet(); return false }
        } else audio.copyOf()

        if (codec == DirectAudioBatch.CODEC_OPUS) {
            txOpusFrames.incrementAndGet(); txOpusBytes.addAndGet(encodedFrame.size.toLong())
        } else txPcmFrames.incrementAndGet()

        val sequence = directSequence.incrementAndGet()
        tx.incrementAndGet()
        val batch = batcher.offer(sequence, SystemClock.elapsedRealtime(), codec, encodedFrame) ?: return true
        val payload = DirectAudioBatch.encode(generation, batch.codec, batch.frames)
        val createdAt = System.currentTimeMillis() - (SystemClock.elapsedRealtime() - batch.firstCaptureMs)
        val sent = r.originateAudioPacket(payload, batch.firstSequence, createdAt)
        if (!sent) {
            dropped.addAndGet(batch.frames.size.toLong())
            return false
        }
        return true
    }
    @Synchronized
    private fun encodeAndSend(audio: ByteArray): Boolean {
        val transport = cluster ?: return false
        val node = localNodeId ?: return false
        if (connectedPeerCount() < 1) return false
        if (audio.size != OpusVoiceCodec.PCM_FRAME_BYTES) { dropped.incrementAndGet(); return false }

        val generation = transport.connectionGeneration()
        if (generation <= 0) return false
        if (generation != batcherGeneration) {
            batcher.reset()
            batcherGeneration = generation
        }

        // vc55: pick the codec per frame from the Nearby bandwidth report.
        val codec = DirectCodecPolicy.codecFor(CODEC_MODE, transport.bandwidthQuality())
        if (codec != lastTxCodec) {
            if (lastTxCodec >= 0) onLog("DIRECT CODEC • ${DirectCodecPolicy.codecLabel(lastTxCodec)} -> ${DirectCodecPolicy.codecLabel(codec)}")
            lastTxCodec = codec
        }
        val frame = if (codec == DirectAudioBatch.CODEC_OPUS) {
            opus.encode20ms(audio) ?: run { opusEncodeFailures.incrementAndGet(); dropped.incrementAndGet(); return false }
        } else {
            audio.copyOf()
        }
        if (codec == DirectAudioBatch.CODEC_OPUS) { txOpusFrames.incrementAndGet(); txOpusBytes.addAndGet(frame.size.toLong()) }
        else txPcmFrames.incrementAndGet()

        val sequence = directSequence.incrementAndGet()
        tx.incrementAndGet()
        val batch = batcher.offer(sequence, SystemClock.elapsedRealtime(), codec, frame) ?: return true

        val directPayload = DirectAudioBatch.encode(generation, batch.codec, batch.frames)
        // createdAtMs is the wall-clock capture time of the first frame in the batch.
        val createdAt = System.currentTimeMillis() - (SystemClock.elapsedRealtime() - batch.firstCaptureMs)
        val envelope = RideMeshEnvelope(
            messageId = UUID.randomUUID(), originNodeId = node, previousHopNodeId = node,
            sequence = batch.firstSequence, createdAtMs = createdAt,
            ttl = 0, hopCount = 0, type = RideMeshEnvelope.Type.AUDIO, payload = directPayload
        )
        return when (transport.sendDirectAudio(envelope.encode(), batch.frames.size)) {
            NearbyClusterTransport.DirectSendResult.SENT -> true
            NearbyClusterTransport.DirectSendResult.CONGESTED -> { congestionDrops.addAndGet(batch.frames.size.toLong()); false }
            NearbyClusterTransport.DirectSendResult.NO_LINK -> { dropped.addAndGet(batch.frames.size.toLong()); false }
        }
    }

    /**
     * Called by AudioEngine's playout thread, in sequence order, for every frame or gap.
     * Incoming frames carry a one-byte codec tag (see [onData]); packet == null means a missing frame.
     */
    fun decodeForPlayout(source: String, packet: ByteArray?, fec: Boolean = false): ByteArray? {
        if (packet == null) return conceal(source)
        if (packet.size < 2) { decodeFailures.incrementAndGet(); return conceal(source) }
        val codec = packet[0].toInt() and 0xff
        val body = packet.copyOfRange(1, packet.size)
        val previousCodec = lastRxCodec.put(source, codec)
        if (previousCodec != null && previousCodec != codec) opus.forgetPeer(source)
        val pcm = when (codec) {
            DirectAudioBatch.CODEC_PCM16 -> body.takeIf { it.size == OpusVoiceCodec.PCM_FRAME_BYTES }
            DirectAudioBatch.CODEC_OPUS -> opus.decode20ms(source, body, fec)
            else -> null
        }
        if (pcm == null) {
            decodeFailures.incrementAndGet()
            return conceal(source)
        }
        decodedFrames.incrementAndGet()
        lastPcmBySource[source] = pcm
        plcRunBySource[source] = 0
        return pcm
    }

    private fun conceal(source: String): ByteArray? {
        val run = (plcRunBySource[source] ?: 0) + 1
        plcRunBySource[source] = run
        if (run > MAX_PLC_FRAMES) return null
        val pcm = if (lastRxCodec[source] == DirectAudioBatch.CODEC_OPUS) {
            opus.conceal20ms(source)
        } else {
            lastPcmBySource[source]?.let { fade(it, if (run <= 1) 0.6 else 0.3) }
        }
        if (pcm != null) plcFrames.incrementAndGet()
        return pcm
    }

    private fun fade(pcm: ByteArray, gain: Double): ByteArray {
        val out = pcm.copyOf()
        var i = 0
        while (i + 1 < out.size) {
            val sample = ((out[i + 1].toInt() shl 8) or (out[i].toInt() and 0xff)).toShort().toInt()
            val faded = (sample * gain).toInt()
            out[i] = (faded and 0xff).toByte()
            out[i + 1] = ((faded shr 8) and 0xff).toByte()
            i += 2
        }
        return out
    }

    override fun onStatus(message: String) { status = message; onLog(message) }
    override fun onPeerConnected(nodeId: String, riderName: String) {
        if (hybridMode) {
            status = "HYBRID CONNECTED • $riderName"
            announce()
            router?.originateDiagnostic("VC62_HYBRID_PROBE")
            onLog("HYBRID LOCAL CONNECTED • $riderName • peers=${connectedPeerCount()} • role=${if (isPrimaryBridge()) "PRIMARY" else if (bridgeCandidate()) "BACKUP" else "OFFLINE"}")
        } else {
            status = "DIRECT CONNECTED • $riderName"
            onLog("DIRECT CONNECTED • $riderName • peers=${connectedPeerCount()} • ${if (activeLabRole == 1) "STAR HUB" else "direct"}")
        }
    }
    override fun onPeerDisconnected(nodeId: String) {
        rtt.remove(nodeId)
        bridgeCandidates.remove(nodeId)
        remoteGenerations.remove(nodeId)
        if (hybridMode) {
            status = "HYBRID LINK LOST • rediscovering"
            onLog("HYBRID LOCAL LINK LOST • bridge election refreshed")
        } else {
            status = "DIRECT DISCONNECTED • rediscovering"
            onLog("DIRECT LINK LOST • stale audio invalidated • rediscovery enabled")
        }
    }
    override fun onRtt(nodeId: String, rttMs: Int) { rtt[nodeId] = rttMs }

    /** Expand one vc56 RMD2 batch back into codec-tagged 20 ms frames. AudioEngine receives
     * them with consecutive sequences/timestamps, so its burst-aware jitter buffer sees exactly
     * the same media cadence as the confirmed-good direct build. */
    private fun deliverAudioBatch(originNode: String, firstSequence: Int, createdAtMs: Long, batch: DirectAudioBatch.Decoded) {
        val previous = remoteGenerations[originNode]
        if (previous != null && batch.generation < previous) {
            staleGenerationDrops.incrementAndGet()
            return
        }
        if (previous == null || batch.generation > previous) {
            remoteGenerations[originNode] = batch.generation
            generationChanges.incrementAndGet()
            synchronized(delayLock) { minTransitMs = Long.MAX_VALUE }
            onLog("REMOTE AUDIO GENERATION • ${originNode.take(8)} • $previous -> ${batch.generation} • fresh playout source")
        }
        synchronized(delayLock) {
            val transit = System.currentTimeMillis() - createdAtMs
            if (transit < minTransitMs) minTransitMs = transit
            addedDelayMs = transit - minTransitMs
            if (addedDelayMs > maxAddedDelayMs) maxAddedDelayMs = addedDelayMs
        }
        rxBatches.incrementAndGet()
        val source = "$originNode#g${batch.generation}"
        val codecTag = batch.codec.toByte()
        batch.frames.forEachIndexed { index, frame ->
            rx.incrementAndGet()
            if (batch.codec == DirectAudioBatch.CODEC_OPUS) rxOpusFrames.incrementAndGet() else rxPcmFrames.incrementAndGet()
            val tagged = ByteArray(frame.size + 1)
            tagged[0] = codecTag
            frame.copyInto(tagged, 1)
            onAudioFrame(source, firstSequence + index, createdAtMs + index * 20L, tagged)
        }
    }

    override fun onData(nodeId: String, payload: ByteArray) {
        if (hybridMode) { router?.receive(nodeId, payload); return }
        val envelope = RideMeshEnvelope.decode(payload) ?: run { invalidDirectPackets.incrementAndGet(); return }
        if (envelope.type != RideMeshEnvelope.Type.AUDIO || envelope.hopCount != 0 || envelope.ttl != 0) {
            invalidDirectPackets.incrementAndGet(); return
        }
        val batch = DirectAudioBatch.decode(envelope.payload) ?: run { invalidDirectPackets.incrementAndGet(); return }
        val originNode = envelope.originNodeId.toString()
        if (activeLabRole == 1 && connectedPeerCount() > 1 && originNode == nodeId) {
            cluster?.forwardDirectAudioExcept(nodeId, payload, batch.frames.size)
        }
        deliverAudioBatch(originNode, envelope.sequence, envelope.createdAtMs, batch)
    }

    companion object {
        /** AUTO = raw PCM only on HIGH (Wi-Fi) bandwidth, Opus otherwise. FORCE_* for lab tests. */
        val CODEC_MODE = DirectCodecPolicy.Mode.AUTO
        /** vc80: 2 x 20 ms = 40 ms of audio per Nearby payload (25 payloads/s).
         * Field vc79 proved receiver smoothing works, while 80 ms bursts still exposed audible
         * scheduling gaps. Smaller direct packets reduce the audio affected by one late burst. */
        const val FRAMES_PER_BATCH = 4
        /** Keep a one-frame partial batch across ordinary scheduler stalls. Codec/sequence
         * discontinuities still flush immediately; a real capture/focus pause flushes after 160 ms. */
        private const val MAX_FRAME_GAP_MS = 60L
        /** Conceal at most 60 ms of missing audio, then play silence. */
        private const val MAX_PLC_FRAMES = 3
        private const val BRIDGE_LEASE_MS = 6_000L
    }
}
