package com.bikemesh.ridemesh.offline

import android.content.Context
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionOptions
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionType
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger

/**
 * Android offline transport using Google Nearby Connections.
 * vc55: direct one-peer test uses [DIRECT_STRATEGY] (P2P_POINT_TO_POINT), a DISRUPTIVE
 * connection type so Nearby may upgrade to Wi-Fi, bandwidth reporting, and bounded
 * (drop-not-queue) real-time audio sending.
 */
class NearbyClusterTransport(
    context: Context,
    private val nodeId: String,
    private val riderName: String,
    private val rideToken: String,
    deviceName: String = "Android device",
    private val listener: Listener,
    private val labRole: Int = 0,
    private val hybridMesh: Boolean = false,
) {
    interface Listener {
        fun onStatus(message: String)
        fun onPeerConnected(nodeId: String, riderName: String)
        fun onPeerDisconnected(nodeId: String)
        fun onRtt(nodeId: String, rttMs: Int)
        fun onData(nodeId: String, payload: ByteArray)
    }

    data class PeerSnapshot(
        val nodeId: String,
        val riderName: String,
        val deviceName: String,
    )

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context.applicationContext)
    // Use all Nearby media for the Android-only baseline. Old BLE test preferences
    // must not silently constrain discovery on an upgraded installation.
    private val bleOnly = false
    private var scheduler = Executors.newSingleThreadScheduledExecutor()
    private val connectedEndpoints = ConcurrentHashMap.newKeySet<String>()
    private val pendingEndpoints = ConcurrentHashMap.newKeySet<String>()
    private val endpointToNode = ConcurrentHashMap<String, String>()
    private val endpointToName = ConcurrentHashMap<String, String>()
    private val endpointToDevice = ConcurrentHashMap<String, String>()
    private val retryAfterMs = ConcurrentHashMap<String, Long>()
    // vc58: temporarily suppress endpoint IDs that Nearby has declared unknown/stale.
    private val staleEndpointUntilMs = ConcurrentHashMap<String, Long>()
    private val helloAttempts = ConcurrentHashMap<String, Int>()

    // A bounded four-packet window tolerates transfer acknowledgements slower than 20 ms.
    // Pending speech is FIFO, age-limited, and fair between speakers.
    private val audioInFlightPayload = ConcurrentHashMap<String, MutableMap<Long, Long>>()
    private val audioLatestPending = ConcurrentHashMap<String, FreshAudioQueue>()
    private val audioSentAt = ConcurrentHashMap<String, Long>()
    private val foundEndpoints = ConcurrentHashMap<String, DiscoveredEndpointInfo>()
    private val pendingSince = ConcurrentHashMap<String, Long>()
    data class Stats(
        val advertising: Boolean, val discovering: Boolean, val found: Int,
        val attempts: Int, val connected: Int, val failed: Int, val pending: Int, val sendFailed: Int,
        val reconnects: Int, val connectionGeneration: Int,
        val txPayloads: Long, val rxPayloads: Long,
        val directAudioSent: Long, val directAudioCompleted: Long, val directAudioFailed: Long,
        val directAudioPending: Int, val maxDirectAudioPending: Int,
        val lastTxGapMs: Long, val maxTxGapMs: Long, val lastRxGapMs: Long, val maxRxGapMs: Long,
        // vc55
        val bandwidthQuality: Int, val bandwidthChanges: Int,
        val directAudioFramesSent: Long,
        val congestionDroppedBatches: Long, val congestionDroppedFrames: Long,
        val directAudioTimedOut: Long, val inFlightLimit: Int,
        // vc56 read-only diagnostics around the known-good vc55 transport path.
        val directCompletionAvgMs: Long, val directCompletionMaxMs: Long,
        val lastCompletionGapMs: Long, val maxCompletionGapMs: Long,
        val l2ConnectedForMs: Long, val identityReadyForMs: Long,
        val bandwidthReportAgeMs: Long, val timeToFirstHighBandwidthMs: Long,
    )
    enum class DirectSendResult { SENT, CONGESTED, NO_LINK }
    @Volatile private var advertising = false
    @Volatile private var discovering = false
    private val discoveryHandler = Handler(Looper.getMainLooper())
    private var advertisingStarting = false
    private var discoveryStarting = false
    private var discoveryEpoch = 0
    @Volatile private var lastDiscoveryError = "NONE"
    fun transportDescription(): String = "${strategyLabel()} • ${if (hybridMesh) "NON_DISRUPTIVE" else "DISRUPTIVE"} • service=$serviceId • ride=$rideToken • advertisingPending=$advertisingStarting • discoveryPending=$discoveryStarting • lastError=$lastDiscoveryError"

    private val attempts = AtomicInteger()
    private val successful = AtomicInteger()
    private val failures = AtomicInteger()
    private val sendFailures = AtomicInteger()
    private val reconnects = AtomicInteger()
    private val connectionGeneration = AtomicInteger()
    private val txPayloads = AtomicLong()
    private val rxPayloads = AtomicLong()
    private val directAudioSent = AtomicLong()
    private val directAudioCompleted = AtomicLong()
    private val directAudioFailed = AtomicLong()
    // vc55: bounded in-flight window replaces vc54's unbounded payload-id set.
    private val starLab = !hybridMesh && labRole in 1..3
    // vc62 hybrid: keep enough direct cluster links for a five-rider nearby group while
    // MeshRelayRouter covers riders that are reachable only through another phone.
    private val maxPeers = if (hybridMesh) HYBRID_MAX_PEERS else if (labRole == 1) 2 else 1
    private val inFlightLimit = if (starLab) STAR_MAX_IN_FLIGHT else DIRECT_MAX_IN_FLIGHT
    private val directGate = InFlightGate(inFlightLimit, DIRECT_IN_FLIGHT_TIMEOUT_MS)
    private val directAudioFramesSent = AtomicLong()
    private val congestionDroppedBatches = AtomicLong()
    private val congestionDroppedFrames = AtomicLong()
    private val bandwidthChanges = AtomicInteger()
    @Volatile private var bandwidthQuality = DirectCodecPolicy.QUALITY_UNKNOWN
    // vc56: measurement only. These counters do not participate in routing, codec selection,
    // queue limits, jitter control or playback.
    private val directCompletionTotalMs = AtomicLong(0)
    private val directCompletionSamples = AtomicLong(0)
    private val directCompletionMaxMs = AtomicLong(0)
    private val lastCompletionAt = AtomicLong(0)
    private val lastCompletionGap = AtomicLong(0)
    private val maxCompletionGap = AtomicLong(0)
    @Volatile private var l2ConnectedAtMs = 0L
    @Volatile private var identityReadyAtMs = 0L
    @Volatile private var lastBandwidthChangedAtMs = 0L
    @Volatile private var firstHighBandwidthAtMs = 0L
    private val lastTxAt = AtomicLong(0)
    private val lastRxAt = AtomicLong(0)
    private val lastTxGap = AtomicLong(0)
    private val maxTxGap = AtomicLong(0)
    private val lastRxGap = AtomicLong(0)
    private val maxRxGap = AtomicLong(0)
    fun stats(): Stats {
        val now = SystemClock.elapsedRealtime()
        val samples = directCompletionSamples.get()
        val avgCompletion = if (samples > 0L) directCompletionTotalMs.get() / samples else 0L
        val l2Age = if (l2ConnectedAtMs > 0L) (now - l2ConnectedAtMs).coerceAtLeast(0L) else 0L
        val identityAge = if (identityReadyAtMs > 0L) (now - identityReadyAtMs).coerceAtLeast(0L) else 0L
        val bandwidthAge = if (lastBandwidthChangedAtMs > 0L) (now - lastBandwidthChangedAtMs).coerceAtLeast(0L) else -1L
        val highUpgradeMs = if (firstHighBandwidthAtMs > 0L && l2ConnectedAtMs > 0L)
            (firstHighBandwidthAtMs - l2ConnectedAtMs).coerceAtLeast(0L) else -1L
        return Stats(
            advertising = advertising, discovering = discovering, found = foundEndpoints.size,
            attempts = attempts.get(), connected = successful.get(), failed = failures.get(),
            pending = pendingEndpoints.size, sendFailed = sendFailures.get(),
            reconnects = reconnects.get(), connectionGeneration = connectionGeneration.get(),
            txPayloads = txPayloads.get(), rxPayloads = rxPayloads.get(),
            directAudioSent = directAudioSent.get(), directAudioCompleted = directAudioCompleted.get(),
            directAudioFailed = directAudioFailed.get(),
            directAudioPending = directGate.size(), maxDirectAudioPending = directGate.maxObserved,
            lastTxGapMs = lastTxGap.get(), maxTxGapMs = maxTxGap.get(),
            lastRxGapMs = lastRxGap.get(), maxRxGapMs = maxRxGap.get(),
            bandwidthQuality = bandwidthQuality, bandwidthChanges = bandwidthChanges.get(),
            directAudioFramesSent = directAudioFramesSent.get(),
            congestionDroppedBatches = congestionDroppedBatches.get(),
            congestionDroppedFrames = congestionDroppedFrames.get(),
            directAudioTimedOut = directGate.timedOut, inFlightLimit = inFlightLimit,
            directCompletionAvgMs = avgCompletion, directCompletionMaxMs = directCompletionMaxMs.get(),
            lastCompletionGapMs = lastCompletionGap.get(), maxCompletionGapMs = maxCompletionGap.get(),
            l2ConnectedForMs = l2Age, identityReadyForMs = identityAge,
            bandwidthReportAgeMs = bandwidthAge, timeToFirstHighBandwidthMs = highUpgradeMs,
        )
    }
    fun bandwidthQuality(): Int = bandwidthQuality
    fun refreshDiscovery(reason: String) { if (started && endpointToNode.size < maxPeers) restartDiscovery() }
    fun connectionGeneration(): Int = connectionGeneration.get()
    private fun allowed(name: String): Boolean {
        val parts = name.split('|', limit = 4)
        if (parts.size != 4 || parts[0] != "RMA1" || parts[2] != rideToken) return false
        if (!starLab) return true
        val remoteRole = parts[1].toIntOrNull() ?: return false
        return when (labRole) {
            1 -> remoteRole == 2 || remoteRole == 3 // A hub accepts B + C
            2, 3 -> remoteRole == 1               // spokes connect only to A
            else -> false
        }
    }
    private val audioDropped = AtomicLong(0)

    @Volatile private var started = false

    private val serviceId = "in.autopilotindia.ridemesh.android.offline1"
    // Include a short node suffix only in discovery identity so deterministic
    // initiator election remains unique even when both riders use the same name.
    private val localEndpointName = "RMA1|$labRole|$rideToken|${sanitize(riderName.ifBlank { "Rider" }).take(14)}-${nodeId.take(8)}"
    private val localDeviceName = sanitize(deviceName.ifBlank { "Android device" }).take(48)

    private fun status(message: String) = listener.onStatus("NEARBY DIAG • $message")

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (!started || endpointId !in connectedEndpoints) return
            val now = SystemClock.elapsedRealtime()
            val previous = lastRxAt.getAndSet(now)
            if (previous > 0) {
                val gap = now - previous
                lastRxGap.set(gap)
                maxRxGap.accumulateAndGet(gap) { a, b -> maxOf(a, b) }
            }
            rxPayloads.incrementAndGet()
            val bytes = payload.asBytes() ?: return
            handleMessage(endpointId, bytes)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            if (!started || update.status == PayloadTransferUpdate.Status.IN_PROGRESS) return
            val directSentAt = directGate.removeAndSentAt(update.payloadId)
            if (directSentAt != null) {
                if (update.status == PayloadTransferUpdate.Status.SUCCESS) {
                    directAudioCompleted.incrementAndGet()
                    val completedAt = SystemClock.elapsedRealtime()
                    val completionMs = (completedAt - directSentAt).coerceAtLeast(0L)
                    directCompletionTotalMs.addAndGet(completionMs)
                    directCompletionSamples.incrementAndGet()
                    directCompletionMaxMs.accumulateAndGet(completionMs) { a, b -> maxOf(a, b) }
                    val previousCompletion = lastCompletionAt.getAndSet(completedAt)
                    if (previousCompletion > 0L) {
                        val gap = completedAt - previousCompletion
                        lastCompletionGap.set(gap)
                        maxCompletionGap.accumulateAndGet(gap) { a, b -> maxOf(a, b) }
                    }
                } else {
                    directAudioFailed.incrementAndGet(); sendFailures.incrementAndGet()
                }
                return
            }
            synchronized(audioInFlightPayload) {
                val flights = audioInFlightPayload[endpointId] ?: return
                if (flights.remove(update.payloadId) == null) return
                if (flights.isEmpty()) audioSentAt.remove(endpointId)
                else audioSentAt[endpointId] = flights.values.minOrNull()!!
                if (update.status != PayloadTransferUpdate.Status.SUCCESS) sendFailures.incrementAndGet()
                drainAudio(endpointId)
            }
        }
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            if (!started) return
            if (!allowed(info.endpointName) || connectedEndpoints.size >= maxPeers) {
                client.rejectConnection(endpointId)
                return
            }
            val name = info.endpointName.ifBlank { "Android rider" }
            endpointToName[endpointId] = name
            status("CONNECTION INITIATED • $name • ${endpointId.take(6)}")
            client.acceptConnection(endpointId, payloadCallback)
                .addOnSuccessListener { status("CONNECTION ACCEPTED • $name") }
                .addOnFailureListener { status("ACCEPT FAILED • ${shortError(it)}") }
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            pendingEndpoints.remove(endpointId)
            pendingSince.remove(endpointId)
            if (!started) return
            if (resolution.status.isSuccess) {
                successful.incrementAndGet()
                retryAfterMs.remove(endpointId)
                connectedEndpoints.add(endpointId)
                l2ConnectedAtMs = SystemClock.elapsedRealtime()
                identityReadyAtMs = 0L
                lastBandwidthChangedAtMs = 0L
                firstHighBandwidthAtMs = 0L
                val generation = connectionGeneration.incrementAndGet()
                status("DIRECT LINK L2 CONNECTED • generation=$generation • endpoint=${endpointId.take(6)}")
                helloAttempts[endpointId] = 0
                status("CONNECTED • ${endpointToName[endpointId] ?: endpointId.take(6)} • exchanging identity")
                sendHello(endpointId)
            } else {
                failures.incrementAndGet()
                val code = resolution.status.statusCode
                retryAfterMs[endpointId] = SystemClock.elapsedRealtime() + RETRY_BACKOFF_MS
                status("CONNECTION FAILED • code=$code • retry in ${RETRY_BACKOFF_MS / 1000}s")
                if (connectedEndpoints.isEmpty()) {
                    scheduler.schedule({ restartDiscovery() }, RETRY_BACKOFF_MS, TimeUnit.MILLISECONDS)
                }
            }
        }

        override fun onBandwidthChanged(endpointId: String, bandwidthInfo: BandwidthInfo) {
            if (!started) return
            val quality = bandwidthInfo.quality
            bandwidthQuality = quality
            lastBandwidthChangedAtMs = SystemClock.elapsedRealtime()
            if (quality == DirectCodecPolicy.QUALITY_HIGH && firstHighBandwidthAtMs == 0L) {
                firstHighBandwidthAtMs = lastBandwidthChangedAtMs
            }
            bandwidthChanges.incrementAndGet()
            status("BANDWIDTH ${DirectCodecPolicy.qualityLabel(quality)} • endpoint=${endpointId.take(6)}")
        }

        override fun onDisconnected(endpointId: String) {
            if (!started) return
            reconnects.incrementAndGet()
            directGate.clear()
            bandwidthQuality = DirectCodecPolicy.QUALITY_UNKNOWN
            l2ConnectedAtMs = 0L; identityReadyAtMs = 0L; lastBandwidthChangedAtMs = 0L; firstHighBandwidthAtMs = 0L
            status("DIRECT LINK DISCONNECTED • endpoint=${endpointId.take(6)} • reconnects=${reconnects.get()}")
            audioSentAt.remove(endpointId)
            pendingSince.remove(endpointId)
            connectedEndpoints.remove(endpointId)
            pendingEndpoints.remove(endpointId)
            helloAttempts.remove(endpointId)
            audioInFlightPayload.remove(endpointId)
            audioLatestPending.remove(endpointId)?.let { audioDropped.addAndGet(it.droppedCount()) }
            val remoteNode = endpointToNode.remove(endpointId)
            val name = endpointToName.remove(endpointId)
            endpointToDevice.remove(endpointId)
            retryAfterMs[endpointId] = SystemClock.elapsedRealtime() + RETRY_BACKOFF_MS

            val isNodeStillConnected = remoteNode != null && endpointToNode.values.contains(remoteNode)
            if (remoteNode != null && !isNodeStillConnected) {
                listener.onPeerDisconnected(remoteNode)
            }

            if (started && connectedEndpoints.size < maxPeers) {
                status("DISCONNECTED • ${name ?: endpointId.take(6)} • rediscovering")
                scheduler.schedule({ restartDiscovery() }, RETRY_BACKOFF_MS, TimeUnit.MILLISECONDS)
            }
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            if (!started || connectedEndpoints.contains(endpointId) || !allowed(info.endpointName)) return
            val nowForStale = SystemClock.elapsedRealtime()
            val staleUntil = staleEndpointUntilMs[endpointId] ?: 0L
            if (nowForStale < staleUntil) return
            if (staleUntil > 0L) staleEndpointUntilMs.remove(endpointId)
            foundEndpoints[endpointId] = info
            val name = info.endpointName.ifBlank { "Android rider" }
            endpointToName[endpointId] = name
            status("ENDPOINT FOUND • $name • ${endpointId.take(6)}")

            if (connectedEndpoints.size >= maxPeers) return

            val now = SystemClock.elapsedRealtime()
            val waitUntil = retryAfterMs[endpointId] ?: 0L
            if (now < waitUntil) {
                status("WAITING RETRY • $name • ${(waitUntil - now + 999) / 1000}s")
                return
            }

            // vc54 direct-link isolation: exactly one side initiates. This prevents
            // simultaneous request collisions from continuously tearing down the pair.
            val remoteEndpointName = info.endpointName
            if (starLab) {
                if (labRole == 1) { status("STAR HUB WAIT • spoke initiates • $name"); return }
            } else if (localEndpointName > remoteEndpointName) {
                status("PASSIVE WAIT • remote initiates • $name")
                return
            }
            if (!pendingEndpoints.add(endpointId)) return
            pendingSince[endpointId] = now
            attempts.incrementAndGet()
            status("REQUESTING CONNECTION • $name")
            client.requestConnection(localEndpointName, endpointId, lifecycleCallback, directConnectionOptions())
                .addOnSuccessListener { status("REQUEST SENT • $name") }
                .addOnFailureListener {
                    if (!started) return@addOnFailureListener
                    pendingEndpoints.remove(endpointId)
                    pendingSince.remove(endpointId)
                    failures.incrementAndGet()
                    val error = shortError(it)
                    val endpointUnknown = error.contains("8011") || error.contains("STATUS_ENDPOINT_UNKNOWN")
                    if (endpointUnknown) {
                        // Nearby can keep surfacing an expired endpoint ID after a disconnect.
                        // Forget it and wait for a fresh endpoint advertisement instead of hammering it.
                        foundEndpoints.remove(endpointId)
                        endpointToName.remove(endpointId)
                        retryAfterMs.remove(endpointId)
                        staleEndpointUntilMs[endpointId] = SystemClock.elapsedRealtime() + STALE_ENDPOINT_SUPPRESS_MS
                        status("STALE ENDPOINT INVALIDATED • ${endpointId.take(6)} • waiting for fresh advertisement")
                        if (connectedEndpoints.size < maxPeers) scheduler.schedule({ restartDiscovery() }, 500, TimeUnit.MILLISECONDS)
                    } else {
                        retryAfterMs[endpointId] = SystemClock.elapsedRealtime() + RETRY_BACKOFF_MS
                        status("REQUEST FAILED • $error • retrying")
                        if (connectedEndpoints.isEmpty()) scheduler.schedule({ restartDiscovery() }, RETRY_BACKOFF_MS, TimeUnit.MILLISECONDS)
                    }
                }
        }

        override fun onEndpointLost(endpointId: String) {
            if (!started) return
            foundEndpoints.remove(endpointId)
            status("ENDPOINT LOST • ${endpointToName[endpointId] ?: endpointId.take(6)}")
        }
    }

    fun start() {
        stop()
        scheduler = Executors.newSingleThreadScheduledExecutor()
        started = true
        status("NEARBY START • ${transportDescription()}")
        restartDiscovery()

        scheduler.scheduleWithFixedDelay({
            if (!started) return@scheduleWithFixedDelay
            val now = SystemClock.elapsedRealtime()
            pendingSince.entries.filter { now - it.value > 12_000 }.forEach {
                pendingSince.remove(it.key); pendingEndpoints.remove(it.key)
                client.disconnectFromEndpoint(it.key)
                retryAfterMs[it.key] = now + RETRY_BACKOFF_MS
            }
            directGate.purgeExpired(now)
            audioSentAt.entries.filter { now - it.value > 1500 }.forEach {
                audioSentAt.remove(it.key)
                synchronized(audioInFlightPayload) {
                    audioInFlightPayload.remove(it.key)?.keys?.forEach { id -> client.cancelPayload(id) }
                }
                client.disconnectFromEndpoint(it.key)
                sendFailures.incrementAndGet()
            }
            foundEndpoints.forEach { (endpoint, info) -> discoveryCallback.onEndpointFound(endpoint, info) }
            connectedEndpoints.forEach { endpointId ->
                synchronized(audioInFlightPayload) { drainAudio(endpointId) }
                if (!endpointToNode.containsKey(endpointId)) {
                    if ((helloAttempts[endpointId] ?: 0) >= 10) client.disconnectFromEndpoint(endpointId)
                    else sendHello(endpointId)
                } else sendRaw(endpointId, "PING|$now".toByteArray())
            }
        }, 1, 1, TimeUnit.SECONDS)
    }

    fun stop() {
        started = false
        discoveryEpoch++
        discoveryHandler.removeCallbacksAndMessages(null)
        advertisingStarting = false; discoveryStarting = false
        lastDiscoveryError = "NONE"
        scheduler.shutdownNow()
        advertising = false; discovering = false
        foundEndpoints.clear(); pendingSince.clear(); audioSentAt.clear()
        runCatching { client.stopAdvertising() }
        runCatching { client.stopDiscovery() }
        runCatching { client.stopAllEndpoints() }
        connectedEndpoints.clear()
        pendingEndpoints.clear()
        endpointToNode.clear()
        endpointToName.clear()
        endpointToDevice.clear()
        retryAfterMs.clear()
        staleEndpointUntilMs.clear()
        helloAttempts.clear()
        audioInFlightPayload.clear()
        audioLatestPending.clear()
        directGate.clear(); directGate.resetStats()
        bandwidthQuality = DirectCodecPolicy.QUALITY_UNKNOWN; bandwidthChanges.set(0)
        l2ConnectedAtMs = 0L; identityReadyAtMs = 0L; lastBandwidthChangedAtMs = 0L; firstHighBandwidthAtMs = 0L
        directCompletionTotalMs.set(0); directCompletionSamples.set(0); directCompletionMaxMs.set(0)
        lastCompletionAt.set(0); lastCompletionGap.set(0); maxCompletionGap.set(0)
        directAudioFramesSent.set(0); congestionDroppedBatches.set(0); congestionDroppedFrames.set(0)
        audioDropped.set(0)
        txPayloads.set(0); rxPayloads.set(0); directAudioSent.set(0); directAudioCompleted.set(0); directAudioFailed.set(0)
        lastTxAt.set(0); lastRxAt.set(0); lastTxGap.set(0); lastRxGap.set(0); maxTxGap.set(0); maxRxGap.set(0)
        attempts.set(0); successful.set(0); failures.set(0); sendFailures.set(0); reconnects.set(0); connectionGeneration.set(0)
    }

    fun connectedPeerCount(): Int = endpointToNode.size
    fun firstPeerName(): String? = endpointToNode.entries.firstOrNull()?.key?.let(endpointToName::get)
    fun realtimeAudioDropped(): Long = audioDropped.get() + audioLatestPending.values.sumOf { it.droppedCount() }

    fun peerSnapshots(): List<PeerSnapshot> = endpointToNode.entries.map { (endpointId, remoteNodeId) ->
        PeerSnapshot(
            nodeId = remoteNodeId,
            riderName = endpointToName[endpointId].orEmpty().ifBlank { "Android rider" },
            deviceName = endpointToDevice[endpointId].orEmpty().ifBlank { "Android device" },
        )
    }.sortedBy { it.riderName.lowercase() }

    @Suppress("unused")
    fun send(payload: ByteArray): Boolean = sendExceptNode(null, payload)

    fun sendExceptNode(excludedNodeId: String?, payload: ByteArray): Boolean {
        if (!started) return false
        val endpoints = connectedEndpoints.filter { endpointId ->
            val peerNodeId = endpointToNode[endpointId]
            peerNodeId != null && peerNodeId != excludedNodeId
        }
        if (endpoints.isEmpty()) return false

        val encoded = ByteArray(DATA_PREFIX.size + payload.size)
        DATA_PREFIX.copyInto(encoded)
        payload.copyInto(encoded, DATA_PREFIX.size)

        val envelope = RideMeshEnvelope.decode(payload) ?: return false
        if (envelope.type == RideMeshEnvelope.Type.AUDIO) {
            synchronized(audioInFlightPayload) {
                for (endpoint in endpoints) {
                    audioLatestPending.computeIfAbsent(endpoint) { FreshAudioQueue() }
                        .offer(envelope.originNodeId.toString(), encoded, SystemClock.elapsedRealtime())
                    drainAudio(endpoint)
                }
            }
        } else {
            client.sendPayload(endpoints, Payload.fromBytes(encoded))
                .addOnFailureListener { sendFailures.incrementAndGet() }
        }
        return true
    }

    // Caller holds audioInFlightPayload's monitor.
    private fun drainAudio(endpoint: String) {
        if (!started || endpoint !in connectedEndpoints) return
        val flights = audioInFlightPayload.computeIfAbsent(endpoint) { linkedMapOf() }
        while (flights.size < 4) {
            val bytes = audioLatestPending[endpoint]?.poll(SystemClock.elapsedRealtime()) ?: return
            val payload = Payload.fromBytes(bytes)
            flights[payload.id] = SystemClock.elapsedRealtime()
            audioSentAt[endpoint] = flights.values.minOrNull()!!
            client.sendPayload(endpoint, payload).addOnFailureListener {
                synchronized(audioInFlightPayload) {
                    val current = audioInFlightPayload[endpoint]
                    if (current?.remove(payload.id) != null) {
                        if (current.isEmpty()) audioSentAt.remove(endpoint)
                        else audioSentAt[endpoint] = current.values.minOrNull()!!
                        sendFailures.incrementAndGet()
                    }
                }
            }
        }
    }


    /**
     * vc55: one-peer real-time send with backpressure.
     * At most [DIRECT_MAX_IN_FLIGHT] payloads may wait inside Nearby. When the link is behind,
     * the new batch is dropped (CONGESTED) instead of queued, so delay can never build up.
     */
    fun sendDirectAudio(envelopeBytes: ByteArray, frameCount: Int): DirectSendResult {
        if (!started) return DirectSendResult.NO_LINK
        val endpoints = endpointToNode.keys.toList()
        if (endpoints.isEmpty()) return DirectSendResult.NO_LINK
        val now = SystemClock.elapsedRealtime()
        if (directGate.size() + endpoints.size > inFlightLimit || !directGate.hasRoom(now)) {
            congestionDroppedBatches.incrementAndGet()
            congestionDroppedFrames.addAndGet(frameCount.toLong())
            return DirectSendResult.CONGESTED
        }
        val encoded = ByteArray(DATA_PREFIX.size + envelopeBytes.size)
        DATA_PREFIX.copyInto(encoded)
        envelopeBytes.copyInto(encoded, DATA_PREFIX.size)
        val previous = lastTxAt.getAndSet(now)
        if (previous > 0) {
            val gap = now - previous
            lastTxGap.set(gap)
            maxTxGap.accumulateAndGet(gap) { a, b -> maxOf(a, b) }
        }
        endpoints.forEach { endpoint ->
            val payload = Payload.fromBytes(encoded)
            val payloadId = payload.id
            directGate.add(payloadId, now)
            directAudioSent.incrementAndGet(); txPayloads.incrementAndGet()
            directAudioFramesSent.addAndGet(frameCount.toLong())
            client.sendPayload(endpoint, payload).addOnFailureListener {
                if (directGate.remove(payloadId)) { directAudioFailed.incrementAndGet(); sendFailures.incrementAndGet() }
                status("DIRECT AUDIO SEND FAILED • ${shortError(it)}")
            }
        }
        return DirectSendResult.SENT
    }

    /** STAR hub forwards an already encoded direct audio envelope to every spoke except its source. */
    fun forwardDirectAudioExcept(excludedNodeId: String, envelopeBytes: ByteArray, frameCount: Int): DirectSendResult {
        if (!started || labRole != 1) return DirectSendResult.NO_LINK
        val endpoints = endpointToNode.filterValues { it != excludedNodeId }.keys.toList()
        if (endpoints.isEmpty()) return DirectSendResult.NO_LINK
        val now = SystemClock.elapsedRealtime()
        if (directGate.size() + endpoints.size > inFlightLimit || !directGate.hasRoom(now)) return DirectSendResult.CONGESTED
        val encoded = ByteArray(DATA_PREFIX.size + envelopeBytes.size).also { DATA_PREFIX.copyInto(it); envelopeBytes.copyInto(it, DATA_PREFIX.size) }
        endpoints.forEach { endpoint ->
            val p = Payload.fromBytes(encoded); directGate.add(p.id, now); directAudioSent.incrementAndGet(); txPayloads.incrementAndGet(); directAudioFramesSent.addAndGet(frameCount.toLong())
            client.sendPayload(endpoint, p).addOnFailureListener { if (directGate.remove(p.id)) { directAudioFailed.incrementAndGet(); sendFailures.incrementAndGet() } }
        }
        return DirectSendResult.SENT
    }

    private fun activeStrategy(): Strategy = when {
        hybridMesh -> Strategy.P2P_CLUSTER
        starLab -> Strategy.P2P_STAR
        else -> DIRECT_STRATEGY
    }
    private fun strategyLabel(): String = when {
        hybridMesh -> "P2P_CLUSTER(HYBRID)"
        starLab -> "P2P_STAR(${if (labRole == 1) "HUB A" else "SPOKE ${if (labRole == 2) "B" else "C"}"})"
        else -> DIRECT_STRATEGY_LABEL
    }

    private fun directConnectionOptions(): ConnectionOptions =
        ConnectionOptions.Builder().setConnectionType(
            if (hybridMesh) ConnectionType.NON_DISRUPTIVE else ConnectionType.DISRUPTIVE
        ).build()

    // Watchdogs and retry timers request reconciliation, never stop a healthy scan.
    // Nearby task callbacks and these transitions run on the main looper. Epochs
    // prevent an old start completion from changing a later ride's diagnostics.
    private fun restartDiscovery() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            discoveryHandler.post { restartDiscovery() }
            return
        }
        if (!started || connectedEndpoints.size >= maxPeers) return
        val epoch = discoveryEpoch
        val strategy = activeStrategy()
        if ((!starLab || labRole == 1) && !advertising && !advertisingStarting) {
            advertisingStarting = true
            try {
                client.startAdvertising(localEndpointName, serviceId, lifecycleCallback,
                    AdvertisingOptions.Builder().setStrategy(strategy).setLowPower(bleOnly).build())
                    .addOnSuccessListener {
                        if (started && epoch == discoveryEpoch) {
                            advertisingStarting = false; advertising = true
                            status("ADVERTISING ON • ${strategyLabel()}")
                        }
                    }
                    .addOnFailureListener {
                        if (started && epoch == discoveryEpoch) {
                            advertisingStarting = false; advertising = false
                            lastDiscoveryError = "ADVERTISING FAILED • ${shortError(it)}"
                            status(lastDiscoveryError)
                        }
                    }
            } catch (error: Exception) {
                advertisingStarting = false; advertising = false
                lastDiscoveryError = "ADVERTISING FAILED • ${shortError(error)}"
                status(lastDiscoveryError)
            }
        }
        if ((!starLab || labRole != 1) && !discovering && !discoveryStarting) {
            discoveryStarting = true
            try {
                client.startDiscovery(serviceId, discoveryCallback,
                    DiscoveryOptions.Builder().setStrategy(strategy).setLowPower(bleOnly).build())
                    .addOnSuccessListener {
                        if (started && epoch == discoveryEpoch) {
                            discoveryStarting = false; discovering = true
                            status("DISCOVERY ON • ${strategyLabel()} • searching same-code riders")
                        }
                    }
                    .addOnFailureListener {
                        if (started && epoch == discoveryEpoch) {
                            discoveryStarting = false; discovering = false
                            lastDiscoveryError = "DISCOVERY FAILED • ${shortError(it)}"
                            status(lastDiscoveryError)
                        }
                    }
            } catch (error: Exception) {
                discoveryStarting = false; discovering = false
                lastDiscoveryError = "DISCOVERY FAILED • ${shortError(error)}"
                status(lastDiscoveryError)
            }
        }
    }

    private fun handleMessage(endpointId: String, bytes: ByteArray) {
        if (!started || endpointId !in connectedEndpoints || bytes.size > RideMeshEnvelope.MAX_PAYLOAD + 100) return
        if (startsWith(bytes, DATA_PREFIX)) {
            endpointToNode[endpointId]?.let { listener.onData(it, bytes.copyOfRange(DATA_PREFIX.size, bytes.size)) }
            return
        }
        val text = bytes.toString(Charsets.UTF_8)
        when {
            text.startsWith("HELLO|") -> {
                val parts = text.split('|', limit = 5)
                if (!acceptIdentity(endpointId, parts)) return
                sendRaw(endpointId, helloAck())
            }
            text.startsWith("HELLO_ACK|") -> acceptIdentity(endpointId, text.split('|', limit = 5))
            text.startsWith("PING|") -> sendRaw(endpointId, "PONG|${text.substringAfter('|')}".toByteArray())
            text.startsWith("PONG|") -> {
                val sent = text.substringAfter('|').toLongOrNull() ?: return
                val remoteNode = endpointToNode[endpointId] ?: return
                listener.onRtt(remoteNode, (SystemClock.elapsedRealtime() - sent).coerceIn(0, 60_000).toInt())
            }
            startsWith(bytes, DATA_PREFIX) -> endpointToNode[endpointId]?.let {
                listener.onData(it, bytes.copyOfRange(DATA_PREFIX.size, bytes.size))
            }
        }
    }

    private fun acceptIdentity(endpointId: String, parts: List<String>): Boolean {
        if (parts.size < 4 || parts[1] != rideToken || parts[2] == nodeId) {
            status("IDENTITY REJECTED • endpoint=${endpointId.take(6)}")
            client.disconnectFromEndpoint(endpointId)
            return false
        }
        val remoteNode = parts[2]
        if (runCatching { java.util.UUID.fromString(remoteNode) }.isFailure) {
            client.disconnectFromEndpoint(endpointId)
            return false
        }
        val remoteName = parts[3].ifBlank { endpointToName[endpointId] ?: "Android rider" }
        val remoteDevice = parts.getOrNull(4).orEmpty().ifBlank { "Android device" }

        val existingEndpoint = endpointToNode.entries.firstOrNull { it.value == remoteNode && it.key != endpointId }?.key
        if (existingEndpoint != null && connectedEndpoints.contains(existingEndpoint)) {
            status("DUPLICATE ENDPOINT • keeping $existingEndpoint • closing $endpointId")
            client.disconnectFromEndpoint(endpointId)
            return false
        }

        val wasNew = endpointToNode.put(endpointId, remoteNode) == null
        endpointToName[endpointId] = remoteName
        endpointToDevice[endpointId] = remoteDevice
        helloAttempts.remove(endpointId)
        if (wasNew) {
            identityReadyAtMs = SystemClock.elapsedRealtime()
            status("IDENTITY OK • $remoteName • $remoteDevice • DIRECT LINK READY")
            if (hybridMesh) {
                if (endpointToNode.size >= maxPeers) {
                    runCatching { client.stopDiscovery() }; discovering = false
                    status("HYBRID CLUSTER FULL • peers=${endpointToNode.size}/$maxPeers")
                } else {
                    status("HYBRID CLUSTER READY • peers=${endpointToNode.size}/$maxPeers • discovery remains active")
                }
            } else if (!starLab || endpointToNode.size >= maxPeers) {
                runCatching { client.stopDiscovery() }; discovering = false
                runCatching { client.stopAdvertising() }; advertising = false
                status("DIRECT LINK LOCKED • target peers reached=${endpointToNode.size}/$maxPeers • generation=${connectionGeneration.get()}")
            } else {
                status("STAR HUB READY • peers=${endpointToNode.size}/$maxPeers • waiting for next spoke")
            }
            listener.onPeerConnected(remoteNode, remoteName)
        }
        return true
    }

    private fun sendHello(endpointId: String) {
        val attempt = (helloAttempts[endpointId] ?: 0) + 1
        helloAttempts[endpointId] = attempt
        if (attempt == 1 || attempt == 3 || attempt == 5) {
            status("IDENTITY HELLO • ${endpointToName[endpointId] ?: endpointId.take(6)} • attempt $attempt")
        }
        sendRaw(endpointId, hello())
    }

    private fun sendRaw(endpointId: String, bytes: ByteArray) {
        if (connectedEndpoints.contains(endpointId)) {
            txPayloads.incrementAndGet()
            client.sendPayload(endpointId, Payload.fromBytes(bytes))
                .addOnFailureListener { status("PAYLOAD SEND FAILED • ${shortError(it)}") }
        }
    }

    private fun hello() = "HELLO|$rideToken|$nodeId|${sanitize(riderName.ifBlank { "Rider" })}|$localDeviceName".toByteArray()
    private fun helloAck() = "HELLO_ACK|$rideToken|$nodeId|${sanitize(riderName.ifBlank { "Rider" })}|$localDeviceName".toByteArray()
    private fun sanitize(value: String): String = value.replace('|', '/').replace('\n', ' ').replace('\r', ' ')
    @Suppress("SameParameterValue")
    private fun startsWith(bytes: ByteArray, prefix: ByteArray): Boolean = bytes.size >= prefix.size && prefix.indices.all { bytes[it] == prefix[it] }
    private fun shortError(t: Throwable): String = "${t.javaClass.simpleName}: ${t.message.orEmpty().take(90)}"

    companion object {
        private const val RETRY_BACKOFF_MS = 3500L
        private const val STALE_ENDPOINT_SUPPRESS_MS = 12_000L

        /**
         * One-peer direct test: P2P_POINT_TO_POINT upgrades to Wi-Fi most readily.
         * BOTH phones must run the same build. The eight-rider mesh needs P2P_CLUSTER again.
         */
        val DIRECT_STRATEGY: Strategy = Strategy.P2P_POINT_TO_POINT
        const val DIRECT_STRATEGY_LABEL = "P2P_POINT_TO_POINT"

        /** Max audio payloads waiting inside Nearby (vc80 direct: 2 frames each = ~120 ms of audio). */
        const val DIRECT_MAX_IN_FLIGHT = 3
        const val STAR_MAX_IN_FLIGHT = 6
        const val HYBRID_MAX_PEERS = 5
        private const val DIRECT_IN_FLIGHT_TIMEOUT_MS = 2_000L
        private val DATA_PREFIX = byteArrayOf(0x52, 0x4d, 0x44, 0x31)
    }
}
