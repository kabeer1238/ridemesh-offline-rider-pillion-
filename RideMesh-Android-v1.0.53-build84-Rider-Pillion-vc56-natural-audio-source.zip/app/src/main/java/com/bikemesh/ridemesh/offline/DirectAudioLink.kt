package com.bikemesh.ridemesh.offline

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * vc55 direct-link audio primitives. Pure Kotlin (no Android types) so they are unit-testable.
 *
 * vc54 field logs showed the Nearby link carrying only ~15-18 audio payloads/s while the
 * sender offered 50/s, and the sender queued without limit (2412 frames pending = ~48 s of
 * delay). vc55 fixes this with three pieces:
 *
 *  1. [DirectAudioBatch]  - several 20 ms frames per Nearby payload (less per-payload overhead).
 *  2. [InFlightGate]      - hard limit on payloads waiting inside Nearby; late audio is dropped,
 *                           never queued.
 *  3. [DirectCodecPolicy] - raw PCM only when Nearby reports HIGH bandwidth, Opus otherwise.
 */
object DirectAudioBatch {
    const val MAGIC = 0x524D4432 // "RMD2" (vc54 used RMD1 = one raw frame, no codec field)
    const val CODEC_PCM16 = 0
    const val CODEC_OPUS = 1
    const val MAX_FRAMES = 8
    const val PCM_FRAME_BYTES = 640
    const val MAX_OPUS_FRAME_BYTES = 263 // OpusVoiceCodec 7-byte OPV1 header + 256 bytes
    private const val HEADER_BYTES = 10  // magic(4) + generation(4) + codec(1) + count(1)

    data class Decoded(val generation: Int, val codec: Int, val frames: List<ByteArray>)

    fun encode(generation: Int, codec: Int, frames: List<ByteArray>): ByteArray {
        require(frames.size in 1..MAX_FRAMES) { "batch must hold 1..$MAX_FRAMES frames" }
        require(codec == CODEC_PCM16 || codec == CODEC_OPUS) { "unknown codec $codec" }
        frames.forEach { require(validFrameSize(codec, it.size)) { "bad frame size ${it.size} for codec $codec" } }
        val out = ByteBuffer.allocate(HEADER_BYTES + frames.sumOf { 2 + it.size }).order(ByteOrder.BIG_ENDIAN)
        out.putInt(MAGIC)
        out.putInt(generation)
        out.put(codec.toByte())
        out.put(frames.size.toByte())
        for (frame in frames) {
            out.putShort(frame.size.toShort())
            out.put(frame)
        }
        return out.array()
    }

    fun decode(payload: ByteArray): Decoded? {
        if (payload.size < HEADER_BYTES) return null
        val input = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN)
        if (input.int != MAGIC) return null
        val generation = input.int
        val codec = input.get().toInt() and 0xff
        if (codec != CODEC_PCM16 && codec != CODEC_OPUS) return null
        val count = input.get().toInt() and 0xff
        if (count !in 1..MAX_FRAMES) return null
        val frames = ArrayList<ByteArray>(count)
        repeat(count) {
            if (input.remaining() < 2) return null
            val size = input.short.toInt() and 0xffff
            if (!validFrameSize(codec, size) || input.remaining() < size) return null
            val frame = ByteArray(size)
            input.get(frame)
            frames.add(frame)
        }
        if (input.hasRemaining()) return null
        return Decoded(generation, codec, frames)
    }

    private fun validFrameSize(codec: Int, size: Int): Boolean = when (codec) {
        CODEC_PCM16 -> size == PCM_FRAME_BYTES
        CODEC_OPUS -> size in 1..MAX_OPUS_FRAME_BYTES
        else -> false
    }
}

/**
 * Collects consecutive 20 ms frames into one batch. A partial batch is discarded when the
 * capture stream pauses (mute, audio focus loss, tone) or the codec changes, so stale speech
 * is never glued onto fresh speech.
 */
class DirectFrameBatcher(
    private val framesPerBatch: Int,
    private val maxFrameGapMs: Long,
) {
    class Batch(val firstSequence: Int, val firstCaptureMs: Long, val codec: Int, val frames: List<ByteArray>)

    private val frames = ArrayList<ByteArray>(framesPerBatch)
    private var firstSequence = 0
    private var firstCaptureMs = 0L
    private var lastCaptureMs = 0L
    private var lastSequence = 0
    private var codec = -1

    var discardedFrames = 0L
        private set

    init {
        require(framesPerBatch in 1..DirectAudioBatch.MAX_FRAMES)
    }

    @Synchronized
    fun offer(sequence: Int, captureMs: Long, frameCodec: Int, frame: ByteArray): Batch? {
        if (frames.isNotEmpty() && (
                captureMs - lastCaptureMs > maxFrameGapMs ||
                    frameCodec != codec ||
                    sequence != lastSequence + 1)
        ) {
            discardedFrames += frames.size
            frames.clear()
        }
        if (frames.isEmpty()) {
            firstSequence = sequence
            firstCaptureMs = captureMs
            codec = frameCodec
        }
        frames.add(frame)
        lastCaptureMs = captureMs
        lastSequence = sequence
        if (frames.size < framesPerBatch) return null
        val batch = Batch(firstSequence, firstCaptureMs, codec, ArrayList(frames))
        frames.clear()
        return batch
    }

    @Synchronized
    fun reset() {
        frames.clear()
        codec = -1
    }
}

/**
 * Backpressure for real-time audio: at most [maxInFlight] payloads may be waiting inside
 * Nearby. When full, the caller drops the new batch. Entries that never receive a transfer
 * update are forgotten after [timeoutMs] so a lost callback cannot block audio forever.
 */
class InFlightGate(
    private val maxInFlight: Int,
    private val timeoutMs: Long,
) {
    private val sentAt = LinkedHashMap<Long, Long>()

    var maxObserved = 0
        private set
    var timedOut = 0L
        private set

    @Synchronized
    fun hasRoom(nowMs: Long): Boolean {
        purgeExpiredLocked(nowMs)
        return sentAt.size < maxInFlight
    }

    @Synchronized
    fun add(payloadId: Long, nowMs: Long) {
        sentAt[payloadId] = nowMs
        if (sentAt.size > maxObserved) maxObserved = sentAt.size
    }

    /** Returns true when [payloadId] was one of ours. */
    @Synchronized
    fun remove(payloadId: Long): Boolean = sentAt.remove(payloadId) != null

    /** vc56 diagnostics only: removes the payload and returns its original send time. */
    @Synchronized
    fun removeAndSentAt(payloadId: Long): Long? = sentAt.remove(payloadId)

    @Synchronized
    fun purgeExpired(nowMs: Long): Int = purgeExpiredLocked(nowMs)

    @Synchronized
    fun size(): Int = sentAt.size

    @Synchronized
    fun clear() = sentAt.clear()

    @Synchronized
    fun resetStats() {
        maxObserved = 0
        timedOut = 0
    }

    private fun purgeExpiredLocked(nowMs: Long): Int {
        var removed = 0
        val iterator = sentAt.entries.iterator()
        while (iterator.hasNext()) {
            if (nowMs - iterator.next().value > timeoutMs) {
                iterator.remove()
                removed++
            }
        }
        timedOut += removed
        return removed
    }
}

/** Chooses the codec for the next frame from the Nearby bandwidth report. */
object DirectCodecPolicy {
    enum class Mode { AUTO, FORCE_PCM, FORCE_OPUS }

    // Nearby BandwidthInfo.Quality values.
    const val QUALITY_UNKNOWN = 0
    const val QUALITY_LOW = 1
    const val QUALITY_MEDIUM = 2
    const val QUALITY_HIGH = 3

    /**
     * AUTO: raw PCM needs ~256 kbit/s, which only a Wi-Fi-class (HIGH) Nearby link carries.
     * vc54 measured ~80-90 kbit/s, so anything below HIGH uses Opus (~30-40 kbit/s batched).
     */
    fun codecFor(mode: Mode, bandwidthQuality: Int): Int = when (mode) {
        Mode.FORCE_PCM -> DirectAudioBatch.CODEC_PCM16
        Mode.FORCE_OPUS -> DirectAudioBatch.CODEC_OPUS
        Mode.AUTO -> if (bandwidthQuality == QUALITY_HIGH) DirectAudioBatch.CODEC_PCM16 else DirectAudioBatch.CODEC_OPUS
    }

    fun qualityLabel(quality: Int): String = when (quality) {
        QUALITY_HIGH -> "HIGH (Wi-Fi class)"
        QUALITY_MEDIUM -> "MEDIUM"
        QUALITY_LOW -> "LOW"
        else -> "UNKNOWN (not reported yet)"
    }

    fun codecLabel(codec: Int): String = when (codec) {
        DirectAudioBatch.CODEC_PCM16 -> "RAW PCM16"
        DirectAudioBatch.CODEC_OPUS -> "OPUS"
        else -> "NONE"
    }
}
