package com.bikemesh.ridemesh.transport

import android.media.AudioFormat
import org.webrtc.audio.JavaAudioDeviceModule
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * vc62 audio bridge between the Android Nearby mesh (16 kHz mono / 20 ms PCM)
 * and the WebRTC/SFU AudioDeviceModule (normally 48 kHz mono / 10 ms PCM).
 *
 * Important invariants:
 *  - WebRTC remains the only microphone owner on an Internet-capable phone.
 *  - Offline audio is injected directly into the WebRTC capture buffer. It is
 *    never played through a speaker and re-recorded by the microphone.
 *  - WebRTC playout is tapped read-only, converted to the mesh PCM format and
 *    forwarded only by the elected PRIMARY bridge.
 *  - The PRIMARY bridge sends one 20 ms downlink frame containing its own real
 *    microphone plus current remote SFU playout. Offline audio injected into
 *    the uplink is never copied back into that downlink, preventing a loop.
 *  - Queues are deliberately short. Fresh intercom audio is preferred over
 *    delayed audio after congestion or a bridge handover.
 */
class HybridSfuAudioBridge(
    private val isPrimaryBridge: () -> Boolean,
    private val sendToOffline: (ByteArray) -> Unit,
) {
    private data class SourceQueue(
        val halves: ArrayDeque<ByteArray> = ArrayDeque(),
    )

    private val offlineSources = ConcurrentHashMap<String, SourceQueue>()
    private val remotePlaybackLock = Any()
    private val remotePlaybackHalves = ArrayDeque<ByteArray>()

    @Volatile private var localMicEnabled = true
    @Volatile private var closed = false
    @Volatile private var localDownlinkHalf: ByteArray? = null

    private val offlineFramesOffered = AtomicLong()
    private val offlineFramesDropped = AtomicLong()
    private val captureCallbacks = AtomicLong()
    private val injectedCallbacks = AtomicLong()
    private val playbackCallbacks = AtomicLong()
    private val offlineDownlinkFrames = AtomicLong()
    private val unsupportedCallbacks = AtomicLong()

    fun setLocalMicEnabled(enabled: Boolean) {
        localMicEnabled = enabled
    }

    /** Accept one decoded Nearby frame: PCM16 LE, mono, 16 kHz, 20 ms (640 bytes). */
    fun offerOfflinePcm(sourceId: String, pcm16k20ms: ByteArray) {
        if (closed || !isPrimaryBridge()) return
        if (pcm16k20ms.size != MESH_FRAME_BYTES) {
            offlineFramesDropped.incrementAndGet()
            return
        }
        val key = sourceId.ifBlank { "offline" }
        val queue = offlineSources.computeIfAbsent(key) { SourceQueue() }
        synchronized(queue) {
            queue.halves.addLast(pcm16k20ms.copyOfRange(0, MESH_HALF_BYTES))
            queue.halves.addLast(pcm16k20ms.copyOfRange(MESH_HALF_BYTES, MESH_FRAME_BYTES))
            while (queue.halves.size > MAX_SOURCE_HALVES) {
                queue.halves.removeFirst()
                offlineFramesDropped.incrementAndGet()
            }
        }
        offlineFramesOffered.incrementAndGet()
    }

    /**
     * Called from JavaAudioDeviceModule.AudioBufferCallback before WebRTC consumes capture PCM.
     * The return value must preserve the capture timestamp contract.
     */
    fun processCapture(
        buffer: ByteBuffer,
        audioFormat: Int,
        channelCount: Int,
        sampleRate: Int,
        bytesRead: Int,
        captureTimeNs: Long,
    ): Long {
        if (closed || bytesRead <= 0) return captureTimeNs
        captureCallbacks.incrementAndGet()
        if (audioFormat != AudioFormat.ENCODING_PCM_16BIT || channelCount <= 0 || sampleRate <= 0) {
            unsupportedCallbacks.incrementAndGet()
            return captureTimeNs
        }

        val bytesPerFrame = channelCount * 2
        if (bytesRead < bytesPerFrame || bytesRead > buffer.capacity()) {
            unsupportedCallbacks.incrementAndGet()
            return captureTimeNs
        }
        val frames = bytesRead / bytesPerFrame
        val durationMs = frames * 1000.0 / sampleRate.toDouble()
        // Android WebRTC ADM normally supplies 10 ms callbacks. Do not attempt to bridge
        // an unexpected callback size because it could create bursty or time-stretched voice.
        if (durationMs !in 8.0..12.5) {
            unsupportedCallbacks.incrementAndGet()
            return captureTimeNs
        }

        val originalMic = readMonoPcm16(buffer, channelCount, frames)
        val primary = isPrimaryBridge()

        // Build the mesh downlink from the real microphone BEFORE offline audio is injected.
        if (primary) {
            val local10 = if (localMicEnabled) {
                shortsToBytes(resample(originalMic, sampleRate, MESH_SAMPLE_RATE, MESH_HALF_SAMPLES))
            } else {
                ByteArray(MESH_HALF_BYTES)
            }
            emitOfflineDownlinkOnCaptureClock(local10)
        } else {
            clearBridgeQueues()
        }

        val sourceHalves = if (primary) pollOfflineHalves() else emptyList()
        val target = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val start = target.position()
        val sourceGain = if (sourceHalves.isEmpty()) 0.0 else 1.0 / sqrt(sourceHalves.size.toDouble())
        val resampledOffline = sourceHalves.map { half ->
            val source = bytesToShorts(half)
            resample(source, MESH_SAMPLE_RATE, sampleRate, frames)
        }

        var injected = false
        for (frameIndex in 0 until frames) {
            var offlineSum = 0.0
            for (source in resampledOffline) offlineSum += source[frameIndex].toDouble()
            val offlineMixed = (offlineSum * sourceGain).roundToInt()
            for (channel in 0 until channelCount) {
                val offset = start + (frameIndex * channelCount + channel) * 2
                val mic = if (localMicEnabled) target.getShort(offset).toInt() else 0
                val mixed = clamp16(mic + offlineMixed)
                target.putShort(offset, mixed.toShort())
            }
            if (offlineMixed != 0) injected = true
        }
        if (injected) injectedCallbacks.incrementAndGet()
        return captureTimeNs
    }

    /** Read-only tap of decoded WebRTC/SFU playout. */
    fun onPlaybackSamples(samples: JavaAudioDeviceModule.AudioSamples) {
        if (closed || !isPrimaryBridge()) return
        playbackCallbacks.incrementAndGet()
        if (samples.audioFormat != AudioFormat.ENCODING_PCM_16BIT ||
            samples.channelCount <= 0 || samples.sampleRate <= 0 || samples.data.isEmpty()) {
            unsupportedCallbacks.incrementAndGet()
            return
        }
        val chunks = toMeshTenMsChunks(samples.data, samples.channelCount, samples.sampleRate)
        if (chunks.isEmpty()) return
        synchronized(remotePlaybackLock) {
            chunks.forEach(remotePlaybackHalves::addLast)
            while (remotePlaybackHalves.size > MAX_REMOTE_HALVES) remotePlaybackHalves.removeFirst()
        }
    }

    fun diagnostics(): String = buildString {
        append("Hybrid PCM bridge: ")
        append(if (closed) "CLOSED" else if (isPrimaryBridge()) "PRIMARY" else "STANDBY")
        append(" • offline in=").append(offlineFramesOffered.get())
        append(" drop=").append(offlineFramesDropped.get())
        append(" • capture=").append(captureCallbacks.get())
        append(" injected=").append(injectedCallbacks.get())
        append(" • SFU playback=").append(playbackCallbacks.get())
        append(" • mesh downlink=").append(offlineDownlinkFrames.get())
        append(" • unsupported=").append(unsupportedCallbacks.get())
    }

    fun close() {
        closed = true
        clearBridgeQueues()
        synchronized(remotePlaybackLock) { remotePlaybackHalves.clear() }
        localDownlinkHalf = null
    }

    private fun emitOfflineDownlinkOnCaptureClock(local10: ByteArray) {
        val first = localDownlinkHalf
        if (first == null) {
            localDownlinkHalf = local10
            return
        }
        localDownlinkHalf = null
        val local20 = ByteArray(MESH_FRAME_BYTES)
        first.copyInto(local20, 0)
        local10.copyInto(local20, MESH_HALF_BYTES)

        val remote20 = ByteArray(MESH_FRAME_BYTES)
        synchronized(remotePlaybackLock) {
            remotePlaybackHalves.pollFirst()?.copyInto(remote20, 0)
            remotePlaybackHalves.pollFirst()?.copyInto(remote20, MESH_HALF_BYTES)
        }
        val mixed = mixPcm16(local20, remote20)
        if (pcmPeak(mixed) >= MIN_FORWARD_PEAK) {
            sendToOffline(mixed)
            offlineDownlinkFrames.incrementAndGet()
        }
    }

    private fun pollOfflineHalves(): List<ByteArray> {
        val out = ArrayList<ByteArray>(offlineSources.size)
        val stale = ArrayList<String>()
        offlineSources.forEach { (id, queue) ->
            val half = synchronized(queue) { queue.halves.pollFirst() }
            if (half != null) out += half
            if (synchronized(queue) { queue.halves.isEmpty() }) stale += id
        }
        stale.forEach { id ->
            val q = offlineSources[id] ?: return@forEach
            if (synchronized(q) { q.halves.isEmpty() }) offlineSources.remove(id, q)
        }
        return out
    }

    private fun clearBridgeQueues() {
        offlineSources.clear()
        synchronized(remotePlaybackLock) { remotePlaybackHalves.clear() }
        localDownlinkHalf = null
    }

    private fun readMonoPcm16(buffer: ByteBuffer, channels: Int, frames: Int): ShortArray {
        val view = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val start = view.position()
        val out = ShortArray(frames)
        for (frame in 0 until frames) {
            var sum = 0
            for (channel in 0 until channels) {
                sum += view.getShort(start + (frame * channels + channel) * 2).toInt()
            }
            out[frame] = clamp16(sum / channels).toShort()
        }
        return out
    }

    private fun toMeshTenMsChunks(data: ByteArray, channels: Int, sampleRate: Int): List<ByteArray> {
        val frames = data.size / (channels * 2)
        if (frames <= 0) return emptyList()
        val input = ShortArray(frames)
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        for (frame in 0 until frames) {
            var sum = 0
            for (channel in 0 until channels) sum += bb.getShort((frame * channels + channel) * 2).toInt()
            input[frame] = clamp16(sum / channels).toShort()
        }
        val outputSamples = (frames.toDouble() * MESH_SAMPLE_RATE / sampleRate.toDouble()).roundToInt()
        if (outputSamples < MESH_HALF_SAMPLES) return emptyList()
        val output = resample(input, sampleRate, MESH_SAMPLE_RATE, outputSamples)
        val chunks = ArrayList<ByteArray>()
        var offset = 0
        while (offset + MESH_HALF_SAMPLES <= output.size) {
            chunks += shortsToBytes(output.copyOfRange(offset, offset + MESH_HALF_SAMPLES))
            offset += MESH_HALF_SAMPLES
        }
        return chunks
    }

    private fun resample(input: ShortArray, inputRate: Int, outputRate: Int, outputSamples: Int): ShortArray {
        if (input.isEmpty() || outputSamples <= 0) return ShortArray(0)
        if (inputRate == outputRate && input.size == outputSamples) return input.copyOf()
        val out = ShortArray(outputSamples)
        if (outputSamples == 1 || input.size == 1) {
            java.util.Arrays.fill(out, input[0])
            return out
        }
        val scale = (input.size - 1).toDouble() / (outputSamples - 1).toDouble()
        for (i in 0 until outputSamples) {
            val pos = i * scale
            val left = pos.toInt().coerceIn(0, input.lastIndex)
            val right = (left + 1).coerceAtMost(input.lastIndex)
            val fraction = pos - left
            val sample = input[left] * (1.0 - fraction) + input[right] * fraction
            out[i] = clamp16(sample.roundToInt()).toShort()
        }
        return out
    }

    private fun mixPcm16(a: ByteArray, b: ByteArray): ByteArray {
        val count = minOf(a.size, b.size) / 2
        val aa = ByteBuffer.wrap(a).order(ByteOrder.LITTLE_ENDIAN)
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val out = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) {
            val mixed = aa.getShort(i * 2).toInt() + bb.getShort(i * 2).toInt()
            out.putShort(i * 2, clamp16(mixed).toShort())
        }
        return out.array()
    }

    private fun bytesToShorts(bytes: ByteArray): ShortArray {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        return ShortArray(bytes.size / 2) { index -> bb.getShort(index * 2) }
    }

    private fun shortsToBytes(samples: ShortArray): ByteArray {
        val out = ByteBuffer.allocate(samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        samples.forEachIndexed { index, value -> out.putShort(index * 2, value) }
        return out.array()
    }

    private fun pcmPeak(pcm: ByteArray): Int {
        val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        var peak = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val value = kotlin.math.abs(bb.getShort(i).toInt())
            if (value > peak) peak = value
            i += 2
        }
        return peak
    }

    private fun clamp16(value: Int): Int = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

    companion object {
        const val MESH_SAMPLE_RATE = 16_000
        const val MESH_FRAME_BYTES = 640
        private const val MESH_HALF_BYTES = 320
        private const val MESH_HALF_SAMPLES = 160
        private const val MAX_SOURCE_HALVES = 6       // 60 ms per source
        private const val MAX_REMOTE_HALVES = 8       // 80 ms decoded SFU playout
        private const val MIN_FORWARD_PEAK = 48
    }
}
