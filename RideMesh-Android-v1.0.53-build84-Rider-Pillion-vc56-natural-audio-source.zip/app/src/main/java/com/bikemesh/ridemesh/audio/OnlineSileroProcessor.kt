package com.bikemesh.ridemesh.audio

import android.content.Context
import android.media.AudioFormat
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.sqrt

/**
 * vc75 online Silero local-microphone controller.
 *
 * The WebRTC ADM capture graph stays alive continuously. Silero inference runs off-thread from a
 * bounded PCM copy. The realtime callback only applies a lightweight gain envelope to THIS phone's
 * local microphone PCM; timestamps, format, resampling and WebRTC/Opus ownership are unchanged.
 * Manual mute/private-call isolation remains a separate hard-mute policy, and hybrid bridge audio
 * is injected later so remote/offline riders are never suppressed by this local VAD.
 */
internal class OnlineSileroProcessor(context: Context) : AutoCloseable {
    private data class Frame(val pcm: ByteArray, val rate: Int)

    private val appContext = context.applicationContext
    private val queue = ArrayBlockingQueue<Frame>(24)
    private val observedFrames = AtomicLong(0)
    private val droppedFrames = AtomicLong(0)

    @Volatile private var enabled = false
    @Volatile private var voiceAllowed = false
    @Volatile private var closed = false
    @Volatile private var ready = false
    @Volatile private var failure: String? = null
    @Volatile private var speaking = false
    @Volatile private var modelStats = "starting"
    @Volatile private var captureFormat = "waiting for WebRTC PCM"
    @Volatile private var confirmedSpeechFrames = 0
    @Volatile private var gateOpen = false
    @Volatile private var gateGain = 0.03f
    @Volatile private var provisionalUntilMs = 0L
    @Volatile private var speechUntilMs = 0L
    @Volatile private var quietSinceMs = 0L
    @Volatile private var onsetArmed = true
    private val gateOpens = AtomicLong(0)
    private val gateCloses = AtomicLong(0)

    private val worker = Thread({ inferLoop() }, "RideMesh-Online-Silero-Observer").apply {
        isDaemon = true
        start()
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (!value) {
            // vc77: Voice Detection OFF is a true bypass. Restore unity immediately so no
            // attenuation state from the natural VAD can survive after the user disables it.
            // WebRTC capture/AEC/NS/AGC remain unchanged; only RideMesh's custom VAD envelope
            // is bypassed here.
            speaking = false
            gateOpen = false
            gateGain = 1.0f
            confirmedSpeechFrames = 0
            provisionalUntilMs = 0L
            speechUntilMs = 0L
            quietSinceMs = 0L
            onsetArmed = true
            queue.clear()
        }
    }

    /** Private-call/user-mute state remains authoritative and separate from this natural VAD envelope. */
    fun setAllowed(value: Boolean) {
        voiceAllowed = value
        if (!value) {
            speaking = false
            queue.clear()
        }
    }

    fun bypass() = setEnabled(false)

    fun diagnostics(): String {
        val state = when {
            closed -> "STOPPED"
            failure != null -> "BYPASS (${failure})"
            !enabled -> "OFF • WebRTC unchanged"
            !voiceAllowed -> "PAUSED • WebRTC TX policy owns mute/call isolation"
            !ready -> "STARTING • WebRTC unchanged"
            speaking -> "ON • SPEECH ACTIVE"
            else -> "ON • listening"
        }
        return "Online Silero observer: $state" +
            " • source: JavaAudioDeviceModule read-only PCM" +
            " • $captureFormat" +
            " • observed: ${observedFrames.get()}" +
            " • dropped: ${droppedFrames.get()}" +
            " • queue: ${queue.size}/${queue.remainingCapacity() + queue.size}" +
            " • TX gate: ${if (!enabled || failure != null || !ready) "BYPASS" else if (gateOpen) "OPEN" else "CLOSED"}" +
            " • gate gain: ${"%.2f".format(gateGain)}" +
            " • gate opens/closes: ${gateOpens.get()}/${gateCloses.get()}" +
            " • $modelStats"
    }

    private fun inferLoop() {
        var detector: SileroSpeechDetector? = null
        try {
            detector = SileroSpeechDetector(appContext)
            ready = true
            while (!closed) {
                val frame = queue.poll(100, TimeUnit.MILLISECONDS) ?: continue
                if (!enabled || !voiceAllowed) continue
                val activeDetector = requireNotNull(detector)
                val result = activeDetector.observe(OnlineVadPolicy.analysisFrame(frame.pcm, frame.rate))
                if (result != null) {
                    if (result) {
                        confirmedSpeechFrames++
                        if (confirmedSpeechFrames >= SPEECH_CONFIRM_FRAMES) {
                            speaking = true
                            speechUntilMs = android.os.SystemClock.elapsedRealtime() + SPEECH_HANGOVER_MS
                        }
                    } else {
                        confirmedSpeechFrames = 0
                        speaking = false
                    }
                }
                modelStats = activeDetector.diagnostics()
            }
        } catch (_: InterruptedException) {
            if (!closed) failure = "worker interrupted"
        } catch (t: Throwable) {
            failure = "model unavailable: ${t.javaClass.simpleName}"
        } finally {
            ready = false
            detector?.close()
            queue.clear()
        }
    }

    /**
     * Called from WebRTC ADM capture callback. Always returns the original timestamp. vc75 may
     * attenuate local-mic PCM in place, but never rewrites timing/format or bridge-injected audio.
     */
    fun process(
        buffer: ByteBuffer,
        format: Int,
        channels: Int,
        rate: Int,
        bytesRead: Int,
        timestamp: Long,
    ): Long {
        if (!enabled || !voiceAllowed || closed || failure != null) return timestamp
        try {
            if (format != AudioFormat.ENCODING_PCM_16BIT || channels != 1 ||
                rate !in intArrayOf(8_000, 16_000, 32_000, 48_000) ||
                bytesRead <= 0 || bytesRead > buffer.capacity()
            ) {
                captureFormat = "unsupported PCM: format=$format ch=$channels rate=$rate bytes=$bytesRead"
                return timestamp
            }

            captureFormat = "PCM16 mono ${rate / 1000} kHz • ${bytesRead / 2} samples/callback"
            val pcm = ByteArray(bytesRead)
            val copy = buffer.duplicate()
            copy.position(0)
            copy.limit(bytesRead)
            copy.get(pcm)
            observedFrames.incrementAndGet()
            if (!queue.offer(Frame(pcm, rate))) droppedFrames.incrementAndGet()

            // vc75: gate ONLY the local microphone PCM at the ADM observation point. This runs
            // before HybridSfuAudioBridge injects offline riders, so bridge audio is never VAD-gated.
            if (ready) {
                val now = android.os.SystemClock.elapsedRealtime()
                var sum = 0.0
                var count = 0
                var i = 0
                while (i + 1 < pcm.size) {
                    val sample = ((pcm[i].toInt() and 0xff) or (pcm[i + 1].toInt() shl 8)).toShort().toInt()
                    sum += sample.toDouble() * sample.toDouble()
                    count++
                    i += 2
                }
                val rms = if (count > 0) sqrt(sum / count) else 0.0
                if (rms < QUIET_RMS) {
                    if (quietSinceMs == 0L) quietSinceMs = now
                    if (now - quietSinceMs >= REARM_QUIET_MS) onsetArmed = true
                } else {
                    quietSinceMs = 0L
                    if (onsetArmed && rms >= ONSET_RMS) {
                        provisionalUntilMs = now + PROVISIONAL_ONSET_MS
                        onsetArmed = false
                    }
                }
                val shouldOpen = now < provisionalUntilMs || now < speechUntilMs
                if (shouldOpen != gateOpen) {
                    gateOpen = shouldOpen
                    if (shouldOpen) gateOpens.incrementAndGet() else gateCloses.incrementAndGet()
                }
                // vc75 natural-intercom gate: never hard-switch the local microphone to digital
                // zero during ordinary silence. Speech/onset opens immediately; after the longer
                // conversational hold expires, gain eases down toward a very low comfort floor.
                // This keeps the mic graph continuously alive and removes the abrupt ON/OFF sensation
                // while still strongly attenuating steady non-speech. Bridge-injected rider audio is
                // added later by HybridSfuAudioBridge and is therefore unaffected.
                val targetGain = if (gateOpen) 1.0f else CLOSED_GAIN
                gateGain = if (targetGain > gateGain) {
                    // Fast attack protects H/T/K/P consonants.
                    minOf(1.0f, gateGain + ATTACK_GAIN_STEP)
                } else {
                    // Slow release avoids an audible noise-floor cliff after a sentence.
                    maxOf(CLOSED_GAIN, gateGain - RELEASE_GAIN_STEP)
                }
                if (gateGain < 0.999f) {
                    val write = buffer.duplicate()
                    val safe = minOf(bytesRead, write.capacity())
                    var n = 0
                    while (n + 1 < safe) {
                        val sample = ((write.get(n).toInt() and 0xff) or (write.get(n + 1).toInt() shl 8)).toShort().toInt()
                        val scaled = (sample * gateGain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        write.put(n, (scaled and 0xff).toByte())
                        write.put(n + 1, ((scaled shr 8) and 0xff).toByte())
                        n += 2
                    }
                }
            }
        } catch (_: Throwable) {
            // Any VAD/gate failure bypasses suppression; never break the production voice path.
            droppedFrames.incrementAndGet()
        }
        return timestamp
    }

    companion object {
        private const val SPEECH_CONFIRM_FRAMES = 2
        private const val SPEECH_HANGOVER_MS = 1_200L
        private const val PROVISIONAL_ONSET_MS = 160L
        private const val REARM_QUIET_MS = 250L
        private const val ONSET_RMS = 650.0
        private const val QUIET_RMS = 260.0
        private const val CLOSED_GAIN = 0.03f
        private const val ATTACK_GAIN_STEP = 1.0f
        private const val RELEASE_GAIN_STEP = 0.02f
    }

    override fun close() {
        enabled = false
        voiceAllowed = false
        closed = true
        speaking = false
        queue.clear()
        worker.interrupt()
    }
}
