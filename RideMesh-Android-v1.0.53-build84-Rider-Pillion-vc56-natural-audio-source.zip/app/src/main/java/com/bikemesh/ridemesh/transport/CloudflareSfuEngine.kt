package com.bikemesh.ridemesh.transport

import org.json.JSONObject
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.net.HttpURLConnection
import java.net.URL
import java.util.LinkedHashMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * vc61 manual Cloudflare Realtime SFU diagnostic engine.
 *
 * This engine deliberately sits beside the proven vc60 P2P/TURN path.  It uses the existing
 * PeerConnectionFactory + microphone AudioTrack owned by InternetNode, so there is still only one
 * Android audio capture stack.  MQTT remains RideMesh's presence/track-announcement channel.
 * Cloudflare credentials never live in the APK; every Realtime API call is proxied through the
 * ridemesh-sfu-backend Worker.
 */
internal class CloudflareSfuEngine(
    private val factory: PeerConnectionFactory,
    private val localAudioTrack: AudioTrack,
    private val backendUrl: String,
    private val callback: Callback,
) : AutoCloseable {

    interface Callback {
        fun onPublished(sessionId: String, trackName: String)
        fun onState(message: String)
        fun onError(message: String)
    }

    data class Diagnostics(
        val sessionId: String,
        val state: String,
        val iceState: String,
        val peerConnectionState: String,
        val localTrackName: String,
        val remoteTracks: Int,
        val publishCalls: Int,
        val subscribeCalls: Int,
        val renegotiations: Int,
        val reconnects: Int,
        val packetsSent: Long,
        val packetsReceived: Long,
        val lastTxPacketAgeMs: Long,
        val lastRxPacketAgeMs: Long,
        val rttMs: Double,
        val jitterMs: Double,
        val lossPercent: Double,
        val lastError: String,
    )

    private val closed = AtomicBoolean(false)
    private val started = AtomicBoolean(false)
    private val serial = Executors.newSingleThreadExecutor { r -> Thread(r, "RideMesh-SFU-Control").apply { isDaemon = true } }
    private val subscribed = ConcurrentHashMap.newKeySet<String>()
    // vc62: a duplicate MQTT announcement can arrive after pending was removed but before
    // Cloudflare renegotiation completes. Keep the active key reserved across that whole window.
    private val inFlightSubscriptions = ConcurrentHashMap.newKeySet<String>()
    // Cloudflare Realtime allows only one SDP-changing operation at a time. Remote track
    // announcements can arrive over MQTT before the local microphone publish has completed,
    // so queue them until the initial offer/answer is stable and serialize every pull/renegotiate.
    private val pendingSubscriptions = LinkedHashMap<String, Pair<String, String>>()
    @Volatile private var initialPublishComplete = false
    @Volatile private var negotiationInFlight = false
    private val publishCalls = AtomicInteger(0)
    private val subscribeCalls = AtomicInteger(0)
    private val renegotiations = AtomicInteger(0)
    private val reconnects = AtomicInteger(0)

    @Volatile private var pc: PeerConnection? = null
    @Volatile private var sessionId = ""
    @Volatile private var localTrackName = ""
    @Volatile private var state = "IDLE"
    @Volatile private var iceState = "NEW"
    @Volatile private var connectionState = "NEW"
    @Volatile private var lastError = ""
    @Volatile private var packetsSent = 0L
    @Volatile private var packetsReceived = 0L
    @Volatile private var lastTxProgressMs = 0L
    @Volatile private var lastRxProgressMs = 0L
    @Volatile private var rttMs = -1.0
    @Volatile private var jitterMs = -1.0
    @Volatile private var lossPercent = -1.0

    fun start() {
        if (!started.compareAndSet(false, true) || closed.get()) return
        serial.execute {
            try {
                state = "CREATING SESSION"
                callback.onState(state)
                sessionId = createSession()
                if (sessionId.isBlank()) error("SFU backend returned no sessionId")
                createPeerConnectionAndPublish()
            } catch (t: Throwable) {
                fail("SFU start failed: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    fun subscribe(remoteSessionId: String, trackName: String) {
        if (remoteSessionId.isBlank() || trackName.isBlank()) return
        if (remoteSessionId == sessionId && trackName == localTrackName) return
        val key = "$remoteSessionId/$trackName"
        serial.execute {
            if (closed.get() || subscribed.contains(key) || inFlightSubscriptions.contains(key) || pendingSubscriptions.containsKey(key)) return@execute
            pendingSubscriptions[key] = remoteSessionId to trackName
            drainPendingSubscriptions()
        }
    }

    private fun drainPendingSubscriptions() {
        if (closed.get() || !initialPublishComplete || negotiationInFlight) return
        val next = pendingSubscriptions.entries.firstOrNull() ?: return
        val key = next.key
        val (remoteSessionId, trackName) = next.value
        pendingSubscriptions.remove(key)
        val connection = pc
        if (connection == null) {
            pendingSubscriptions[key] = remoteSessionId to trackName
            return
        }
        negotiationInFlight = true
        inFlightSubscriptions.add(key)
        state = "SUBSCRIBING"
        callback.onState(state)
        try {
            val response = postJson(
                "/pull",
                JSONObject()
                    .put("sessionId", sessionId)
                    .put("remoteSessionId", remoteSessionId)
                    .put("trackName", trackName)
            )
            subscribeCalls.incrementAndGet()
            val description = response.optJSONObject("sessionDescription")
            if (response.optBoolean("requiresImmediateRenegotiation", description != null) && description != null) {
                val offer = SessionDescription(SessionDescription.Type.OFFER, description.optString("sdp"))
                setRemote(
                    connection,
                    offer,
                    onSuccess = { createAndSendRenegotiationAnswer(connection, key) },
                    onFailure = { error ->
                        serial.execute {
                            negotiationInFlight = false
                            inFlightSubscriptions.remove(key)
                            fail("SFU pull remote SDP: $error")
                        }
                    }
                )
            } else {
                subscribed.add(key)
                inFlightSubscriptions.remove(key)
                negotiationInFlight = false
                state = "SUBSCRIBED"
                callback.onState(state)
                drainPendingSubscriptions()
            }
        } catch (t: Throwable) {
            negotiationInFlight = false
            inFlightSubscriptions.remove(key)
            pendingSubscriptions[key] = remoteSessionId to trackName
            fail("SFU subscribe failed: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    fun diagnostics(): Diagnostics {
        pc?.getStats { report ->
            var sent = 0L
            var received = 0L
            var lost = 0L
            var haveLost = false
            var currentRtt = -1.0
            var currentJitter = -1.0
            report.statsMap.values.forEach { stat ->
                val m = stat.members
                when (stat.type) {
                    "outbound-rtp" -> if (((m["kind"] ?: m["mediaType"])?.toString()).equals("audio", true)) {
                        sent += (m["packetsSent"] as? Number)?.toLong() ?: 0L
                    }
                    "inbound-rtp" -> if (((m["kind"] ?: m["mediaType"])?.toString()).equals("audio", true)) {
                        received += (m["packetsReceived"] as? Number)?.toLong() ?: 0L
                        val l = (m["packetsLost"] as? Number)?.toLong()
                        if (l != null) { lost += l; haveLost = true }
                        val j = (m["jitter"] as? Number)?.toDouble()
                        if (j != null) currentJitter = maxOf(currentJitter, j * 1000.0)
                    }
                    "candidate-pair" -> {
                        val pairState = m["state"]?.toString().orEmpty()
                        val nominated = m["nominated"] as? Boolean ?: false
                        if ((pairState.equals("succeeded", true) || nominated) && currentRtt < 0) {
                            val r = (m["currentRoundTripTime"] as? Number)?.toDouble()
                            if (r != null) currentRtt = r * 1000.0
                        }
                    }
                }
            }
            val now = android.os.SystemClock.elapsedRealtime()
            if (sent > packetsSent) lastTxProgressMs = now
            if (received > packetsReceived) lastRxProgressMs = now
            packetsSent = sent
            packetsReceived = received
            if (currentRtt >= 0) rttMs = currentRtt
            if (currentJitter >= 0) jitterMs = currentJitter
            if (haveLost && received + lost > 0) lossPercent = lost.toDouble() * 100.0 / (received + lost).toDouble()
        }
        return Diagnostics(
            sessionId = sessionId,
            state = state,
            iceState = iceState,
            peerConnectionState = connectionState,
            localTrackName = localTrackName,
            remoteTracks = subscribed.size,
            publishCalls = publishCalls.get(),
            subscribeCalls = subscribeCalls.get(),
            renegotiations = renegotiations.get(),
            reconnects = reconnects.get(),
            packetsSent = packetsSent,
            packetsReceived = packetsReceived,
            lastTxPacketAgeMs = if (lastTxProgressMs == 0L) -1L else (android.os.SystemClock.elapsedRealtime() - lastTxProgressMs),
            lastRxPacketAgeMs = if (lastRxProgressMs == 0L) -1L else (android.os.SystemClock.elapsedRealtime() - lastRxProgressMs),
            rttMs = rttMs,
            jitterMs = jitterMs,
            lossPercent = lossPercent,
            lastError = lastError,
        )
    }

    fun isConnected(): Boolean = connectionState == "CONNECTED" || iceState == "CONNECTED" || iceState == "COMPLETED"
    fun remoteTrackCount(): Int = subscribed.size

    private fun createPeerConnectionAndPublish() {
        val config = PeerConnection.RTCConfiguration(
            listOf(PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer())
        ).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        val connection = factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState) = Unit
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                iceState = newState.name
                if (newState == PeerConnection.IceConnectionState.FAILED) reconnects.incrementAndGet()
                callback.onState("SFU ICE ${newState.name}")
            }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                connectionState = newState.name
                state = if (newState == PeerConnection.PeerConnectionState.CONNECTED) "CONNECTED" else state
                callback.onState("SFU ${newState.name}")
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) = Unit
            override fun onIceCandidate(candidate: IceCandidate) = Unit // Cloudflare SFU uses the SDP exchange; no app-side trickle endpoint.
            override fun onIceCandidatesRemoved(candidates: Array<IceCandidate>) = Unit
            override fun onAddStream(stream: MediaStream) = Unit
            override fun onRemoveStream(stream: MediaStream) = Unit
            override fun onDataChannel(dataChannel: DataChannel) = Unit
            override fun onRenegotiationNeeded() = Unit
            override fun onAddTrack(receiver: RtpReceiver, mediaStreams: Array<MediaStream>) {
                receiver.track()?.setEnabled(true)
            }
        }) ?: error("Could not create SFU PeerConnection")
        pc = connection

        // Reuse the same proven WebRTC AudioTrack API as vc60. The Worker publishes the offer with
        // autoDiscover so Cloudflare discovers this audio m-line and assigns the global track name.
        connection.addTrack(localAudioTrack, listOf("ridemesh-sfu"))
        runCatching { connection.setBitrate(28_000, 42_000, 60_000) }

        state = "CREATING OFFER"
        connection.createOffer(object : BaseSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                val offer = SessionDescription(desc.type, preferOpus(desc.description))
                connection.setLocalDescription(object : BaseSdpObserver() {
                    override fun onSetSuccess() {
                        serial.execute { publishOffer(connection, offer) }
                    }
                    override fun onSetFailure(error: String) = fail("SFU set local offer: $error")
                }, offer)
            }
            override fun onCreateFailure(error: String) = fail("SFU create offer: $error")
        }, MediaConstraints())
    }

    private fun publishOffer(connection: PeerConnection, offer: SessionDescription) {
        try {
            state = "PUBLISHING MIC"
            val response = postJson(
                "/publish",
                JSONObject()
                    .put("sessionId", sessionId)
                    .put("sessionDescription", JSONObject().put("type", "offer").put("sdp", offer.description))
            )
            publishCalls.incrementAndGet()
            val answerJson = response.optJSONObject("sessionDescription") ?: error("SFU publish response missing sessionDescription")
            val trackArray = response.optJSONArray("tracks") ?: error("SFU publish response missing tracks")
            if (trackArray.length() == 0) error("SFU published zero tracks")
            val firstTrack = trackArray.optJSONObject(0) ?: error("Invalid SFU track response")
            localTrackName = firstTrack.optString("trackName").ifBlank { localAudioTrack.id() }
            val answer = SessionDescription(SessionDescription.Type.ANSWER, answerJson.optString("sdp"))
            setRemote(connection, answer,
                onSuccess = {
                    serial.execute {
                        initialPublishComplete = true
                        state = "PUBLISHED"
                        callback.onPublished(sessionId, localTrackName)
                        callback.onState("SFU MIC PUBLISHED")
                        drainPendingSubscriptions()
                    }
                },
                onFailure = { error -> fail("SFU set publish answer: $error") }
            )
        } catch (t: Throwable) {
            fail("SFU publish failed: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun createAndSendRenegotiationAnswer(connection: PeerConnection, subscriptionKey: String) {
        connection.createAnswer(object : BaseSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                val answer = SessionDescription(desc.type, preferOpus(desc.description))
                connection.setLocalDescription(object : BaseSdpObserver() {
                    override fun onSetSuccess() {
                        serial.execute {
                            try {
                                putJson(
                                    "/renegotiate",
                                    JSONObject()
                                        .put("sessionId", sessionId)
                                        .put("sessionDescription", JSONObject().put("type", "answer").put("sdp", answer.description))
                                )
                                renegotiations.incrementAndGet()
                                subscribed.add(subscriptionKey)
                                inFlightSubscriptions.remove(subscriptionKey)
                                negotiationInFlight = false
                                state = "SUBSCRIBED"
                                callback.onState("SFU REMOTE AUDIO SUBSCRIBED")
                                drainPendingSubscriptions()
                            } catch (t: Throwable) {
                                negotiationInFlight = false
                                inFlightSubscriptions.remove(subscriptionKey)
                                fail("SFU renegotiate failed: ${t.message ?: t.javaClass.simpleName}")
                            }
                        }
                    }
                    override fun onSetFailure(error: String) { negotiationInFlight = false; inFlightSubscriptions.remove(subscriptionKey); fail("SFU set local answer: $error") }
                }, answer)
            }
            override fun onCreateFailure(error: String) { negotiationInFlight = false; inFlightSubscriptions.remove(subscriptionKey); fail("SFU create answer: $error") }
        }, MediaConstraints())
    }

    private fun setRemote(connection: PeerConnection, description: SessionDescription, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        connection.setRemoteDescription(object : BaseSdpObserver() {
            override fun onSetSuccess() = onSuccess()
            override fun onSetFailure(error: String) = onFailure(error)
        }, description)
    }

    private fun createSession(): String {
        val response = postJson("/session", JSONObject())
        return response.optJSONObject("session")?.optString("sessionId")
            ?.ifBlank { response.optString("sessionId") }
            ?: response.optString("sessionId")
    }

    private fun postJson(path: String, body: JSONObject): JSONObject = requestJson("POST", path, body)
    private fun putJson(path: String, body: JSONObject): JSONObject = requestJson("PUT", path, body)

    private fun requestJson(method: String, path: String, body: JSONObject): JSONObject {
        val connection = (URL(backendUrl.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = HTTP_TIMEOUT_MS
            readTimeout = HTTP_TIMEOUT_MS
            doOutput = true
            useCaches = false
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body.toString()) }
            val status = connection.responseCode
            val source = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = source?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = if (text.isBlank()) JSONObject() else JSONObject(text)
            if (status !in 200..299 || json.optBoolean("ok", true).not()) {
                error("HTTP $status ${json.optString("error", text).take(240)}")
            }
            // Worker wraps some calls in {ok:true, response:{...}} and may proxy others directly.
            return json.optJSONObject("response") ?: json
        } finally {
            connection.disconnect()
        }
    }

    private fun fail(message: String) {
        lastError = message
        state = "ERROR"
        callback.onError(message)
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        runCatching { pc?.close() }
        runCatching { pc?.dispose() }
        pc = null
        serial.shutdownNow()
        state = "CLOSED"
    }

    private open class BaseSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) = Unit
        override fun onSetSuccess() = Unit
        override fun onCreateFailure(error: String) = Unit
        override fun onSetFailure(error: String) = Unit
    }

    companion object {
        private const val HTTP_TIMEOUT_MS = 10_000

        private fun preferOpus(sdp: String): String {
            val lines = sdp.split("\r\n").toMutableList()
            val audioLineIndex = lines.indexOfFirst { it.startsWith("m=audio ") }
            if (audioLineIndex < 0) return sdp
            val opusPayload = lines.firstOrNull { it.startsWith("a=rtpmap:") && it.contains("opus/48000", true) }
                ?.substringAfter("a=rtpmap:")?.substringBefore(' ')
                ?: return sdp
            val parts = lines[audioLineIndex].split(' ').toMutableList()
            val payloadIndex = parts.indexOf(opusPayload)
            if (payloadIndex > 2) {
                parts.removeAt(payloadIndex)
                parts.add(3, opusPayload)
                lines[audioLineIndex] = parts.joinToString(" ")
            }
            return lines.joinToString("\r\n")
        }
    }
}
