package com.bikemesh.ridemesh.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Process
import java.util.ArrayDeque
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

enum class AudioRoute {
    AUTO,
    PHONE,
    HELMET,
}

class AudioEngine(
    context: Context,
    private val onCapturedFrame: (ByteArray) -> Unit,
    private val onStatus: (String) -> Unit,
    neuralVadInitiallyEnabled: Boolean = false,
) {
    private val appContext = context.applicationContext
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val musicDucker = OfflineMusicDucker(audioManager)
    private val routeHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var routeCallbackRegistered = false
    private val deviceCallback = object : android.media.AudioDeviceCallback() {
        override fun onAudioDevicesAdded(devices: Array<out AudioDeviceInfo>) = recoverRoute()
        override fun onAudioDevicesRemoved(devices: Array<out AudioDeviceInfo>) = recoverRoute()
    }
    private fun recoverRoute() {
        routeHandler.postDelayed({
            if (transmitDesired.get() && !focusPaused.get()) selectCommunicationDevice()
        }, 350L)
    }
    private val capturing = AtomicBoolean(false)
    private val playbackRunning = AtomicBoolean(true)
    private val transmitDesired = AtomicBoolean(false)
    /** vc62: online bridge phones use WebRTC for capture but need local-mesh playout. */
    private val playbackOnlyDesired = AtomicBoolean(false)
    private val focusPaused = AtomicBoolean(false)
    private val focusHeld = AtomicBoolean(false)
    private val userMuted = AtomicBoolean(false)
    private val capturedFrames = java.util.concurrent.atomic.AtomicLong()
    private val forwardedFrames = java.util.concurrent.atomic.AtomicLong()
    @Volatile private var micLevel = 0
    private val playedBytes = java.util.concurrent.atomic.AtomicLong()
    private val rebufferCount = java.util.concurrent.atomic.AtomicLong()
    private val playbackLock = Any()
    private val playbackErrors = java.util.concurrent.atomic.AtomicLong()
    private val incomingFlushes = java.util.concurrent.atomic.AtomicLong()
    private val rxPackets = java.util.concurrent.atomic.AtomicLong()
    private val rxMissing = java.util.concurrent.atomic.AtomicLong()
    private val rxDuplicate = java.util.concurrent.atomic.AtomicLong()
    private val rxReordered = java.util.concurrent.atomic.AtomicLong()
    private val rxLate = java.util.concurrent.atomic.AtomicLong()
    private val rxUnderruns = java.util.concurrent.atomic.AtomicLong()
    private val maxQueueDepth = java.util.concurrent.atomic.AtomicInteger()
    private val neuralVadEnabled = AtomicBoolean(neuralVadInitiallyEnabled)
    @Volatile private var neuralVadStatus = if (neuralVadInitiallyEnabled) "Silero pending next offline start" else "Silero off"
    fun setNeuralVadEnabled(enabled: Boolean) {
        neuralVadEnabled.set(enabled)
        neuralVadStatus = if (enabled) "Silero pending next offline start" else "Silero off"
    }
    fun isCaptureReleased() = audioRecord == null && !capturing.get()
    fun isAudioInterrupted() = focusPaused.get()
    fun canSendAudio() = transmitDesired.get() && !focusPaused.get() && !userMuted.get()
    fun voiceStatus() = when {
        !transmitDesired.get() -> "Audio stopped"
        focusPaused.get() -> "Audio interrupted"
        !capturing.get() -> "Microphone unavailable"
        userMuted.get() -> "Muted • listening"
        else -> "Microphone running"
    }
    fun diagnostics() = "Voice: ${voiceStatus()}\nMic running: ${capturing.get()} • capture buffers: ${capturedFrames.get()} • level: $micLevel\nMic frames forwarded: ${forwardedFrames.get()} • muted: ${userMuted.get()}\nSpeaker PCM bytes written: ${playedBytes.get()} • playback errors: ${playbackErrors.get()} • rebuffers: ${rebufferCount.get()} • incoming flushes: ${incomingFlushes.get()}\nPCM DIAG RX: ${rxPackets.get()} • missing: ${rxMissing.get()} • duplicate: ${rxDuplicate.get()} • reordered: ${rxReordered.get()} • late: ${rxLate.get()} • underruns: ${rxUnderruns.get()} • maxQ: ${maxQueueDepth.get()}\n${receiveBufferDiagnostics()}\nNeural VAD: $neuralVadStatus"

    /** vc56 read-only snapshot. Called from the diagnostics UI, never from the audio scheduler. */
    private fun receiveBufferDiagnostics(): String {
        val now = android.os.SystemClock.elapsedRealtime()
        var sources = 0
        var primed = 0
        var totalFrames = 0
        var maxDepth = 0
        var maxPrime = 0
        var maxJitter = 0.0
        var oldestAge = 0L
        for (state in sourceStates.values) {
            synchronized(state) {
                sources++
                if (state.primed) primed++
                val depth = state.frames.size
                totalFrames += depth
                if (depth > maxDepth) maxDepth = depth
                if (state.targetPrimeFrames > maxPrime) maxPrime = state.targetPrimeFrames
                if (state.jitterEwmaMs > maxJitter) maxJitter = state.jitterEwmaMs
                val first = state.frames.firstEntry()?.value
                if (first != null) oldestAge = maxOf(oldestAge, now - first.arrivalMs)
            }
        }
        return "RX buffer now: sources $sources • primed $primed • queued $totalFrames frames (${totalFrames * FRAME_MS} ms aggregate) • max source depth $maxDepth • target prime $maxPrime frames • jitter ${"%.1f".format(maxJitter)} ms • oldest buffered ${oldestAge.coerceAtLeast(0L)} ms"
    }

    private data class IncomingFrame(
        val sequence: Int,
        val timestampMs: Long,
        val arrivalMs: Long,
        val audio: ByteArray,
    )

    private class SourceState {
        val frames = TreeMap<Int, IncomingFrame>()
        var expectedSequence: Int? = null
        var primed = false
        var targetPrimeFrames = MIN_PRIME_FRAMES
        var jitterEwmaMs = 0.0
        var lastArrivalMs = 0L
        var lastSenderTimestampMs = 0L
        // vc55: several frames arrive together in one Nearby payload (a "burst").
        var burstArrivalMs = 0L
        var burstSenderTimestampMs = 0L
        var burstFrames = 0
        var largestBurstFrames = 1
        var highestReceived: Int? = null
        var lastSeenMs = 0L
        var lastGoodFrame: ByteArray? = null
        var consecutivePlc = 0
    }

    /**
     * vc79 keeps an ordered adaptive jitter buffer for each rider. Nearby delivers the
     * four-frame voice payloads in bursts, so keep 120 ms minimum working headroom and
     * expand gradually toward 200 ms when measured burst jitter rises. Short starvation
     * is concealed for up to 60 ms before a full re-prime.
     */
    @Volatile var packetDecoder: ((String, ByteArray?, Boolean) -> ByteArray?)? = null
    /** vc68: observes per-rider PCM only after vc56 jitter ordering/PLC/codec decode.
     * Used by the hybrid bridge so SFU forwarding never decodes packets in arrival order. */
    @Volatile var orderedPcmObserver: ((String, ByteArray) -> Unit)? = null
    private val sourceStates = ConcurrentHashMap<String, SourceState>()
    private val rawPcmSources = ConcurrentHashMap.newKeySet<String>()

    @Volatile private var audioRecord: AudioRecord? = null
    @Volatile private var audioTrack: AudioTrack? = null
    @Volatile private var route: AudioRoute = AudioRoute.AUTO
    @Volatile private var playbackActiveUntilMs = 0L

    private val playbackThread = Thread({ playbackLoop() }, "RideMesh-Mixer").apply {
        isDaemon = true
        start()
    }

    private val voiceAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> resumeAfterAudioFocus()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> pauseForAudioFocus()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> Unit
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Close capture first. Reacquire only for active ordinary media with no
                // system communication mode; transient call interruptions never take this path.
                pauseForAudioFocus()
                routeHandler.postDelayed({
                    if (transmitDesired.get() && focusPaused.get() && audioManager.isMusicActive &&
                        audioManager.mode == AudioManager.MODE_NORMAL) {
                        focusHeld.set(false)
                        if (ensureAudioFocus()) startRecorder()
                    }
                }, 650L)
            }
        }
    }

    private val audioFocusRequest: AudioFocusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(voiceAttributes)
            .setAcceptsDelayedFocusGain(true)
            .setWillPauseWhenDucked(false)
            .setOnAudioFocusChangeListener(audioFocusListener)
            .build()
    }

    private fun ensureAudioFocus(): Boolean {
        if (focusHeld.get() && focusPaused.get()) return false
        if (focusHeld.get() && !focusPaused.get()) return true
        return when (audioManager.requestAudioFocus(audioFocusRequest)) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                focusHeld.set(true)
                focusPaused.set(false)
                musicDucker.setEnabled(true)
                true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                focusHeld.set(true)
                focusPaused.set(true)
                onStatus("PAUSED FOR PHONE CALL • AUTO RESUME")
                false
            }
            else -> {
                focusHeld.set(false)
                focusPaused.set(true)
                onStatus("AUDIO BUSY • WAITING TO RESUME")
                false
            }
        }
    }

    private fun pauseForAudioFocus() {
        if (!transmitDesired.get()) return
        if (!focusPaused.compareAndSet(false, true)) return
        musicDucker.setEnabled(false)
        capturing.set(false)
        // Stop the recorder immediately so RideMesh cannot leak a phone/WhatsApp call
        // into the ride while another communication app owns audio focus.
        try { audioRecord?.stop() } catch (_: Throwable) {}
        clearRemoteAudio()
        audioTrack?.let {
            try { it.pause() } catch (_: Throwable) {}
            try { it.flush() } catch (_: Throwable) {}
        }
        releaseCommunicationRouteForExternalCall()
        onStatus("CALL / OTHER AUDIO ACTIVE • RIDEMESH PAUSED")
    }

    private fun resumeAfterAudioFocus() {
        if (!transmitDesired.get()) return
        focusHeld.set(true)
        if (!focusPaused.compareAndSet(true, false)) return
        Thread({
            try { Thread.sleep(CALL_RESUME_SETTLE_MS) } catch (_: InterruptedException) { return@Thread }
            if (focusPaused.get() || !transmitDesired.get()) return@Thread
            musicDucker.setEnabled(true)
            selectCommunicationDevice()
            audioTrack?.let {
                try { it.play() } catch (_: Throwable) {}
            }
            onStatus("HANDS-FREE • AUDIO RESUMED")
            if (transmitDesired.get()) startRecorder()
        }, "RideMesh-CallResume").apply { isDaemon = true; start() }
    }

    @Suppress("DEPRECATION")
    private fun releaseCommunicationRouteForExternalCall() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice()
            } else {
                runCatching { audioManager.stopBluetoothSco() }
                audioManager.isBluetoothScoOn = false
                audioManager.isSpeakerphoneOn = false
            }
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (_: Throwable) {
            // The external call already has priority; failing to clear one route must not
            // cause RideMesh to fight for audio.
        }
    }

    /** Engineering hook: drop all queued remote audio immediately on direct-link loss/re-generation. */
    fun flushIncoming(reason: String = "transport reset") {
        incomingFlushes.incrementAndGet()
        clearRemoteAudio()
        synchronized(playbackLock) {
            audioTrack?.let {
                try { it.pause() } catch (_: Throwable) {}
                try { it.flush() } catch (_: Throwable) {}
                try { it.play() } catch (_: Throwable) {}
            }
        }
        onStatus("REMOTE AUDIO FLUSHED • $reason")
    }

    private fun clearRemoteAudio() {
        sourceStates.values.forEach { state ->
            synchronized(state) {
                state.frames.clear()
                state.expectedSequence = null
                state.primed = false
                state.lastGoodFrame = null
                state.consecutivePlc = 0
            }
        }
        sourceStates.clear()
        rawPcmSources.clear()
    }

    fun setRoute(newRoute: AudioRoute) {
        route = newRoute
        if (transmitDesired.get() && !focusPaused.get()) selectCommunicationDevice()
    }

    fun setUserMuted(muted: Boolean) {
        userMuted.set(muted)
        if (muted) {
            onStatus("MIC MUTED • LISTENING ONLY")
        } else {
            onStatus("HANDS-FREE • MIC LIVE")
        }
    }

    fun isUserMuted(): Boolean = userMuted.get()

    @SuppressLint("MissingPermission")
    fun selectCommunicationDevice(): String {
        return try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val available = audioManager.availableCommunicationDevices
                val helmet = available.firstOrNull { it.isHelmetCandidate() }
                val speaker = available.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }

                val chosen = when (route) {
                    AudioRoute.HELMET -> helmet ?: speaker
                    AudioRoute.PHONE -> speaker
                    AudioRoute.AUTO -> helmet ?: speaker
                }

                if (chosen == null) {
                    val text = when (route) {
                        AudioRoute.HELMET -> "Audio: no call-capable Bluetooth headset found"
                        AudioRoute.PHONE -> "Audio: phone speaker unavailable"
                        AudioRoute.AUTO -> "Audio: no communication device available"
                    }
                    onStatus(text)
                    text
                } else {
                    val ok = audioManager.setCommunicationDevice(chosen)
                    val label = chosen.routeLabel()
                    val text = if (ok) "Audio: $label" else "Audio routing failed: $label"
                    onStatus(text)
                    text
                }
            } else {
                val hasBluetoothSco = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                    .any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }

                val useBluetooth = when (route) {
                    AudioRoute.HELMET -> hasBluetoothSco
                    AudioRoute.PHONE -> false
                    AudioRoute.AUTO -> hasBluetoothSco
                }

                @Suppress("DEPRECATION")
                if (useBluetooth) {
                    audioManager.isSpeakerphoneOn = false
                    audioManager.startBluetoothSco()
                    audioManager.isBluetoothScoOn = true
                    "Audio: Bluetooth headset"
                } else {
                    audioManager.stopBluetoothSco()
                    audioManager.isBluetoothScoOn = false
                    audioManager.isSpeakerphoneOn = true
                    "Audio: phone speaker + microphone"
                }.also(onStatus)
            }
        } catch (t: Throwable) {
            val text = "Audio routing error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}"
            onStatus(text)
            text
        }
    }

    /** vc62 hybrid bridge: enable the existing low-latency mixer without opening AudioRecord.
     * WebRTC remains the only microphone owner on an Internet-capable bridge phone. */
    fun startPlaybackOnly() {
        playbackOnlyDesired.set(true)
    }

    fun stopPlaybackOnly() {
        playbackOnlyDesired.set(false)
        clearRemoteAudio()
        synchronized(playbackLock) {
            val track = audioTrack
            audioTrack = null
            runCatching { track?.pause() }
            runCatching { track?.flush() }
            runCatching { track?.release() }
        }
    }

    fun isPlaybackOnlyActive(): Boolean = playbackOnlyDesired.get()

    @SuppressLint("MissingPermission")
    fun startTransmit() {
        transmitDesired.set(true)
        if (!ensureAudioFocus() || focusPaused.get()) return
        if (!routeCallbackRegistered) {
            audioManager.registerAudioDeviceCallback(deviceCallback, routeHandler)
            routeCallbackRegistered = true
        }
        startRecorder()
    }

    @SuppressLint("MissingPermission")
    private fun startRecorder() {
        // An old recorder may still be unwinding after a focus interruption.
        // Never overwrite it with another recorder sharing the same capture flag.
        if (audioRecord != null) return
        if (!capturing.compareAndSet(false, true)) return

        var recorder: AudioRecord? = null
        try {
            selectCommunicationDevice()

            val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING)
            if (min <= 0) {
                capturing.set(false)
                onStatus("Microphone buffer unavailable")
                return
            }
            val recordBuffer = max(min, FRAME_BYTES * 2)

            recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                CHANNEL_IN,
                ENCODING,
                recordBuffer,
            )

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                capturing.set(false)
                recorder.release()
                onStatus("Microphone could not start")
                return
            }

            val aec = createAec(recorder.audioSessionId)
            val ns = createNs(recorder.audioSessionId)
            val agc = createAgc(recorder.audioSessionId)

            audioRecord = recorder
            recorder.startRecording()
            onStatus("HANDS-FREE • ECHO GUARD • VAD • ${effectsLabel(aec != null, ns != null, agc != null)}")

            val activeRecorder = recorder
            Thread({
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                val frame = ByteArray(FRAME_BYTES)
                val preRoll = ArrayDeque<ByteArray>(VAD_PREROLL_FRAMES)
                val windFilter = WindRumbleFilter(SAMPLE_RATE, WIND_FILTER_CUTOFF_HZ)
                var hangover = 0
                var noiseFloor = VAD_INITIAL_NOISE_FLOOR
                val neuralDetector = if (neuralVadEnabled.get()) {
                    runCatching { SileroSpeechDetector(appContext) }
                        .onFailure { neuralVadStatus = "Silero fallback: ${it.javaClass.simpleName}" }
                        .getOrNull()
                } else null
                var neuralFailed = false
                if (neuralDetector != null) neuralVadStatus = neuralDetector.diagnostics()

                try {
                    while (capturing.get()) {
                        // AudioRecord is allowed to return a partial buffer. Beta2 treated every
                        // partial read as a complete 20 ms packet, which can sound slow/choppy.
                        // Beta3 accumulates exactly one 20 ms frame before VAD/transmission.
                        var filled = 0
                        while (filled < frame.size && capturing.get()) {
                            val read = activeRecorder.read(
                                frame,
                                filled,
                                frame.size - filled,
                                AudioRecord.READ_BLOCKING,
                            )
                            if (read < 0) throw IllegalStateException("AudioRecord read error $read")
                            if (read == 0) continue
                            filled += read
                        }
                        if (filled != frame.size) continue
                        if (!canSendAudio() || (Build.VERSION.SDK_INT >= 29 &&
                            activeRecorder.activeRecordingConfiguration?.isClientSilenced == true)) {
                            preRoll.clear()
                            neuralDetector?.clearPending()
                            hangover = 0
                            continue
                        }

                        val current = windFilter.process(frame.copyOf())
                        val rms = pcmRms(current)
                        capturedFrames.incrementAndGet(); micLevel = rms.toInt()

                        val normalThreshold = max(VAD_MIN_RMS, noiseFloor * VAD_NOISE_MULTIPLIER)
                        val farEndAudioActive = android.os.SystemClock.elapsedRealtime() < playbackActiveUntilMs
                        val echoThreshold = if (aec != null) {
                            max(VAD_ECHO_MIN_RMS_AEC, normalThreshold * VAD_ECHO_MULTIPLIER_AEC)
                        } else {
                            max(VAD_ECHO_MIN_RMS_NO_AEC, normalThreshold * VAD_ECHO_MULTIPLIER_NO_AEC)
                        }
                        val speechThreshold = if (farEndAudioActive) echoThreshold else normalThreshold
                        val neuralSpeech = if (neuralFailed) null else {
                            runCatching { neuralDetector?.observe(current) }
                                .onFailure {
                                    neuralFailed = true
                                    neuralVadStatus = "Silero fallback: ${it.javaClass.simpleName}"
                                }
                                .getOrNull()
                        }
                        val speech = when {
                            neuralSpeech == null -> rms >= speechThreshold
                            farEndAudioActive -> neuralSpeech && rms >= speechThreshold
                            else -> neuralSpeech
                        }
                        if (capturedFrames.get() % 50L == 0L && neuralDetector != null && !neuralFailed) {
                            neuralVadStatus = neuralDetector.diagnostics()
                        }
                        if (speech) musicDucker.speech()

                        // A manual mute keeps the recorder alive for instant recovery but sends no frames.
                        // Clear pre-roll/hangover so speech recorded while muted can never leak after unmuting.
                        if (userMuted.get()) {
                            preRoll.clear()
                            hangover = 0
                            if (!farEndAudioActive) {
                                noiseFloor = (noiseFloor * 0.985) + (rms * 0.015)
                            }
                            continue
                        }

                        // Do not learn loud far-end playback as the new road-noise floor.
                        if (!speech && !farEndAudioActive) {
                            noiseFloor = (noiseFloor * 0.985) + (rms * 0.015)
                        }

                        if (speech) hangover = VAD_HANGOVER_FRAMES
                        else if (hangover > 0) hangover--

                        // Rider/Pillion natural-voice profile: restore the vc56 offline media cadence.
                        // Speech plus pre-roll and hangover avoids continuously loading Nearby while
                        // retaining the known-good vc56 voice behavior.
                        if (!OFFLINE_VOICE_ACTIVATED || speech || hangover > 0) {
                            while (preRoll.isNotEmpty()) {
                                onCapturedFrame(preRoll.removeFirst())
                                forwardedFrames.incrementAndGet()
                            }
                            onCapturedFrame(current)
                            forwardedFrames.incrementAndGet()
                        } else {
                            preRoll.addLast(current)
                            while (preRoll.size > VAD_PREROLL_FRAMES) preRoll.removeFirst()
                        }
                    }
                } catch (t: Throwable) {
                    if (!focusPaused.get()) {
                        onStatus("Microphone stream error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}")
                    }
                } finally {
                    neuralDetector?.close()
                    neuralVadStatus = if (neuralVadEnabled.get()) "Silero stopped" else "Silero off"
                    try { activeRecorder.stop() } catch (_: Throwable) {}
                    aec?.release()
                    ns?.release()
                    agc?.release()
                    activeRecorder.release()
                    if (audioRecord === activeRecorder) {
                        audioRecord = null
                        capturing.set(false)
                    }
                }
            }, "RideMesh-Mic").start()
        } catch (t: Throwable) {
            capturing.set(false)
            try { recorder?.release() } catch (_: Throwable) {}
            if (audioRecord === recorder) audioRecord = null
            onStatus("Microphone error: ${t.javaClass.simpleName}: ${t.message ?: "unknown"}")
        }
    }

    fun stopTransmit() {
        transmitDesired.set(false)
        musicDucker.setEnabled(false)
        routeHandler.removeCallbacksAndMessages(null)
        if (routeCallbackRegistered) {
            runCatching { audioManager.unregisterAudioDeviceCallback(deviceCallback) }
            routeCallbackRegistered = false
        }
        capturing.set(false)
        try { audioRecord?.stop() } catch (_: Throwable) {}
        if (!playbackOnlyDesired.get()) {
            clearRemoteAudio()
            synchronized(playbackLock) {
                val track = audioTrack
                audioTrack = null
                runCatching { track?.pause() }
                runCatching { track?.flush() }
                runCatching { track?.release() }
            }
            releaseCommunicationRouteForExternalCall()
        }
        if (focusHeld.getAndSet(false)) {
            runCatching { audioManager.abandonAudioFocusRequest(audioFocusRequest) }
        }
    }

    /**
     * Add one sequenced 20 ms packet to the per-rider adaptive jitter buffer.
     * Sender timestamps are used only for inter-packet timing, never for wall-clock sync.
     */
    /** Enqueue already-decoded 16 kHz/20 ms PCM while the normal offline decoder stays installed. */
    fun playIncomingPcm(sourceId: String, sequence: Int, timestampMs: Long, pcm: ByteArray) {
        if (pcm.size != FRAME_BYTES) return
        val key = sourceId.ifBlank { "bridge-pcm" }
        rawPcmSources.add(key)
        playIncoming(key, sequence, timestampMs, pcm)
    }

    fun playIncoming(sourceId: String, sequence: Int, timestampMs: Long, audio: ByteArray) {
        if (audio.isEmpty() || !playbackRunning.get() || focusPaused.get()) return
        val key = sourceId.ifBlank { "unknown" }
        val normalized = if (packetDecoder != null) audio.copyOf() else when {
            audio.size == FRAME_BYTES -> audio.copyOf()
            audio.size > FRAME_BYTES -> audio.copyOf(FRAME_BYTES)
            else -> audio.copyOf(FRAME_BYTES)
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val state = sourceStates.computeIfAbsent(key) { SourceState() }

        synchronized(state) {
            rxPackets.incrementAndGet()
            if (state.frames.containsKey(sequence)) rxDuplicate.incrementAndGet()
            // vc55: loss/reorder are measured against the highest sequence RECEIVED.
            // vc54 compared against the playout position, which over-counted "missing"
            // whenever a few frames were buffered.
            val highest = state.highestReceived
            if (highest == null || sequence > highest) {
                if (highest != null && sequence > highest + 1) rxMissing.addAndGet((sequence - highest - 1).toLong())
                state.highestReceived = sequence
            } else if (sequence < highest) {
                rxReordered.incrementAndGet()
            }

            // Frames that arrive within BURST_WINDOW_MS belong to one payload. Jitter is measured
            // between payload arrivals, not between frames inside the same payload.
            val newBurst = state.burstArrivalMs == 0L || now - state.lastArrivalMs > BURST_WINDOW_MS
            if (newBurst) {
                if (state.burstArrivalMs > 0L) {
                    val arrivalDelta = now - state.burstArrivalMs
                    val senderDelta = timestampMs - state.burstSenderTimestampMs
                    if (arrivalDelta in 0L..1_000L && senderDelta in 10L..400L) {
                        val sample = abs(arrivalDelta.toDouble() - senderDelta.toDouble())
                        state.jitterEwmaMs = if (state.jitterEwmaMs == 0.0) {
                            sample
                        } else {
                            (state.jitterEwmaMs * 0.88) + (sample * 0.12)
                        }
                    }
                }
                state.burstArrivalMs = now
                state.burstSenderTimestampMs = timestampMs
                state.burstFrames = 1
            } else {
                state.burstFrames++
                if (state.burstFrames > state.largestBurstFrames) {
                    state.largestBurstFrames = state.burstFrames.coerceAtMost(MAX_BURST_FRAMES)
                }
            }
            // Headroom must cover one whole payload plus jitter, or playout drains between payloads.
            state.targetPrimeFrames = max(targetPrimeFrames(state.jitterEwmaMs), state.largestBurstFrames + 2)

            state.lastArrivalMs = now
            state.lastSenderTimestampMs = timestampMs
            state.lastSeenMs = now

            val expected = state.expectedSequence
            if (expected != null && sequence < expected - OLD_PACKET_TOLERANCE) return@synchronized
            if (!state.frames.containsKey(sequence)) {
                state.frames[sequence] = IncomingFrame(sequence, timestampMs, now, normalized)
            }

            maxQueueDepth.updateAndGet { old -> maxOf(old, state.frames.size) }
            while (state.frames.size > MAX_SOURCE_QUEUE_FRAMES) {
                state.frames.pollFirstEntry()
                rxLate.incrementAndGet()
            }

            // If the receiver ever gets far behind, jump forward rather than playing old speech.
            if (state.primed && state.frames.size > state.targetPrimeFrames + LATENCY_CATCHUP_MARGIN) {
                while (state.frames.size > state.targetPrimeFrames) state.frames.pollFirstEntry()
                state.expectedSequence = state.frames.firstKey()
                state.consecutivePlc = 0
            }
        }
    }

    private fun playbackLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        var nextTickNs = System.nanoTime()

        while (playbackRunning.get()) {
            try {
                if (focusPaused.get() || (!transmitDesired.get() && !playbackOnlyDesired.get())) {
                    Thread.sleep(PLAYBACK_IDLE_SLEEP_MS)
                    nextTickNs = System.nanoTime()
                    continue
                }

                val nowNs = System.nanoTime()
                if (nowNs < nextTickNs) {
                    sleepNanos(nextTickNs - nowNs)
                } else if (nowNs - nextTickNs > FRAME_NS * 3) {
                    // Do not attempt to replay missed scheduler time after a stall.
                    nextTickNs = nowNs
                }
                nextTickNs += FRAME_NS

                val nowMs = android.os.SystemClock.elapsedRealtime()
                val frames = ArrayList<ByteArray>(sourceStates.size)
                var activeSource = false

                for ((sourceId, state) in sourceStates) {
                    val frame = synchronized(state) { pullPlayoutFrame(sourceId, state, nowMs) }
                    if (frame != null) {
                        frames.add(frame)
                        // Keep this callback on the already-ordered 20 ms playout clock.
                        // The consumer must be non-blocking; the hybrid bridge only enqueues.
                        runCatching { orderedPcmObserver?.invoke(sourceId, frame) }
                    }
                    if (nowMs - state.lastSeenMs <= SOURCE_SILENCE_HOLD_MS) activeSource = true

                    if (nowMs - state.lastSeenMs > SOURCE_EXPIRE_MS && synchronized(state) { state.frames.isEmpty() }) {
                        sourceStates.remove(sourceId, state)
                    }
                }

                if (frames.isEmpty() && !activeSource) {
                    Thread.sleep(PLAYBACK_IDLE_SLEEP_MS)
                    nextTickNs = System.nanoTime() + FRAME_NS
                    continue
                }

                // Keep the AudioTrack clock moving at a fixed 20 ms cadence between voice packets.
                val mixed = if (frames.isEmpty()) SILENCE_FRAME else mixFrames(frames)
                if (frames.isNotEmpty() && pcmRms(mixed) >= VAD_MIN_RMS) musicDucker.speech()
                synchronized(playbackLock) {
                    if ((transmitDesired.get() || playbackOnlyDesired.get()) && !focusPaused.get()) {
                        val track = ensureTrack()
                        if (track != null) {
                            if (frames.isNotEmpty()) playbackActiveUntilMs = nowMs + ECHO_GUARD_AFTER_PLAYBACK_MS
                            if (track.playState != AudioTrack.PLAYSTATE_PLAYING) track.play()
                            var offset = 0
                            while (offset < mixed.size && !focusPaused.get() && (transmitDesired.get() || playbackOnlyDesired.get())) {
                                val written = track.write(mixed, offset, mixed.size-offset, AudioTrack.WRITE_BLOCKING)
                                if (written <= 0) throw IllegalStateException("AudioTrack write failed: $written")
                                offset += written
                                playedBytes.addAndGet(written.toLong())
                            }
                        }
                    }
                }
            } catch (_: InterruptedException) {
                break
            } catch (t: Throwable) {
                playbackErrors.incrementAndGet()
                onStatus("Speaker recovering: ${t.message ?: t.javaClass.simpleName}")
                // A dead AudioTrack must be replaced, not reused on every tick.
                val failed = audioTrack; audioTrack = null
                runCatching { failed?.stop() }; runCatching { failed?.release() }
                Thread.sleep(PLAYBACK_IDLE_SLEEP_MS)
                nextTickNs = System.nanoTime() + FRAME_NS
            }
        }
    }

    private fun pullPlayoutFrame(sourceId: String, state: SourceState, nowMs: Long): ByteArray? {
        while (state.frames.isNotEmpty() && nowMs - state.frames.firstEntry().value.arrivalMs > MAX_FRAME_AGE_MS) {
            state.frames.pollFirstEntry()
            state.primed = false
            state.expectedSequence = null
        }
        while (state.frames.isNotEmpty()) {
            val expected = state.expectedSequence ?: break
            if (state.frames.firstKey() < expected) state.frames.pollFirstEntry() else break
        }

        if (!state.primed) {
            if (state.frames.isEmpty()) return null
            val waited = nowMs - state.frames.firstEntry().value.arrivalMs
            if (state.frames.size < state.targetPrimeFrames && waited < state.targetPrimeFrames * FRAME_MS) return null
            state.expectedSequence = state.frames.firstKey()
            state.primed = true
        }

        var expected = state.expectedSequence ?: return null
        val exact = state.frames.remove(expected)
        if (exact != null) {
            state.expectedSequence = expected + 1
            val pcm = decodeFrame(sourceId, exact.audio) ?: return null
            state.lastGoodFrame = pcm
            state.consecutivePlc = 0
            return pcm
        }

        if (state.frames.isNotEmpty()) {
            val next = state.frames.firstKey()
            val gap = next - expected
            if (gap > 0 && gap <= MAX_PLC_GAP_FRAMES && state.consecutivePlc < MAX_PLC_GAP_FRAMES) {
                state.expectedSequence = expected + 1
                state.consecutivePlc++
                return if (packetDecoder != null && sourceId !in rawPcmSources) decodeFrame(sourceId, null, false) else concealFrame(state.lastGoodFrame, state.consecutivePlc)
            }

            // Large gap or sequence reset: resync immediately to the freshest available packet.
            if (gap > MAX_PLC_GAP_FRAMES || gap < -OLD_PACKET_TOLERANCE) {
                state.expectedSequence = next
                state.consecutivePlc = 0
                expected = next
                val fresh = state.frames.remove(expected)
                if (fresh != null) {
                    state.expectedSequence = expected + 1
                    val pcm = decodeFrame(sourceId, fresh.audio) ?: return null
                    state.lastGoodFrame = pcm
                    return pcm
                }
            }
        }

        // vc79: Nearby can occasionally deliver an otherwise healthy 80 ms payload late.
        // Keep the 20 ms AudioTrack clock continuous for up to 60 ms rather than forcing
        // a full re-prime after the first empty tick. Advancing expectedSequence is
        // intentional: real-time intercom must not replay the late interval afterward.
        if (nowMs - state.lastSeenMs <= LATE_PACKET_GRACE_MS && state.consecutivePlc < 1) {
            state.expectedSequence = expected + 1
            state.consecutivePlc++
            return if (packetDecoder != null && sourceId !in rawPcmSources) decodeFrame(sourceId, null, false) else concealFrame(state.lastGoodFrame, state.consecutivePlc)
        }
        // A starvation must rebuild headroom. Staying primed after an underrun
        // consumes every late packet immediately and perpetuates choppy playback.
        state.primed = false
        state.expectedSequence = null
        state.consecutivePlc = 0
        rebufferCount.incrementAndGet()
        rxUnderruns.incrementAndGet()
        return null
    }

    private fun decodeFrame(sourceId: String, bytes: ByteArray?, fec: Boolean = false): ByteArray? {
        if (sourceId in rawPcmSources) return bytes
        val decoder = packetDecoder ?: return bytes
        return runCatching { decoder(sourceId, bytes, fec) }.getOrNull()
    }

    private fun concealFrame(previous: ByteArray?, lossIndex: Int): ByteArray? {
        previous ?: return null
        val gain = if (lossIndex <= 1) 0.62 else 0.38
        val out = previous.copyOf()
        var i = 0
        while (i + 1 < out.size) {
            val lo = out[i].toInt() and 0xff
            val hi = out[i + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort().toInt()
            val faded = (sample * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            out[i] = (faded and 0xff).toByte()
            out[i + 1] = ((faded shr 8) and 0xff).toByte()
            i += 2
        }
        return out
    }

    // vc56 known-good adaptive playout profile.
    private fun targetPrimeFrames(jitterMs: Double): Int = when {
        jitterMs < 15.0 -> 3
        jitterMs < 28.0 -> 4
        jitterMs < 45.0 -> 5
        else -> 6
    }

    private fun sleepNanos(nanos: Long) {
        if (nanos <= 0L) return
        val millis = nanos / 1_000_000L
        val extraNanos = (nanos % 1_000_000L).toInt()
        Thread.sleep(millis, extraNanos)
    }

    internal fun mixFrames(frames: List<ByteArray>): ByteArray =
        PcmMixer.mix(frames, FRAME_BYTES)

    fun release() {
        playbackOnlyDesired.set(false)
        stopTransmit()
        playbackRunning.set(false)
        playbackThread.interrupt()
        sourceStates.clear()
        if (focusHeld.getAndSet(false)) {
            try { audioManager.abandonAudioFocusRequest(audioFocusRequest) } catch (_: Throwable) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { audioManager.clearCommunicationDevice() } catch (_: Throwable) {}
        } else {
            @Suppress("DEPRECATION")
            try {
                audioManager.stopBluetoothSco()
                audioManager.isBluetoothScoOn = false
                audioManager.isSpeakerphoneOn = false
            } catch (_: Throwable) {}
        }
        audioTrack?.let {
            try { it.stop() } catch (_: Throwable) {}
            it.release()
        }
        audioTrack = null
        try { audioManager.mode = AudioManager.MODE_NORMAL } catch (_: Throwable) {}
    }

    private fun ensureTrack(): AudioTrack? {
        audioTrack?.let { return it }

        return try {
            val min = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT, ENCODING)
            if (min <= 0) return null

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setEncoding(ENCODING)
                        .setChannelMask(CHANNEL_OUT)
                        .build()
                )
                .setBufferSizeInBytes(max(min, FRAME_BYTES * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()

            if (track.state != AudioTrack.STATE_INITIALIZED) {
                track.release()
                null
            } else {
                track.play()
                audioTrack = track
                track
            }
        } catch (t: Throwable) {
            playbackErrors.incrementAndGet()
            onStatus("Speaker unavailable: ${t.message ?: t.javaClass.simpleName}")
            null
        }
    }

    private fun pcmRms(bytes: ByteArray): Double {
        if (bytes.size < 2) return 0.0
        var sum = 0.0
        var samples = 0
        var i = 0
        while (i + 1 < bytes.size) {
            val lo = bytes[i].toInt() and 0xff
            val hi = bytes[i + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort().toInt()
            sum += sample.toDouble() * sample.toDouble()
            samples++
            i += 2
        }
        return if (samples == 0) 0.0 else sqrt(sum / samples)
    }

    private fun createAec(sessionId: Int): AcousticEchoCanceler? = try {
        if (AcousticEchoCanceler.isAvailable()) {
            AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
        } else null
    } catch (_: Throwable) { null }

    private fun createNs(sessionId: Int): NoiseSuppressor? = try {
        if (NoiseSuppressor.isAvailable()) {
            NoiseSuppressor.create(sessionId)?.apply { enabled = true }
        } else null
    } catch (_: Throwable) { null }

    private fun createAgc(sessionId: Int): AutomaticGainControl? = try {
        if (AutomaticGainControl.isAvailable()) {
            AutomaticGainControl.create(sessionId)?.apply { enabled = true }
        } else null
    } catch (_: Throwable) { null }

    private fun effectsLabel(aec: Boolean, ns: Boolean, agc: Boolean): String {
        val enabled = buildList {
            if (aec) add("AEC")
            if (ns) add("NS")
            if (agc) add("AGC")
        }
        return if (enabled.isEmpty()) "software wind filter" else enabled.joinToString("+") + "+WIND"
    }

    private class WindRumbleFilter(sampleRate: Int, cutoffHz: Double) {
        private val alpha: Double
        private var previousInput = 0.0
        private var previousOutput = 0.0

        init {
            val dt = 1.0 / sampleRate.toDouble()
            val rc = 1.0 / (2.0 * PI * cutoffHz)
            alpha = rc / (rc + dt)
        }

        fun process(bytes: ByteArray): ByteArray {
            if (bytes.size < 2) return bytes
            val out = bytes.copyOf()
            var i = 0
            while (i + 1 < bytes.size) {
                val lo = bytes[i].toInt() and 0xff
                val hi = bytes[i + 1].toInt()
                val input = ((hi shl 8) or lo).toShort().toDouble()
                val filtered = alpha * (previousOutput + input - previousInput)
                previousInput = input
                previousOutput = filtered
                val sample = filtered.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                out[i] = (sample and 0xff).toByte()
                out[i + 1] = ((sample shr 8) and 0xff).toByte()
                i += 2
            }
            return out
        }
    }

    private fun AudioDeviceInfo.isHelmetCandidate(): Boolean {
        return when (type) {
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_BLE_HEADSET,
            AudioDeviceInfo.TYPE_HEARING_AID -> true
            else -> false
        }
    }

    private fun AudioDeviceInfo.routeLabel(): String {
        return when {
            isHelmetCandidate() -> productName?.toString()?.takeIf { it.isNotBlank() }
                ?: "Bluetooth helmet/headset"
            type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "phone speaker + microphone"
            else -> productName?.toString()?.takeIf { it.isNotBlank() } ?: "communication device"
        }
    }

    companion object {
        private const val SAMPLE_RATE = 16_000
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
        private const val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
        private const val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
        private const val FRAME_MS = 20
        private const val SAMPLES_PER_FRAME = SAMPLE_RATE * FRAME_MS / 1000
        internal const val FRAME_BYTES = SAMPLES_PER_FRAME * 2

        private const val MIN_PRIME_FRAMES = 3          // vc56: 60 ms initial headroom
        private const val MAX_SOURCE_QUEUE_FRAMES = 12  // vc56 bounded real-time queue
        private const val LATENCY_CATCHUP_MARGIN = 4
        private const val MAX_FRAME_AGE_MS = 260L
        private const val BURST_WINDOW_MS = 5L          // frames closer than this came in one payload
        private const val MAX_BURST_FRAMES = 8
        private const val MAX_PLC_GAP_FRAMES = 2        // vc56: conceal at most 40 ms
        private const val OLD_PACKET_TOLERANCE = 32
        private const val SOURCE_EXPIRE_MS = 2_000L
        private const val SOURCE_SILENCE_HOLD_MS = 320L
        private const val LATE_PACKET_GRACE_MS = 45L    // vc56 known-good grace
        private const val PLAYBACK_IDLE_SLEEP_MS = 3L
        private const val CALL_RESUME_SETTLE_MS = 350L
        private const val ECHO_GUARD_AFTER_PLAYBACK_MS = 100L
        private const val FRAME_NS = FRAME_MS * 1_000_000L
        private val SILENCE_FRAME = ByteArray(FRAME_BYTES)

        private const val VAD_PREROLL_FRAMES = 2
        private const val VAD_HANGOVER_FRAMES = 20 // 400 ms: retain quiet syllables and natural pauses
        private const val VAD_INITIAL_NOISE_FLOOR = 250.0
        private const val VAD_MIN_RMS = 480.0
        private const val VAD_NOISE_MULTIPLIER = 2.05
        private const val VAD_ECHO_MIN_RMS_AEC = 1_800.0
        private const val VAD_ECHO_MIN_RMS_NO_AEC = 3_200.0
        private const val VAD_ECHO_MULTIPLIER_AEC = 2.4
        private const val VAD_ECHO_MULTIPLIER_NO_AEC = 3.4
        private const val WIND_FILTER_CUTOFF_HZ = 110.0
    }
}
