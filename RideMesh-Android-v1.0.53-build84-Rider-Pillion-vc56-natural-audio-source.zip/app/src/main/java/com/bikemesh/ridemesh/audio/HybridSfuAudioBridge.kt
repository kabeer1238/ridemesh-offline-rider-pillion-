package com.bikemesh.ridemesh.audio

import android.media.AudioFormat
import org.webrtc.audio.JavaAudioDeviceModule
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * vc62 diagnostic PCM bridge between the Android Nearby mesh and WebRTC/SFU.
 *
 * Design rules:
 *  - WebRTC remains the only microphone owner on an online bridge phone.
 *  - Offline PCM is mixed directly into the ADM capture buffer; no speaker->mic recapture.
 *  - WebRTC playout PCM and the bridge rider's own microphone are mixed to ONE 16 kHz/20 ms
 *    stream before entering Nearby, so the offline side keeps a single 50 fps bridge clock.
 *  - All queues are bounded. Audio callbacks never block on Nearby or network I/O.
 *
 * This first diagnostic bridge deliberately presents the remote online group as one logical
 * bridge audio source on the offline side. Rider identity still travels in RideMesh presence;
 * individual bridged SFU tracks can be added after the transport is field-proven.
 */
internal class HybridSfuAudioBridge(
    private val isPrimaryBridge: () -> Boolean,
    private val sendToOffline: (ByteArray) -> Unit,
) : AutoCloseable {
    private val closed = AtomicBoolean(false)
    private val localMicEnabled = AtomicBoolean(true)

    private val sourceLock = Any()
    private val offlineSources = ConcurrentHashMap<String, ArrayDeque<ShortArray>>()
    private var injectFrame: ShortArray? = null
    private var injectOffset = 0

    private val localMicLock = Any()
    private val localMicAccumulator = ArrayList<Short>(PCM_20MS_SAMPLES)
    private val remoteLock = Any()
    private val remoteAccumulator = ArrayList<Short>(PCM_20MS_SAMPLES)
    private val micToOffline = ArrayDeque<ShortArray>()
    private val remoteToOffline = ArrayDeque<ShortArray>()

    private val offlineIn = AtomicLong(0)
    private val offlineInjected = AtomicLong(0)
    private val micFrames = AtomicLong(0)
    private val remoteFrames = AtomicLong(0)
    private val localOut = AtomicLong(0)
    private val queueDrops = AtomicLong(0)
    // vc69: count the actual capture callbacks that were hard-zeroed while the user was muted.
    // This is a safety diagnostic: UI mute is not considered successful unless capture PCM is gated.
    private val mutedCaptureCallbacks = AtomicLong(0)
    private val mutedCaptureBytes = AtomicLong(0)

    private val scheduler = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "RideMesh-Hybrid-Bridge").apply { isDaemon = true }
    }

    init {
        scheduler.scheduleAtFixedRate({ bridgeTick() }, 20, 20, TimeUnit.MILLISECONDS)
    }

    fun setLocalMicEnabled(enabled: Boolean) {
        localMicEnabled.set(enabled)
        if (!enabled) synchronized(localMicLock) { localMicAccumulator.clear(); micToOffline.clear() }
    }

    /** One decoded offline rider frame: PCM16 mono, 16 kHz, exactly 20 ms. */
    fun offerOfflinePcm(sourceId: String, pcm: ByteArray) {
        if (closed.get() || !isPrimaryBridge() || pcm.size != PCM_20MS_BYTES) return
        val shorts = bytesToShorts(pcm)
        // Use the same ownership lock as empty-queue removal in the consumer.
        // Otherwise a producer can append to a queue just removed from the map.
        synchronized(sourceLock) {
            if (closed.get()) return
            val q = offlineSources.computeIfAbsent(sourceId.ifBlank { "offline" }) { ArrayDeque() }
            synchronized(q) {
                while (q.size >= MAX_SOURCE_QUEUE) {
                    q.removeFirst()
                    queueDrops.incrementAndGet()
                }
                q.addLast(shorts)
            }
        }
        offlineIn.incrementAndGet()
    }

    /**
     * Called from JavaAudioDeviceModule capture. Silero should observe the buffer BEFORE this
     * method, so VAD continues to describe the bridge rider's real microphone rather than the
     * injected offline group.
     */
    fun processCapture(
        buffer: ByteBuffer,
        audioFormat: Int,
        channels: Int,
        sampleRate: Int,
        bytesRead: Int,
        captureTimeNs: Long,
    ): Long {
        if (closed.get()) return captureTimeNs

        val micEnabled = localMicEnabled.get()

        // vc69 HARD MUTE GATE:
        // In hybrid mode the WebRTC AudioTrack intentionally stays enabled while a PRIMARY bridge
        // is muted so that offline riders can still be injected into the SFU. Therefore disabling
        // the track is not a reliable mute. The capture PCM itself must be zeroed on EVERY device
        // before any bridge decision. This also protects STANDBY/non-primary phones, where the old
        // early return allowed the real microphone to pass through unchanged.
        //
        // Silero observes the microphone before this callback, so this does not affect VAD state;
        // it only guarantees that real microphone samples cannot reach WebRTC while user-muted.
        if (!micEnabled && audioFormat == AudioFormat.ENCODING_PCM_16BIT && bytesRead > 0) {
            val write = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            // The rest of this bridge (and WebRTC's ADM callback contract in this project)
            // addresses capture samples from offset 0, so hard-mute the same exact byte range.
            val safeBytes = minOf(bytesRead, write.capacity())
            var offset = 0
            while (offset + 1 < safeBytes) {
                write.putShort(offset, 0.toShort())
                offset += 2
            }
            if (offset < safeBytes) write.put(offset, 0.toByte())
            mutedCaptureCallbacks.incrementAndGet()
            mutedCaptureBytes.addAndGet(safeBytes.toLong())
        }

        // A non-primary phone has nothing to inject. If muted, its PCM has already been hard-zeroed
        // above; if live, leave the original WebRTC microphone path untouched.
        if (!isPrimaryBridge()) return captureTimeNs

        if (audioFormat != AudioFormat.ENCODING_PCM_16BIT || channels != 1 || bytesRead < 2 || sampleRate <= 0) {
            return captureTimeNs
        }
        val sampleCount = minOf(bytesRead / 2, buffer.capacity() / 2)
        if (sampleCount <= 0) return captureTimeNs

        // Snapshot capture after the hard-mute gate. While muted this is digital silence; while
        // unmuted it is the real microphone. This prevents mic hiss/noise from being mixed back
        // into an offline rider's SFU uplink.
        val original = ShortArray(sampleCount)
        val read = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until sampleCount) original[i] = read.getShort(i * 2)
        if (micEnabled) {
            val mic16 = resample(original, sampleRate, BRIDGE_RATE)
            accumulate20ms(mic16, localMicLock, localMicAccumulator, micToOffline) { micFrames.incrementAndGet() }
        }

        // Mix one synchronized 16 kHz offline frame into successive WebRTC capture callbacks.
        // When the bridge rider is muted, original[] is already zero, so ONLY the offline rider
        // is carried to the SFU.
        val target16Count = ((sampleCount.toLong() * BRIDGE_RATE) / sampleRate).toInt().coerceAtLeast(1)
        val inject16 = nextOfflineChunk(target16Count)
        if (inject16.isNotEmpty()) {
            val injectAtCaptureRate = resample(inject16, BRIDGE_RATE, sampleRate, sampleCount)
            val write = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until minOf(sampleCount, injectAtCaptureRate.size)) {
                val mixed = saturate(original[i].toInt() + (injectAtCaptureRate[i].toInt() * OFFLINE_TO_SFU_GAIN_NUM / OFFLINE_TO_SFU_GAIN_DEN))
                write.putShort(i * 2, mixed.toShort())
            }
        }
        return captureTimeNs
    }

    /** Decoded WebRTC playout. The SDK documents this callback as debug/read-only output PCM. */
    fun onPlaybackSamples(samples: JavaAudioDeviceModule.AudioSamples) {
        if (closed.get() || !isPrimaryBridge()) return
        if (samples.audioFormat != AudioFormat.ENCODING_PCM_16BIT || samples.channelCount != 1 || samples.sampleRate <= 0) return
        val data = samples.data ?: return
        if (data.size < 2) return
        val pcm = bytesToShorts(data)
        val remote16 = resample(pcm, samples.sampleRate, BRIDGE_RATE)
        accumulate20ms(remote16, remoteLock, remoteAccumulator, remoteToOffline) { remoteFrames.incrementAndGet() }
    }

    fun diagnostics(): String {
        val primary = isPrimaryBridge()
        val sourceDepth = offlineSources.values.sumOf { q -> synchronized(q) { q.size } }
        val micDepth = synchronized(localMicLock) { micToOffline.size }
        val remoteDepth = synchronized(remoteLock) { remoteToOffline.size }
        return "Hybrid bridge: ${if (primary) "PRIMARY" else "STANDBY"}" +
            " • offline→SFU ${offlineInjected.get()}/${offlineIn.get()}" +
            " • mic frames ${micFrames.get()}" +
            " • online RX frames ${remoteFrames.get()}" +
            " • forwarded offline ${localOut.get()}" +
            " • queues off=$sourceDepth mic=$micDepth net=$remoteDepth" +
            " • drops ${queueDrops.get()}" +
            " • hardMute cb=${mutedCaptureCallbacks.get()} bytes=${mutedCaptureBytes.get()}"
    }

    private fun bridgeTick() {
        if (closed.get()) return
        if (!isPrimaryBridge()) {
            clearTransient()
            return
        }
        val mic = synchronized(localMicLock) { if (micToOffline.isEmpty()) null else micToOffline.removeFirst() }
        val remote = synchronized(remoteLock) { if (remoteToOffline.isEmpty()) null else remoteToOffline.removeFirst() }
        if (mic == null && remote == null) return
        val mixed = mix20ms(mic, remote)
        try {
            sendToOffline(shortsToBytes(mixed))
            localOut.incrementAndGet()
        } catch (_: Throwable) {
            queueDrops.incrementAndGet()
        }
    }

    private fun nextOfflineChunk(count: Int): ShortArray = synchronized(sourceLock) {
        if (count <= 0) return@synchronized ShortArray(0)
        val out = ShortArray(count)
        var copied = 0
        while (copied < count) {
            if (injectFrame == null || injectOffset >= (injectFrame?.size ?: 0)) {
                injectFrame = mixOneOfflineFrame()
                injectOffset = 0
                if (injectFrame != null) offlineInjected.incrementAndGet()
            }
            val frame = injectFrame ?: break
            val n = minOf(count - copied, frame.size - injectOffset)
            System.arraycopy(frame, injectOffset, out, copied, n)
            copied += n
            injectOffset += n
        }
        if (injectOffset >= (injectFrame?.size ?: 0)) {
            injectFrame = null
            injectOffset = 0
        }
        out
    }

    /** Pop at most one chronological 20 ms frame per offline rider and mix simultaneous talkers. */
    private fun mixOneOfflineFrame(): ShortArray? {
        val frames = ArrayList<ShortArray>()
        synchronized(sourceLock) {
            val stale = ArrayList<String>()
            offlineSources.forEach { (id, q) ->
                val f = synchronized(q) { if (q.isEmpty()) null else q.removeFirst() }
                if (f != null) frames.add(f)
                if (synchronized(q) { q.isEmpty() }) stale.add(id)
            }
            stale.forEach { id -> offlineSources[id]?.let { q -> if (synchronized(q) { q.isEmpty() }) offlineSources.remove(id, q) } }
        }
        if (frames.isEmpty()) return null
        val out = ShortArray(PCM_20MS_SAMPLES)
        for (i in out.indices) {
            var sum = 0
            frames.forEach { frame -> if (i < frame.size) sum += frame[i].toInt() }
            // Small attenuation only when multiple riders overlap to preserve headroom.
            if (frames.size > 1) sum = sum * 3 / (frames.size + 2)
            out[i] = saturate(sum).toShort()
        }
        return out
    }

    private fun accumulate20ms(
        incoming: ShortArray,
        lock: Any,
        accumulator: ArrayList<Short>,
        destination: ArrayDeque<ShortArray>,
        onFrame: () -> Unit,
    ) {
        synchronized(lock) {
            incoming.forEach { accumulator.add(it) }
            while (accumulator.size >= PCM_20MS_SAMPLES) {
                val frame = ShortArray(PCM_20MS_SAMPLES)
                for (i in 0 until PCM_20MS_SAMPLES) frame[i] = accumulator[i]
                // Same samples and frame boundaries; shift the remainder only once.
                accumulator.subList(0, PCM_20MS_SAMPLES).clear()
                while (destination.size >= MAX_OUT_QUEUE) {
                    destination.removeFirst()
                    queueDrops.incrementAndGet()
                }
                destination.addLast(frame)
                onFrame()
            }
        }
    }

    private fun mix20ms(a: ShortArray?, b: ShortArray?): ShortArray {
        val out = ShortArray(PCM_20MS_SAMPLES)
        for (i in out.indices) {
            val av = a?.getOrNull(i)?.toInt() ?: 0
            val bv = b?.getOrNull(i)?.toInt() ?: 0
            out[i] = saturate(av + bv).toShort()
        }
        return out
    }

    private fun clearTransient() {
        synchronized(sourceLock) {
            offlineSources.clear()
            injectFrame = null
            injectOffset = 0
        }
        synchronized(localMicLock) { localMicAccumulator.clear(); micToOffline.clear() }
        synchronized(remoteLock) { remoteAccumulator.clear(); remoteToOffline.clear() }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        clearTransient()
        scheduler.shutdownNow()
    }

    private fun bytesToShorts(bytes: ByteArray): ShortArray {
        val count = bytes.size / 2
        val out = ShortArray(count)
        var p = 0
        for (i in 0 until count) {
            val lo = bytes[p].toInt() and 0xff
            val hi = bytes[p + 1].toInt()
            out[i] = ((hi shl 8) or lo).toShort()
            p += 2
        }
        return out
    }

    private fun shortsToBytes(samples: ShortArray): ByteArray {
        val out = ByteArray(samples.size * 2)
        var p = 0
        samples.forEach { sample ->
            val v = sample.toInt()
            out[p++] = (v and 0xff).toByte()
            out[p++] = ((v shr 8) and 0xff).toByte()
        }
        return out
    }

    private fun resample(input: ShortArray, fromRate: Int, toRate: Int, forcedOutputCount: Int? = null): ShortArray {
        if (input.isEmpty() || fromRate <= 0 || toRate <= 0) return ShortArray(0)
        val outputCount = forcedOutputCount ?: ((input.size.toLong() * toRate) / fromRate).toInt().coerceAtLeast(1)
        if (fromRate == toRate && outputCount == input.size) return input.copyOf()
        val out = ShortArray(outputCount)
        if (outputCount == 1 || input.size == 1) {
            out.fill(input[0])
            return out
        }
        val scale = (input.size - 1).toDouble() / (outputCount - 1).toDouble()
        for (i in out.indices) {
            val position = i * scale
            val left = position.toInt().coerceIn(0, input.lastIndex)
            val right = minOf(left + 1, input.lastIndex)
            val frac = position - left
            val sample = input[left] * (1.0 - frac) + input[right] * frac
            out[i] = sample.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return out
    }

    private fun saturate(value: Int): Int = value.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

    companion object {
        private const val BRIDGE_RATE = 16_000
        private const val PCM_20MS_SAMPLES = 320
        private const val PCM_20MS_BYTES = 640
        private const val MAX_SOURCE_QUEUE = 6
        private const val MAX_OUT_QUEUE = 8
        private const val OFFLINE_TO_SFU_GAIN_NUM = 3
        private const val OFFLINE_TO_SFU_GAIN_DEN = 4
    }
}
