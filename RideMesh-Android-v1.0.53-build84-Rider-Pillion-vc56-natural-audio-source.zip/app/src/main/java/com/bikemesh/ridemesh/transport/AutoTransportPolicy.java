package com.bikemesh.ridemesh.transport;

/** Debounces OS-validated Internet changes using a monotonic clock. No audio ownership here. */
public final class AutoTransportPolicy {
    private boolean online;
    private Boolean candidate;
    private long since;
    public boolean reset(boolean validated, long now) {
        online = validated; candidate = null; since = now; return online;
    }
    public boolean update(boolean validated, long now) {
        if (validated == online) { candidate = null; return online; }
        if (candidate == null || candidate != validated) { candidate = validated; since = now; }
        // vc66: return to Internet after 3 s of stable validation instead of 8 s.
        // A real outage still falls back quickly, while MainActivity separately ignores
        // short OS validation blips when the SFU media path is demonstrably alive.
        if (now - since >= (validated ? 3000L : 1500L)) {
            online = validated; candidate = null;
        }
        return online;
    }
}
