package com.bikemesh.ridemesh.diagnostics

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck

object AppCheckDiagnostics {
    const val TAG = "RideMeshAppCheck"

    fun logAppIdentity(context: Context) {
        try {
            val app = FirebaseApp.getInstance()
            Log.d(TAG, "RideMeshAppCheck: Firebase initialized")
            Log.d(TAG, "RideMeshAppCheck: appId=${app.options.applicationId}")
            Log.d(TAG, "RideMeshAppCheck: projectId=${app.options.projectId}")
            Log.d(TAG, "RideMeshAppCheck: gcmSenderId=${app.options.gcmSenderId}")
            Log.d(TAG, "RideMeshAppCheck: packageName=${context.packageName}")
        } catch (t: Throwable) {
            Log.e(TAG, "RideMeshAppCheck: Failed to read Firebase app identity", t)
        }
    }

    fun forceTokenRequest(forceRefresh: Boolean = true, onResult: (Boolean, String) -> Unit) {
        FirebaseAppCheck.getInstance().getAppCheckToken(forceRefresh)
            .addOnSuccessListener { tokenResult ->
                val token = tokenResult.token
                val segments = token.split('.').size
                Log.d(TAG, "RideMeshAppCheck: TOKEN SUCCESS")
                Log.d(TAG, "tokenLength=${token.length}")
                Log.d(TAG, "jwtSegments=$segments")

                val summary = "APP CHECK SUCCESS\nlength=${token.length} • segments=$segments"
                onResult(true, summary)
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "RideMeshAppCheck: App Check token request FAILED", exception)

                val causes = ArrayList<String>()
                var current: Throwable? = exception
                var level = 0
                var rootClass = exception.javaClass.name
                var rootMsg = exception.message.orEmpty()

                while (current != null) {
                    val className = current.javaClass.name
                    val msg = current.message.orEmpty()
                    rootClass = className
                    rootMsg = msg
                    if (level == 0) {
                        causes.add("ExceptionClass=$className")
                        causes.add("Message=$msg")
                    } else {
                        causes.add("CauseClass[$level]=$className")
                        causes.add("CauseMessage[$level]=$msg")
                    }
                    current = current.cause
                    level++
                }
                causes.add("RootCauseClass=$rootClass")
                causes.add("RootCauseMessage=$rootMsg")

                Log.e(TAG, "RideMeshAppCheck: TOKEN FAILED")
                causes.forEach { Log.e(TAG, "RideMeshAppCheck: $it") }

                val uiSummary = "APP CHECK FAILED\n${exception.javaClass.simpleName}: ${exception.message.orEmpty().ifBlank { "No message" }}\nRoot: $rootClass: $rootMsg"
                onResult(false, uiSummary)
            }
    }
}
