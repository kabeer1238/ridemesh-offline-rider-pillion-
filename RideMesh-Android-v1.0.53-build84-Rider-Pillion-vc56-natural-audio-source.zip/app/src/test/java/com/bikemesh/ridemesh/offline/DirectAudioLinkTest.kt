package com.bikemesh.ridemesh.offline

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DirectAudioLinkTest {
    private fun pcm(seed: Int) = ByteArray(640) { (seed + it).toByte() }

    @Test fun pcmBatchRoundTrips() {
        val frames = List(4) { pcm(it) }
        val decoded = DirectAudioBatch.decode(DirectAudioBatch.encode(7, DirectAudioBatch.CODEC_PCM16, frames))
        assertNotNull(decoded)
        assertEquals(7, decoded!!.generation)
        assertEquals(DirectAudioBatch.CODEC_PCM16, decoded.codec)
        assertEquals(4, decoded.frames.size)
        frames.indices.forEach { assertArrayEquals(frames[it], decoded.frames[it]) }
    }

    @Test fun opusBatchKeepsVariableFrameSizes() {
        val frames = listOf(ByteArray(40) { 1 }, ByteArray(63) { 2 }, ByteArray(9) { 3 })
        val bytes = DirectAudioBatch.encode(2, DirectAudioBatch.CODEC_OPUS, frames)
        assertEquals(10 + frames.sumOf { 2 + it.size }, bytes.size)
        val decoded = DirectAudioBatch.decode(bytes)!!
        assertEquals(listOf(40, 63, 9), decoded.frames.map { it.size })
    }

    @Test fun batchIsMuchSmallerWithOpus() {
        val pcmBytes = DirectAudioBatch.encode(1, DirectAudioBatch.CODEC_PCM16, List(4) { pcm(it) }).size
        val opusBytes = DirectAudioBatch.encode(1, DirectAudioBatch.CODEC_OPUS, List(4) { ByteArray(67) }).size
        assertTrue(opusBytes * 4 < pcmBytes)
    }

    @Test fun malformedBatchesAreRejected() {
        val good = DirectAudioBatch.encode(1, DirectAudioBatch.CODEC_PCM16, listOf(pcm(0)))
        assertNull(DirectAudioBatch.decode(good.copyOf(good.size - 1)))           // truncated
        assertNull(DirectAudioBatch.decode(good + byteArrayOf(0)))                 // trailing bytes
        assertNull(DirectAudioBatch.decode(good.copyOf().also { it[0] = 0 }))     // wrong magic
        assertNull(DirectAudioBatch.decode(good.copyOf().also { it[8] = 9 }))     // unknown codec
        assertNull(DirectAudioBatch.decode(good.copyOf().also { it[9] = 0 }))     // zero frames
        assertNull(DirectAudioBatch.decode(ByteArray(3)))
    }

    @Test fun batcherEmitsConsecutiveFrames() {
        val batcher = DirectFrameBatcher(framesPerBatch = 4, maxFrameGapMs = 60)
        for (i in 1..3) assertNull(batcher.offer(i, i * 20L, DirectAudioBatch.CODEC_PCM16, pcm(i)))
        val batch = batcher.offer(4, 80L, DirectAudioBatch.CODEC_PCM16, pcm(4))!!
        assertEquals(1, batch.firstSequence)
        assertEquals(20L, batch.firstCaptureMs)
        assertEquals(4, batch.frames.size)
        assertArrayEquals(pcm(1), batch.frames[0])
        assertEquals(0L, batcher.discardedFrames)
    }

    @Test fun batcherDiscardsStalePartialBatchAfterMute() {
        val batcher = DirectFrameBatcher(framesPerBatch = 4, maxFrameGapMs = 60)
        batcher.offer(1, 0L, DirectAudioBatch.CODEC_PCM16, pcm(1))
        batcher.offer(2, 20L, DirectAudioBatch.CODEC_PCM16, pcm(2))
        // 5 s of mute, then speech resumes: the two old frames must not be sent with new speech.
        for (i in 3..5) assertNull(batcher.offer(i, 5_000L + i * 20L, DirectAudioBatch.CODEC_PCM16, pcm(i)))
        assertEquals(2L, batcher.discardedFrames)
        val batch = batcher.offer(6, 5_120L, DirectAudioBatch.CODEC_PCM16, pcm(6))!!
        assertEquals(3, batch.firstSequence)
    }

    @Test fun batcherNeverMixesCodecs() {
        val batcher = DirectFrameBatcher(framesPerBatch = 2, maxFrameGapMs = 60)
        batcher.offer(1, 0L, DirectAudioBatch.CODEC_PCM16, pcm(1))
        assertNull(batcher.offer(2, 20L, DirectAudioBatch.CODEC_OPUS, ByteArray(50)))
        val batch = batcher.offer(3, 40L, DirectAudioBatch.CODEC_OPUS, ByteArray(50))!!
        assertEquals(DirectAudioBatch.CODEC_OPUS, batch.codec)
        assertEquals(2, batch.firstSequence)
        assertEquals(1L, batcher.discardedFrames)
    }

    @Test fun gateDropsInsteadOfQueueing() {
        val gate = InFlightGate(maxInFlight = 3, timeoutMs = 2_000)
        for (id in 1L..3L) {
            assertTrue(gate.hasRoom(0))
            gate.add(id, 0)
        }
        assertFalse("fourth payload must be dropped, not queued", gate.hasRoom(10))
        assertTrue(gate.remove(1L))
        assertFalse(gate.remove(1L))
        assertFalse(gate.remove(99L))
        assertTrue(gate.hasRoom(20))
        assertEquals(3, gate.maxObserved)
    }

    @Test fun gateForgetsLostTransferUpdates() {
        val gate = InFlightGate(maxInFlight = 2, timeoutMs = 2_000)
        gate.add(1L, 0)
        gate.add(2L, 100)
        assertFalse(gate.hasRoom(1_000))
        assertTrue(gate.hasRoom(2_050)) // payload 1 expired
        assertEquals(1L, gate.timedOut)
        assertEquals(1, gate.size())
    }

    @Test fun autoPolicyUsesPcmOnlyOnHighBandwidth() {
        val auto = DirectCodecPolicy.Mode.AUTO
        assertEquals(DirectAudioBatch.CODEC_PCM16, DirectCodecPolicy.codecFor(auto, DirectCodecPolicy.QUALITY_HIGH))
        assertEquals(DirectAudioBatch.CODEC_OPUS, DirectCodecPolicy.codecFor(auto, DirectCodecPolicy.QUALITY_MEDIUM))
        assertEquals(DirectAudioBatch.CODEC_OPUS, DirectCodecPolicy.codecFor(auto, DirectCodecPolicy.QUALITY_LOW))
        assertEquals(DirectAudioBatch.CODEC_OPUS, DirectCodecPolicy.codecFor(auto, DirectCodecPolicy.QUALITY_UNKNOWN))
        assertEquals(DirectAudioBatch.CODEC_PCM16,
            DirectCodecPolicy.codecFor(DirectCodecPolicy.Mode.FORCE_PCM, DirectCodecPolicy.QUALITY_LOW))
    }
}
