package com.bikemesh.ridemesh.audio

import org.junit.Assert.assertArrayEquals
import org.junit.Test

/** Pure queue/chunk tests: no microphone or network is opened. */
class HybridBridgeContinuityTest {
    private fun bridge(): HybridSfuAudioBridge = HybridSfuAudioBridge({ true }, {})

    private fun offer(bridge: HybridSfuAudioBridge, value: Int) {
        val bytes = ByteArray(640)
        for (i in 0 until 320) {
            bytes[i * 2] = value.toByte()
            bytes[i * 2 + 1] = (value shr 8).toByte()
        }
        bridge.offerOfflinePcm("rider", bytes)
    }

    private fun read(bridge: HybridSfuAudioBridge, count: Int): ShortArray {
        val method = HybridSfuAudioBridge::class.java.getDeclaredMethod("nextOfflineChunk", Int::class.javaPrimitiveType)
        method.isAccessible = true
        return method.invoke(bridge, count) as ShortArray
    }

    @Test fun normalTenMillisecondChunksRetainOriginalSamples() {
        val bridge = bridge()
        try {
            offer(bridge, 100)
            assertArrayEquals(ShortArray(160) { 100 }, read(bridge, 160))
            assertArrayEquals(ShortArray(160) { 100 }, read(bridge, 160))
            assertArrayEquals(ShortArray(160), read(bridge, 160))
        } finally { bridge.close() }
    }

    @Test fun crossingFrameBoundaryDoesNotInsertSilence() {
        val bridge = bridge()
        try {
            offer(bridge, 100)
            offer(bridge, 200)
            read(bridge, 160)
            assertArrayEquals(ShortArray(480) { if (it < 160) 100 else 200 }, read(bridge, 480))
        } finally { bridge.close() }
    }

    @Test fun originalSixFrameCapacityIsPreserved() {
        val bridge = bridge()
        try {
            for (value in 1..7) offer(bridge, value)
            for (value in 2..7) assertArrayEquals(ShortArray(320) { value.toShort() }, read(bridge, 320))
            assertArrayEquals(ShortArray(320), read(bridge, 320))
        } finally { bridge.close() }
    }
}
