# RideMesh Production Release ProGuard / R8 Optimization & Obfuscation Rules

# General attributes to preserve for reflection, annotations, and stack traces
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable

# WebRTC JNI & Native Classes
-keep class org.webrtc.** { *; }
-keepclassmembers class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# ONNX Runtime & Silero VAD (JNI + Native C++ bindings)
-keep class ai.onnxruntime.** { *; }
-keepclassmembers class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**
-keep class com.github.gkonovalov.vad.** { *; }
-keepclassmembers class com.github.gkonovalov.vad.** { *; }

# Concentus Opus Audio Codec
-keep class org.concentus.** { *; }
-keepclassmembers class org.concentus.** { *; }

# Google Play Billing API

# Firebase, App Check, Play Integrity & Cloud Functions
-keep class com.google.firebase.** { *; }
-keepclassmembers class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class com.google.android.play.core.** { *; }
-keepclassmembers class com.google.android.play.core.** { *; }

# Google Play Services (Nearby, Maps, Location, Code Scanner)
-keep class com.google.android.gms.nearby.** { *; }
-keepclassmembers class com.google.android.gms.nearby.** { *; }
-keep class com.google.android.gms.maps.** { *; }
-keepclassmembers class com.google.android.gms.maps.** { *; }
-keep class com.google.android.gms.location.** { *; }
-keepclassmembers class com.google.android.gms.location.** { *; }
-keep class com.google.android.gms.code.scanner.** { *; }
-keep class com.google.zxing.** { *; }

# RideMesh Data Envelopes, Models & JNI / Reflection / Serializables
-keep class com.bikemesh.ridemesh.offline.RideMeshEnvelope { *; }
-keep class com.bikemesh.ridemesh.offline.RealtimeVoicePacket { *; }
-keepclassmembers class com.bikemesh.ridemesh.** {
    @android.webkit.JavascriptInterface <methods>;
    native <methods>;
}
