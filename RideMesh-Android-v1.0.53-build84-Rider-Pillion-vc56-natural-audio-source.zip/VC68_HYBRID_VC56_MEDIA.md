# RideMesh vc68 / build 69 — Hybrid vc56 media repair

Version: `1.0.38-vc68-hybrid-vc56-media`  
Build: `69`

## Why build 68 did not sound like vc56 during offline↔online use

Build 68 restored the vc56 direct Nearby profile only while AUTO was fully offline. After SFU media became live, AUTO deliberately migrated Nearby back to the older hybrid `P2P_CLUSTER` path. That hybrid media path still differed materially from vc56:

- one Opus frame per Nearby payload instead of four 20 ms frames per payload;
- Opus forced on the hybrid local leg instead of the vc56 AUTO codec rule (RAW PCM16 on HIGH, Opus otherwise);
- hybrid packets were decoded in the Nearby arrival callback before AudioEngine's reorder/jitter/PLC stage;
- the relay transport therefore saw ~50 audio payloads/s per speaker rather than vc56's nominal 12.5 batched payloads/s.

So Build 68 could reproduce vc56 behavior in sustained two-phone offline mode, but it did **not** reproduce vc56 media behavior once the phone became an Internet/SFU bridge.

## vc68 changes

### 1. vc56 four-frame media batches now continue in HYBRID_CLUSTER

Hybrid `P2P_CLUSTER` capture now uses the same media packet format as the known-good direct path:

- 16 kHz mono, 20 ms source frames;
- four frames per RMD2 payload (~80 ms);
- RAW PCM16 when Nearby reports HIGH bandwidth;
- Opus fallback otherwise (current vc57-derived 32 kbit/s/FEC codec settings are retained);
- first-frame sequence and capture timestamp are preserved through the relay envelope.

The hybrid router still owns TTL, deduplication and multi-hop forwarding. Only the media packetization was changed.

### 2. Decode happens after the vc56 jitter buffer, not before it

Build 68 hybrid handling called `decodeForPlayout()` immediately from the Nearby receive callback and then inserted raw PCM into AudioEngine. That meant Opus decoding happened in packet-arrival order and the jitter buffer could no longer perform codec-aware PLC on a missing frame.

Build 69 sends the codec-tagged 20 ms frames into AudioEngine first. AudioEngine performs its existing vc56 burst-aware reorder/prime/catch-up/PLC logic and decodes in sequence order. A new read-only `orderedPcmObserver` forwards the resulting ordered PCM to the SFU bridge.

This observer does not alter the local mixer or capture path; it only sees the PCM frame that AudioEngine was already about to play.

### 3. Hybrid transport payload rate is reduced

At continuous speech the local hybrid leg now targets roughly 12.5 batched Nearby payloads/s instead of about 50 one-frame payloads/s. This is the same batching principle that fixed the large queue/delay problem before vc56.

## Preserved

- vc66/build67 fast Internet return and short retry timers.
- vc67/build68 make-before-break handover profile logic.
- Cloudflare SFU/TURN engine.
- bridge election and P2P_CLUSTER/NON_DISRUPTIVE hybrid topology.
- current `HybridSfuAudioBridge` PCM injection/resampling/mixing implementation.
- direct `VC56_DIRECT` profile and known-good two-device audio path.
- Android call priority, mute, route and music-duck policies.

## Important limitation

This is the closest repair possible without changing the Internet bridge architecture itself. Offline audio that crosses the SFU boundary is still decoded to PCM on the bridge phone and injected into WebRTC, so it can be resampled and WebRTC-encoded again. That is not bit-identical to vc56 direct PCM.

The final architecture for preserving the original RideMesh encoded packet across the Internet boundary is an SFU/DataChannel packet bridge. Build 69 deliberately does not make that larger architectural change yet.

## Verification performed here

- Source archive comparison against the actual vc56 and vc57 sources.
- Confirmed vc56 and vc57 `AudioEngine.kt` are byte-identical.
- Confirmed the Build 68 hybrid branch was still per-frame Opus and pre-jitter decode.
- Pure-Kotlin compilation of `RideMeshEnvelope.kt`, `DirectAudioLink.kt` and the modified `MeshRelayRouter.kt`: PASS.
- Hybrid batch smoke test: PASS; a four-frame RMD2 packet preserved first-frame sequence, capture timestamp and generation through the relay envelope.
- Source brace/parenthesis gross-balance checks: PASS.
- Full Android Gradle compile was attempted but did not start because this environment cannot resolve `services.gradle.org` to download Gradle 8.13. Therefore this package is **not claimed Android-compiled or device-tested**.

## First field test

Use the same two/three phones and fresh ride code.

1. Start AUTO + FORCE SFU and confirm online voice.
2. Keep one rider on the local Nearby side and one on the online/SFU side.
3. Speak continuously for 30 seconds in each direction.
4. Capture engineering logs from the bridge phone and offline phone.
5. In HYBRID mode, look for `VC68 HYBRID MEDIA` and `HYBRID CODEC`.
6. Compare `Audio TX frames`, `RX frames`, bundle rate, congestion drops, receive-buffer target prime/jitter/underruns, and the Hybrid bridge counters.
7. Then remove Internet completely and verify `VC56_DIRECT` still retains the known-good direct sound.

If the local hybrid leg is now clean but the Internet-crossing voice still sounds materially worse than vc56, the next change should be the packet-preserving SFU DataChannel bridge rather than more AudioEngine tuning.
