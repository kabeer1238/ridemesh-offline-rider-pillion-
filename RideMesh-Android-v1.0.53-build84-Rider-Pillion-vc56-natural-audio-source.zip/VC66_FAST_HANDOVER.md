# RideMesh vc66 / build 67 — fast offline↔Internet handover

Version: 1.0.36-vc66-fast-handover

This is a narrow handover/recovery change based on vc65/build66. It deliberately does not retune AudioEngine, the vc56-derived offline codec/jitter path, Opus settings, SFU bridge mixing gains, or Nearby packet batching.

## Why vc65 can feel slow

AUTO used a 2 s Internet-loss debounce but an 8 s Internet-return debounce. When Android briefly removed NET_CAPABILITY_VALIDATED, RideMesh could tear down online audio quickly, then require 8 seconds of stable validation before even starting the online engine again. Offline→Internet also released the offline capture path before TURN/SFU startup, and a microphone-release failure could wait 10 s before retrying; a start exception waited 30 s.

## vc66 changes

1. Internet return debounce: 8 s -> 3 s. Real outage fallback: 2 s -> 1.5 s.
2. A short Android VALIDATED blip no longer forces online→offline while the Cloudflare SFU media path is still connected.
3. TURN credentials are prefetched in the background while offline AudioEngine still owns the microphone. This prefetch does not create WebRTC, request audio focus, or change the audio route.
4. On offline→Internet handover, AudioEngine enters playback-only before transmit capture is stopped. Nearby incoming speech therefore stays alive while microphone ownership changes.
5. If Internet validation disappears during the handover, the online start is cancelled and offline voice is immediately restored.
6. Microphone-release retry reduced 10 s -> 2.5 s. General handover-start recovery reduced 30 s -> 5 s.

## Audio non-regression

No changes were made to AudioEngine.kt, OfflineMeshController.kt, NearbyClusterTransport.kt, OpusVoiceCodec.kt, CloudflareSfuEngine.kt or HybridSfuAudioBridge.kt. The vc65 conservative bridge/audio changes are preserved byte-for-byte.

## Test sequence

Use two or three Android phones on the same ride. Start ONLINE/AUTO with SFU connected, then remove Internet from one phone long enough to force offline. Verify nearby voice continues. Restore mobile data/Wi-Fi and time from Android network validation to SFU CONNECTED. Expected policy delay is about 3 s instead of 8 s, plus actual signaling/SFU setup. During offline→Internet transition, nearby received audio should continue because playback-only is retained. Repeat 10 times, including a quick 1–2 s Wi-Fi/cell validation blip; if SFU remains connected that blip should no longer cause a full transport teardown.

Build verification in this environment is limited by the unavailable Android SDK/Gradle distribution. Source integrity and targeted Java policy behavior are checked separately; compile and device validation are still required.
