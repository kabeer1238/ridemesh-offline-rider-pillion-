# RideMesh Android vc75 — Natural Intercom VAD

Version 1.0.44 • Build 75

- Builds on vc74 adaptive P2P/SFU + SFU stability work.
- Keeps the 160 ms acoustic-onset protection and 2-frame speech confirmation.
- Extends confirmed-speech hold from 400 ms to 1200 ms so normal conversational pauses do not sound like the microphone powers off.
- Replaces hard PCM zeroing during VAD-closed state with a smooth local-mic attenuation floor (3%).
- Opening is immediate to protect leading consonants; closing gain releases gradually.
- VAD acts only on this Android phone's local microphone PCM before HybridSfuAudioBridge injection. Offline riders forwarded through a primary bridge are not VAD-gated.
- Manual mute/private-call hard mute remains separate and must still produce true digital silence.
- SFU/TURN, vc56-derived offline media, bridge routing, billing/Firebase entitlement, and packet-age diagnostics are preserved.

Verification status: source/static checks only here; not Gradle-compiled or device-tested in this environment.
