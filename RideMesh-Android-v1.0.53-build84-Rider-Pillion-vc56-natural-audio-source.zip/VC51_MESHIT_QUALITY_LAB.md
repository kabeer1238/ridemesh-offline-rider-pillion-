# RideMesh Android vc51 — MeshIt Quality Lab

Built from user-supplied vc50 source for controlled Android-to-Android offline voice comparison.

Changes are intentionally limited to offline audio quality:
- Continuous 20 ms microphone packet cadence during an active unmuted offline session. Voice Detection is observation-only, matching the validated iOS principle; it no longer gates offline transport.
- Clean-link jitter-buffer prime reduced from 60 ms to 40 ms; adaptive expansion remains for unstable links.
- Opus in-band FEC is now actually consumed when the next packet is available for a one-frame loss; PLC remains fallback.
- Existing 16 kHz mono, 20 ms, 32 kbps constrained VBR Opus, AEC/NS/AGC, low-latency AudioTrack, Nearby P2P_CLUSTER and mesh envelope are preserved.
- Online WebRTC path is untouched.

Test first with exactly two Android phones, one hop, same room. Compare latency, onset clipping, choppiness, rebuffer count and audio drops against vc50 and MeshIt.
