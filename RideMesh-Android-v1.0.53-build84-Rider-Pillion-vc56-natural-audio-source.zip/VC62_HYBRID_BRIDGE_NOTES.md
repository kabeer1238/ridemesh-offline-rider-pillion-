# RideMesh vc62 Hybrid SFU / Mesh Bridge

Build target: `1.0.32-vc62-hybrid-sfu-mesh-bridge` • versionCode 63

## Included

- AUTO mode with validated Internet runs Cloudflare SFU and Nearby P2P_CLUSTER together.
- AUTO mode without validated Internet remains on the Nearby offline mesh.
- Nearby mesh remains alive during online AUTO operation for offline riders and bridge failover.
- Internet-capable nearby riders advertise bridge candidacy only after SFU media is connected.
- Deterministic PRIMARY / BACKUP bridge election is handled by the local mesh.
- PRIMARY bridge injects decoded offline 16 kHz PCM directly into the WebRTC capture buffer.
- PRIMARY bridge taps decoded WebRTC playout and forwards it to the offline mesh.
- No speaker-to-microphone recapture is used for bridging.
- The real local microphone is kept separate from injected offline audio for downlink loop prevention.
- WebRTC remains the only microphone owner on an Internet-capable hybrid phone.
- AudioEngine is playback-only on online hybrid phones; offline-only phones continue to use AudioEngine capture.
- SFU subscription de-duplication and serialized publish/pull/renegotiate logic from vc61.1 are preserved.
- Voice Detection defaults ON for first launch and keeps the user's stored manual choice afterwards.
- Battery Smart and Voice Detection use the same compact right-side switch design in Settings.
- Existing setup-page Battery Smart SwitchMaterial now uses matching cyan-ON / dark-OFF state colors.

## AUTO six-rider target

Example: A/B/C offline nearby, D/E nearby with Internet, F far away with Internet.

- A/B/C use Nearby mesh.
- D/E join Cloudflare SFU and remain on Nearby for bridge election.
- One of D/E becomes PRIMARY; the other remains BACKUP.
- A/B/C audio is injected by PRIMARY into SFU for D/E/F.
- Remote SFU playout is converted to 16 kHz / 20 ms PCM and sent by PRIMARY to A/B/C.
- If PRIMARY loses Internet, its candidacy disappears and the remaining Internet-capable nearby rider becomes PRIMARY after the local lease converges.

## Verification status

Source integration and static checks are complete in this workspace. Full Gradle compilation cannot run here because the Gradle wrapper needs `https://services.gradle.org/distributions/gradle-8.13-bin.zip` and this environment cannot resolve that host. Build in Android Studio or CI before calling the APK tested.
