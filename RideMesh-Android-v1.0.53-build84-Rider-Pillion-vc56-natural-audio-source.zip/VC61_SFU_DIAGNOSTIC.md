# RideMesh vc61 — Cloudflare SFU Diagnostic

vc61 keeps the proven vc60 P2P/TURN engine intact and adds a manual `FORCE SFU` engineering mode.

## Online test modes

- `AUTO` — vc60 P2P WebRTC; direct ICE preferred, Cloudflare TURN fallback.
- `FORCE TURN` — vc60 P2P WebRTC with relay-only ICE.
- `FORCE SFU` — one Cloudflare Realtime SFU PeerConnection per rider; microphone publishes once and remote rider tracks are pulled into that session.

Change mode in **Settings → Online voice engineering**, then leave/rejoin the ride.

## Backend deployment required

Replace the current `ridemesh-sfu-backend` Worker code with `cloudflare/ridemesh-sfu-backend-worker.js` and deploy it. Keep Worker secrets named exactly:

- `SFU_APP_ID`
- `SFU_API_TOKEN`

Endpoints used by vc61:

- `POST /session`
- `POST /publish`
- `POST /pull`
- `PUT /renegotiate`

The Cloudflare API token is never embedded in the APK.

## First field test

1. Deploy the updated Worker.
2. Install vc61 on both Android phones.
3. On both phones select `FORCE SFU`, leave/rejoin the same Ride code.
4. Open Ride Status and copy **MAXIMUM DIAGNOSTIC LOG** after 30–60 seconds.
5. Expected: SFU session ID populated, local track populated, `PC CONNECTED`, at least one remote track, packets TX/RX increasing, two-way audio.

Do not enable automatic 3+ rider switching yet. This build is intentionally manual so SFU can be compared directly against vc60 AUTO/FORCE TURN.
