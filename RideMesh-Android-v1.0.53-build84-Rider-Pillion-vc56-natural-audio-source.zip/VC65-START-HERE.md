# RideMesh vc65 / build 66 — conservative vc63 audio candidate

Version: 1.0.35-vc65-conservative-audio

This starts from vc63/build64, which the user reported sounded better than vc64/build65. It does not extend the regressed vc64 patch. Audible improvement is a goal, not a verified result.

## Preserved from vc63

- Nearby lifecycle, hybrid P2P_CLUSTER and NON_DISRUPTIVE connection settings.
- SFU SDP sequencing, subscriptions, election and handover behavior.
- Six-frame offline-source bridge queue and eight-frame outgoing bridge queues.
- Original 20 ms fixed-rate bridge sender, resampler, mixing gains and codec.
- AudioEngine playback/jitter buffer and existing mute/call handling.
- No new PCM age expiry, catch-up suppression or shortened queue capacity.

## Three targeted audio changes

1. The producer and consumer now use the same source ownership lock. An empty rider queue cannot be removed between producer lookup and append, which previously could orphan a speech frame.
2. Capture injection can span queued frame boundaries without inserting a silent remainder. Normal 10 ms capture chunks keep the same sample order and values.
3. PCM accumulation removes a completed frame in one operation instead of shifting the array 320 times. Frame contents and timing thresholds are unchanged.

Only app/build.gradle.kts, audio/HybridSfuAudioBridge.kt and the new audio/HybridBridgeContinuityTest.kt differ under app/ from vc63. Tests cover ordinary 10 ms chunks, a frame-boundary crossing and preservation of the six-frame capacity. No aggressive tuning from vc64 is retained.

## Verification

Source diff reviewed; archive integrity checked. The Gradle command requesting compileDebugKotlin, testDebugUnitTest and assembleDebug exited 1 before any task ran: fetching gradle-8.13-bin.zip failed with java.net.SocketException: Network is unreachable. Tests are supplied but NOT executed. No APK was produced. No compiler-warning assessment is possible before compilation.

COMPILED: no. UNIT TESTED: no. DEVICE TESTED: no. FIELD TESTED: no.

Build in a separate extracted folder on your Android Studio machine:

```powershell
.\gradlew.bat :app:compileDebugKotlin
.\gradlew.bat :app:testDebugUnitTest
.\gradlew.bat :app:assembleDebug
```

Expected output after a successful build:
app/build/outputs/apk/debug/RideMesh-android-v1.0.35-vc65-build66-debug.apk

If integrating with your repository, use offline-mesh-v1 only. Do not change production-vc25-billing8.

## Compare with vc63

Install the same build66 APK on both devices; check Settings. Keep Pad online and Poco offline with Wi-Fi radio/Bluetooth on. Use AUTO/NORMAL and the same fresh ride code. Speak alternately for 30 seconds, then together. Compare chopped words and audible delay with vc63 under the same conditions. Capture both reports before ending the ride. Also test mute and call interruption. If voice is worse, stop using this candidate and retain vc63 as the baseline; do not uninstall without preserving needed app data/signing compatibility.

These narrow fixes may not materially change seconds-long stalls. The earlier 80–120 ms expiry was a suspected regression cause, not established by a controlled test. Remaining causes include transport scheduling, radio throughput, playback and the inherited PCM bridge. Existing vc63 diagnostic labels/counters remain partly legacy; this deliberately minimal candidate does not claim to solve that or establish full multi-rider bridging. Historic VC63 files in this archive describe the baseline, not validation of build66.
