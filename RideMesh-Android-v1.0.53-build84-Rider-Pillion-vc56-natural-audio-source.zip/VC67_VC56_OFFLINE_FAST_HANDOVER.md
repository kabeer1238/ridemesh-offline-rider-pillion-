# RideMesh vc67 / build 68 — vc56 offline audio profile + fast handover

Version: `1.0.37-vc67-vc56-offline-fast-handover`  
Build: `68`

## Goal

Keep vc66's faster offline↔Internet handover and current Cloudflare SFU/TURN/hybrid code, while restoring the **confirmed-good vc56/vc57 direct Nearby audio profile whenever AUTO is actually offline**.

## Why this build

The current hybrid controller already contains the vc56 direct audio implementation, but vc65/vc66 AUTO always started Nearby with `hybridMode=true`. That selected:

- `P2P_CLUSTER`
- `NON_DISRUPTIVE`
- per-frame Opus through the relay/router path

The confirmed-good vc56 two-rider path instead used:

- `P2P_POINT_TO_POINT`
- `DISRUPTIVE`
- 20 ms capture frames
- four frames per Nearby payload (80 ms)
- RAW PCM16 whenever Nearby reports HIGH bandwidth
- Opus fallback otherwise
- three direct payloads maximum in flight
- drop-not-queue backpressure
- the existing burst-aware jitter/playout clock

vc57 preserved that path and changed only the Opus fallback to 32 kbit/s with in-band FEC; the current source already carries those vc57 Opus settings.

## vc67 behavior

### Sustained offline

AUTO + no Internet now selects `VC56_DIRECT`:

`P2P_POINT_TO_POINT • DISRUPTIVE • direct batched audio`

This executes the existing `OfflineMeshController.encodeAndSend()` direct branch rather than the hybrid relay/router audio branch.

### Internet returns

The working direct Nearby link is **not** torn down just because Android reports validated Internet. vc66 TURN prefetch remains active. WebRTC/SFU is started while Nearby stays on the vc56 direct profile. Only after `isSfuConnectedForBridge()` confirms the SFU media path does the watchdog migrate Nearby to:

`P2P_CLUSTER • NON_DISRUPTIVE • HYBRID`

This is intentionally break-after-make for the *Nearby profile*, not for the Internet voice path: the online media path must be alive before Nearby is restarted for bridge duties.

### Internet disappears

The already-connected hybrid Nearby link remains available for immediate fallback audio. After a 1.5 s promotion guard, a sustained outage restarts Nearby into the vc56 direct profile. This avoids changing Nearby strategy for a short network flap while still reaching the known-good direct audio mode during a real outage.

## Protected code

vc67 does **not** retune the audio engine, codec, SFU engine, bridge mixer, or Nearby packet implementation. The functional app changes from vc66 are limited to `MainActivity.kt` profile selection/state plus version metadata.

Important source facts checked before packaging:

- vc56 `AudioEngine.kt` and vc57 `AudioEngine.kt` are byte-identical.
- current `OpusVoiceCodec.kt` is byte-identical to vc57 (32 kbit/s + FEC fallback).
- current direct `decodeForPlayout()` is byte-identical to vc56/vc57.
- current direct `encodeAndSend()` matches vc57; its only historical difference from vc56 is `connectedPeerCount() < 1` instead of `!= 1`, which is equivalent for NORMAL one-peer mode and enables the old STAR lab path.
- when `hybridMode=false`, current Nearby still resolves to `P2P_POINT_TO_POINT`, `DISRUPTIVE`, and `DIRECT_MAX_IN_FLIGHT = 3`.

## What this does NOT claim

This source has not been Android-compiled or device-tested in this environment. No APK is included. The expected offline sound is based on selecting the same direct path that produced the known-good vc56/vc57 field result; real-device confirmation is still required.

The vc56 direct profile is a **one-peer quality baseline**. Full multi-rider offline mesh still uses the hybrid/cluster architecture and needs separate field validation. Do not interpret this lab build as proof that 3+ rider offline audio now matches vc56.

## First field test

Use two Android phones with the same fresh ride code and AUTO mode.

1. Start with Internet available and wait for SFU voice.
2. Turn Internet off on both phones.
3. Confirm fallback voice works immediately, then after a few seconds confirm diagnostics show `Local mesh profile: VC56_DIRECT` and Nearby reports `P2P_POINT_TO_POINT • DISRUPTIVE`.
4. Speak continuously for 30–60 seconds and compare directly with vc56/vc57.
5. Turn Internet back on while continuing to talk.
6. The direct Nearby link should remain while SFU reconnects. After SFU is connected, diagnostics should change to `Local mesh profile: HYBRID_CLUSTER`.
7. Capture the engineering log from both phones, especially codec, bandwidth, TX/RX rate, congestion drops, SFU connect time, and handover messages.

Expected APK after a successful local Android Studio debug build:

`app/build/outputs/apk/debug/RideMesh-android-v1.0.37-vc67-build68-debug.apk`
