# RideMesh Android vc44 — iOS parity user build

Based on Android vc43 WebRTC PCM Silero Observer source.

Parity work preserved/confirmed from vc43:
- Production WebRTC/Opus voice path remains unchanged by Voice Detection.
- Read-only online speech observer can be toggled live.
- Private/system call interruption pauses RideMesh capture/TX and auto-resumes.
- Smart music ducking uses local/remote voice activity, 600 ms music-start calibration, 900 ms hold, and respects manual volume changes.
- Audio/network recovery callbacks and Bluetooth communication routing remain intact.

vc44 user-facing changes:
- Customer label is Voice Detection; technical Silero/WebRTC/VAD wording removed from normal Settings.
- Online Voice Detection remains live-toggleable without rebuilding the voice session.
- Join Ride loads the last successfully started ride code, or blank on first use. Create Ride alone generates a new code.
- Last valid code is saved only on the validated ride-start path.
- Ride Status remains rider-facing and shows Voice Detection state.
- Home status says Voice instead of WebRTC Voice.
- versionCode 44 / versionName 1.0.15-user-parity.

Developer diagnostics and internal implementation names are intentionally retained in code and hidden diagnostic paths.
