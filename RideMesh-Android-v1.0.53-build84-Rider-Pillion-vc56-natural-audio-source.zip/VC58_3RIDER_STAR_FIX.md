# RideMesh vc58 — 3-Rider STAR Fix

Based directly on vc57 / confirmed vc56 audio baseline.

## User-visible fix
Settings now exposes **3-rider offline test** with roles:
- NORMAL — proven two-rider direct mode
- A — HUB; accepts B and C
- B — RIDER; connects only to A
- C — RIDER; connects only to A

End the ride before changing role. All three devices must use the same Ride Code.

## STAR topology
A uses Nearby P2P_STAR as the hub and remains advertising until 2/2 spokes are identity-confirmed. B and C use P2P_STAR as spokes and discover/connect only to A. A forwards received B audio to C and received C audio to B while also sending its own audio to both.

## Reconnect hygiene
STATUS_ENDPOINT_UNKNOWN / 8011 endpoint IDs are invalidated and temporarily suppressed so RideMesh waits for a fresh Nearby advertisement instead of repeatedly requesting the stale endpoint.

## Audio lock
The vc56/vc57 audio path is intentionally preserved: 16 kHz mono, 20 ms frames, four frames per payload, RAW PCM16 on HIGH bandwidth, Opus otherwise, existing jitter/playout logic.
