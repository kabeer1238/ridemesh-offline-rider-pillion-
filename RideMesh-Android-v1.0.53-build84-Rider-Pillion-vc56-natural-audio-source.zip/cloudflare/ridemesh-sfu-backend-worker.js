/**
 * RideMesh vc61 Cloudflare Realtime SFU backend.
 * Required Worker secrets:
 *   SFU_APP_ID
 *   SFU_API_TOKEN
 *
 * The Android APK never contains the Cloudflare Realtime API token.
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = {
      "access-control-allow-origin": "*",
      "access-control-allow-headers": "content-type, authorization",
      "access-control-allow-methods": "GET, POST, PUT, OPTIONS",
    };
    const json = (data, status = 200) => new Response(JSON.stringify(data, null, 2), {
      status,
      headers: { "content-type": "application/json", ...cors },
    });

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (!env.SFU_APP_ID || !env.SFU_API_TOKEN) return json({ ok: false, error: "SFU secrets are not configured" }, 500);

    const cf = async (path, method = "POST", body = undefined) => {
      const response = await fetch(`https://rtc.live.cloudflare.com/v1/apps/${env.SFU_APP_ID}${path}`, {
        method,
        headers: {
          Authorization: `Bearer ${env.SFU_API_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      const text = await response.text();
      let parsed;
      try { parsed = text ? JSON.parse(text) : {}; } catch { parsed = { raw: text }; }
      if (!response.ok) {
        return { ok: false, status: response.status, body: parsed };
      }
      return { ok: true, status: response.status, body: parsed };
    };

    try {
      if (url.pathname === "/" && request.method === "GET") {
        return json({
          ok: true,
          service: "RideMesh SFU Backend",
          version: "vc61",
          appIdConfigured: Boolean(env.SFU_APP_ID),
          tokenConfigured: Boolean(env.SFU_API_TOKEN),
        });
      }

      if (url.pathname === "/session" && request.method === "POST") {
        const r = await cf("/sessions/new", "POST");
        return r.ok ? json({ ok: true, session: r.body }) : json({ ok: false, cloudflareStatus: r.status, cloudflareResponse: r.body }, r.status);
      }

      if (url.pathname === "/publish" && request.method === "POST") {
        const body = await request.json();
        const sessionId = String(body.sessionId || "");
        const sessionDescription = body.sessionDescription;
        if (!sessionId || !sessionDescription?.sdp) return json({ ok: false, error: "sessionId and sessionDescription are required" }, 400);
        const r = await cf(`/sessions/${encodeURIComponent(sessionId)}/tracks/new`, "POST", {
          sessionDescription,
          autoDiscover: true,
        });
        return r.ok ? json({ ok: true, response: r.body }) : json({ ok: false, cloudflareStatus: r.status, cloudflareResponse: r.body }, r.status);
      }

      if (url.pathname === "/pull" && request.method === "POST") {
        const body = await request.json();
        const sessionId = String(body.sessionId || "");
        const remoteSessionId = String(body.remoteSessionId || "");
        const trackName = String(body.trackName || "");
        if (!sessionId || !remoteSessionId || !trackName) return json({ ok: false, error: "sessionId, remoteSessionId and trackName are required" }, 400);
        const r = await cf(`/sessions/${encodeURIComponent(sessionId)}/tracks/new`, "POST", {
          tracks: [{ location: "remote", sessionId: remoteSessionId, trackName }],
        });
        return r.ok ? json({ ok: true, response: r.body }) : json({ ok: false, cloudflareStatus: r.status, cloudflareResponse: r.body }, r.status);
      }

      if (url.pathname === "/renegotiate" && request.method === "PUT") {
        const body = await request.json();
        const sessionId = String(body.sessionId || "");
        const sessionDescription = body.sessionDescription;
        if (!sessionId || !sessionDescription?.sdp) return json({ ok: false, error: "sessionId and sessionDescription are required" }, 400);
        const r = await cf(`/sessions/${encodeURIComponent(sessionId)}/renegotiate`, "PUT", { sessionDescription });
        return r.ok ? json({ ok: true, response: r.body }) : json({ ok: false, cloudflareStatus: r.status, cloudflareResponse: r.body }, r.status);
      }

      return json({ ok: false, error: "Not found" }, 404);
    } catch (error) {
      return json({ ok: false, error: String(error?.message || error) }, 500);
    }
  },
};
